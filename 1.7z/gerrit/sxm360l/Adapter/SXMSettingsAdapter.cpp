#include "SXMSettingsAdapter.h"
#include "ScreenList.h"
#include "DataExchange/DataController.h"
#include "Common/ResourceManager.h"
#include "UIBridge.h"

SXMSettingsAdapter::SXMSettingsAdapter() : BaseAdapter(SXM_SETTINGS_ADAPTER)
  ,m_ctxSxmChannelElements(nullptr)
  ,m_ctxSxmSongArtistAlertListModel(nullptr)
  ,m_ctxTeamAlertListModel(nullptr)
  ,m_ctxSportLeaguesListModel(nullptr)
  ,m_ctxSxmTeams(nullptr)
{
    registerNotifiedDpId();
}

SXMSettingsAdapter::~SXMSettingsAdapter()
{
    DELETE_PTR(m_ctxSxmChannelElements);
    DELETE_PTR(m_ctxSxmSongArtistAlertListModel);
    DELETE_PTR(m_ctxTeamAlertListModel);
    DELETE_PTR(m_ctxSportLeaguesListModel);
    DELETE_PTR(m_ctxSxmTeams);
}

void SXMSettingsAdapter::registerNotifiedDpId()
{
    LOGI().writeFormatted("[SXMSettingsAdapter::registerNotifiedDpId]");
    QVector<DataIdentifier::E_EVENT_NOTIFIER> notifiedEvent;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_ARTIST_AND_SONG_ALERTS;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SONG_ALERTS;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_ARTIST_ALERTS;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_SONG_ALERT;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_ARTIST_ALERT;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_HIDE_SYSTEM_COMPONENT;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_ON_CMD_GO_BACK;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_ALERT_OVER;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_TEAM_ALERT;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_LEAGUE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_TEAMS;

    registerNotifier(notifiedEvent);
}

void SXMSettingsAdapter::onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid)
{
    LOGI().writeFormatted("[SXMSettingsAdapter::onDataChanged] eventId: %d", eventid);
    switch (eventid) {
//    case DataIdentifier::E_EVENT_NOTIFIER_SXM_ARTIST_AND_SONG_ALERTS:
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SONG_ALERTS:
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_ARTIST_ALERTS:
        LOGI().writeFormatted("[SXMSettingsAdapter::onDataChanged] E_EVENT_NOTIFIER_SXM_SONG_ALERTS: %d", eventid);
//        setLstSongArtistNotification();
        break;
    case DataIdentifier::DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_SONG_ALERT:
    case DataIdentifier::DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_ARTIST_ALERT:
        eventGetListSongArtistNotifi();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_HIDE_SYSTEM_COMPONENT:
        onHideSystemComponent();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_ON_CMD_GO_BACK:
        onGoBackScreen();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_ALERT_OVER:
        request2ChangeScreen(ScreenIdentifier::E_HMI_VIEW_ID_SXM_MAXIMUM_ADD_NOTIFICATION);
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_TEAM_ALERT:
        setLstTeamNotification();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_LEAGUE:
        setLstSportLeagues();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_TEAMS:
        setLstSportTeams();
        break;
    default:
        break;
    }
}

void SXMSettingsAdapter::initializeScreen()
{
    LOGI().writeFormatted("SXMSettingsAdapter:: initializeScreen Called");
    //Check the screen and request data
    const uint32_t currentScreenId = ScreenListInstance()->getCurrentScreenID();
    LOGI().writeFormatted("[SXMSettingsAdapter::initializeScreen] current screen id: %d", currentScreenId);
    switch (currentScreenId) {
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_ADD_ARTIST_SONG:
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_ADD_ARTIST:
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_ADD_SONG:
    {
        DELETE_PTR(m_ctxSxmChannelElements);
        m_ctxSxmChannelElements = new ChannelElements();
        if (m_rootContext != nullptr) {
            CHANNEL_INFORMATION_T& channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
            m_ctxSxmChannelElements->setValue(channelInfo);
            m_rootContext->setContextProperty("ctxSxmChannelInfomation", m_ctxSxmChannelElements);
        }
        break;
    }
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_ARTIST_SONG_NOTIFICATIONS:
        LOGI().writeFormatted("[SXMSettingsAdapter::initializeScreen] current screen id: %d", currentScreenId);
        DELETE_PTR(m_ctxSxmSongArtistAlertListModel);
        m_ctxSxmSongArtistAlertListModel = new AlertListModel();
        if (m_rootContext != nullptr) {
            m_rootContext->setContextProperty("ctxSxmSongArtistAlertListModel", m_ctxSxmSongArtistAlertListModel);
            setLstSongArtistNotification();
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_MANAGE_TEAM_NOTIFICATIONS:
        LOGI().writeFormatted("[SXMSettingsAdapter::initializeScreen] current screen id: %d", currentScreenId);
        DELETE_PTR(m_ctxTeamAlertListModel);
        m_ctxTeamAlertListModel = new TeamAlertListModel();
        if (m_rootContext != nullptr) {
            m_rootContext->setContextProperty("ctxSxmTeamAlertListModel", m_ctxTeamAlertListModel);
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_CHOOSE_LEAGUE:
        LOGI().writeFormatted("[SXMSettingsAdapter::initializeScreen] current screen id: %d", currentScreenId);
        DELETE_PTR(m_ctxSportLeaguesListModel);
        m_ctxSportLeaguesListModel = new SportsLeagueListModel();
        if (m_rootContext != nullptr) {
            m_rootContext->setContextProperty("ctxSxmSportLeaguesListModel", m_ctxSportLeaguesListModel);
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_CHOOSE_TEAM:
        LOGI().writeFormatted("[SXMSettingsAdapter::initializeScreen] current screen id: %d", currentScreenId);
        DELETE_PTR(m_ctxSxmTeams);
        m_ctxSxmTeams = new TeamListModel();
        if (m_rootContext != nullptr) {
            m_rootContext->setContextProperty("ctxSxmSportTeamsListModel", m_ctxSxmTeams);
        }
        break;
    default:
        break;
    }
}

void SXMSettingsAdapter::onEventScreenChanged()
{

}

void SXMSettingsAdapter::onGoBackScreen()
{
    LOGI().writeFormatted("SXMSettingsAdapter::onGoBackScreen()");
    uint32_t currentScreenId = ScreenList::getInstance()->getCurrentScreenID();
    uint32_t previousScreenId = -1;
    QObject* item = nullptr;
    if (ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_CHOOSE_LEAGUE == currentScreenId){
        item = findChild("sxm_setting_choose_league");
        previousScreenId = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_MANAGE_TEAM_NOTIFICATIONS;
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_TEAM_ALERT, "");
    }
    else if (ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_CHOOSE_TEAM == currentScreenId){
        item = findChild("sxm_setting_choose_team");
        previousScreenId = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_CHOOSE_LEAGUE;
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_LEAGUES, "");
    }
    else{
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TO_HIDE_SYSTEM_COMPONENT,
                                                       "31,3, ");
    }

    if (item != nullptr) {
        QMetaObject::invokeMethod(item, "requestToChangeScreen",
                                  Q_ARG(QVariant,previousScreenId));
//        DELETE_PTR(item);
    }
}

void SXMSettingsAdapter::onHideSystemComponent()
{
    LOGI().writeFormatted("SXMSettingsAdapter::onHideSystemComponent()");
    uint32_t currentScreenId = ScreenList::getInstance()->getCurrentScreenID();
    uint32_t previousScreenId = -1;
    QObject* item = nullptr;
    if (ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_ARTIST_SONG_NOTIFICATIONS == currentScreenId){
        item = findChild("sxm_setting_artist_song_notification");
        previousScreenId = ScreenList::getInstance()->getPreviousScreenID();
        LOGI().writeFormatted("SXMSettingsAdapter::E_HMI_VIEW_ID_SXM_SETTINGS_ARTIST_SONG_NOTIFICATIONS(): previousScreenId[%d]", previousScreenId);

    }
    else if (ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_MANAGE_TEAM_NOTIFICATIONS == currentScreenId){
        item = findChild("sxm_setting_teams_notification");
        previousScreenId = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_ADD_TEAM_NOTIFICATIONS;
        LOGI().writeFormatted("SXMSettingsAdapter::E_HMI_VIEW_ID_SXM_SETTINGS_ADD_TEAM_NOTIFICATIONS(): previousScreenId[%d]", previousScreenId);

    }
    else{
        //Do nothing
        LOGI().writeFormatted("SXMSettingsAdapter::E_HMI_VIEW_ID_SXM_SETTINGS_ARTIST_SONG_NOTIFICATIONS() NOTHING");

    }

    if (item != nullptr) {
        QMetaObject::invokeMethod(item, "requestToChangeScreen",
                                  Q_ARG(QVariant,previousScreenId));
//        DELETE_PTR(item);
    }
}

void SXMSettingsAdapter::setLstSongArtistNotification()
{
    if (nullptr != m_ctxSxmSongArtistAlertListModel) {
        ARTIST_SONG_ALERTS_T &lstArtistSongAlerts = DataController::instance()->getArtistAndSongAlerts();
        m_ctxSxmSongArtistAlertListModel->reset();

        for(int i = 0; i < lstArtistSongAlerts.count; i++) {
            SongArtistAlertElementPtr alertElement = std::make_shared<SongArtistAlertElement>();

            alertElement->setAlertName(lstArtistSongAlerts.name[i]);
            alertElement->setAlertType(lstArtistSongAlerts.type[i]);
            LOGI().writeFormatted("[SXMSettingsAdapter::setLstSongArtistNotification]lstArtistSongAlerts.type[i]: %d", lstArtistSongAlerts.type[i]);

            m_ctxSxmSongArtistAlertListModel->appendData(alertElement);
        }
        m_ctxSxmSongArtistAlertListModel->onDataReady();
    }
    else{
        LOGI().writeFormatted("[SXMSettingsAdapter::setLstSongArtistNotification]m_ctxSxmSongArtistAlertListModel: is NULL");
    }
}

void SXMSettingsAdapter::setLstTeamNotification()
{
    if (nullptr != m_ctxTeamAlertListModel) {
        QList<TEAM_INFO_T> & lstTeamAlerts = DataController::instance()->getTeamAlerts();
        m_ctxTeamAlertListModel->reset();
        for(int i = 0; i < lstTeamAlerts.size(); i++) {
            TeamAlertElementsPtr alertElement = std::make_shared<TeamAlertElements>();
            alertElement->setTeamId(lstTeamAlerts[i].id);
            alertElement->setTeamName(lstTeamAlerts[i].name);
            alertElement->setTeamLogo(lstTeamAlerts[i].logoUrl);
            m_ctxTeamAlertListModel->appendData(alertElement);
        }
        TeamAlertElementsPtr alertElement = std::make_shared<TeamAlertElements>();
        m_ctxTeamAlertListModel->appendData(alertElement);
        m_ctxTeamAlertListModel->onDataReady();
    }
    else{
        LOGI().writeFormatted("[SXMSettingsAdapter::getLstChannelInfomation]m_ctxTeamAlertListModel: is NULL");
    }
}

void SXMSettingsAdapter::setLstSportLeagues()
{
    LOGI().writeFormatted("[SXMSettingsAdapter::setLstSportLeagues]");

    if (nullptr != m_ctxTeamAlertListModel) {
        QList<LEAGUE_INFO_T> &lstSportLeagues = DataController::instance()->getSportLeagues();
        m_ctxSportLeaguesListModel->reset();

        for(int i = 0; i < lstSportLeagues.size(); i++) {
            SportsLeagueElementsPtr leagueElement = std::make_shared<SportsLeagueElements>();
            leagueElement->setLeagueId(lstSportLeagues[i].id);
            leagueElement->setLeagueName(lstSportLeagues[i].name);
            leagueElement->setLeagueLogo(lstSportLeagues[i].logoUrl);

            m_ctxSportLeaguesListModel->appendData(leagueElement);
        }
        m_ctxSportLeaguesListModel->onDataReady();
    }
    else{
        LOGI().writeFormatted("[SXMSettingsAdapter::getLstChannelInfomation]m_ctxTeamAlertListModel: is NULL");
    }
}

void SXMSettingsAdapter::setLstSportTeams()
{
    if(nullptr != m_ctxSxmTeams){
        SPORTS_TEAM_T & teamList = DataController::instance()->getSportTeams();
        m_ctxSxmTeams->reset();

        for(int i = 0; i < teamList.count; i++) {
            TeamPtr team = std::make_shared<TeamElement>();
            team->setName(teamList.teams[i].name);
            team->setlogoUrl(teamList.teams[i].logoUrl);
            team->setId(teamList.teams[i].id);
            m_ctxSxmTeams->appendData(team);
        }
        m_ctxSxmTeams->onDataReady();
    }
}

void SXMSettingsAdapter::eventGetListSongArtistNotifi()
{
    LOGI().writeFormatted("[SXMSettingsAdapter::eventGetListSongArtistNotifi] Called");
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ARTIST_AND_SONG_ALERT, "");

}
