#ifndef SXMSETTINGSADAPTER_H
#define SXMSETTINGSADAPTER_H

#include <QObject>
#include "BaseAdapter.h"
#include "Common/SXMDefine.h"
#include "QmlModel/ChannelElements.h"
#include "QmlModel/ChannelListModel.h"
#include "AlertListModel.h"
#include "SongArtistAlertElement.h"
#include "TeamAlertElements.h"
#include "TeamAlertListModel.h"
#include "SportsLeagueElements.h"
#include "SportsLeagueListModel.h"
#include "TeamElement.h"
#include "TeamListModel.h"

class SXMSettingsAdapter : public BaseAdapter
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SXMSettingsAdapter();
    virtual ~SXMSettingsAdapter();
protected:
    //    void createConnect2Interface();
    //Register notify
    void registerNotifiedDpId();
    //Update data for current screen
    void onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid);
    //Initialize data for screen
    void initializeScreen();
    void onEventScreenChanged();
    void onHideSystemComponent();
    void onGoBackScreen();
private:
    void setLstSongArtistNotification();
    void setLstTeamNotification();
    void setLstSportLeagues();
    void setLstSportTeams();
    void eventGetListSongArtistNotifi();

    ChannelElements* m_ctxSxmChannelElements;
    AlertListModel* m_ctxSxmSongArtistAlertListModel;
    TeamAlertListModel* m_ctxTeamAlertListModel;
    SportsLeagueListModel* m_ctxSportLeaguesListModel;
    TeamListModel* m_ctxSxmTeams;
};

#endif // SXMSETTINGSADAPTER_H
