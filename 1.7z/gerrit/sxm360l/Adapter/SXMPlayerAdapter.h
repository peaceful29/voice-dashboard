#ifndef SXMPLAYERADAPTER_H
#define SXMPLAYERADAPTER_H

#include <QObject>
#include <QTime>
//#include <QTimer>
#include "BaseAdapter.h"
#include "Common/SXMDefine.h"

#include "QmlModel/ChannelElements.h"
#include "QmlModel/ChannelListModel.h"
#include "QmlModel/TeamListModel.h"
#include "SportInformationElement.h"

class QTimer;

#define     TIMEOUT_LOST_SIGNAL     10*1000     // 10s

class SXMPlayerAdapter : public BaseAdapter
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SXMPlayerAdapter();
    virtual ~SXMPlayerAdapter();

    /*****************************
    ** set functions
    *****************************/
    void setChannelInfomation(CHANNEL_INFORMATION_T& channelInfomation);
//    void setChannelNumberCurrent(int channelNumberCurrent);

    /*****************************
    ** get functions
    *****************************/
    int channelNumberCurrent();

    /*****************************
    ** other functions
    *****************************/

public slots:
    void funcTimeoutResumingSignal();

protected:
    //    void createConnect2Interface();
    //Register notify
    void registerNotifiedDpId();
    //Update data for current screen
    void onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid);
    //Initialize data for screen
    void initializeScreen();
    void onEventScreenChanged();

private:

    /*****************************
    ** functions
    *****************************/
    void onEventChannelInfomation();
    void onEventChannelChanged();
    void onEventSeekChannel();
    void onEventRequestTuneLastChannel();
    void onEventNextPageChannel();
    void onEventSignalNotAvailable();
    void onEventSignalAvailable();
    void onEventAudioNotAvailable();
    void onEventAudioAvailable();
    void onGoBackScreen();
    void onHideSystemComponent();
    void onEventTuneRequest();
    void onEventAddFavorite();
    void onEventRemoveFavorite();
    void onEventRelatedList();
    void onEventChannelInfomationNowPlaying();
    void onEventPlayBackUpdate();

    void onEventGetCurrentIndexLinearTune();
    void onEventSeekChannelInfomation();
    void onEventGetAntennaStatus();

    void onEventAntennaAvailable();
    void onEventAntennaNotAvailable();

    /*****************************
    ** variables
    *****************************/
    ChannelElements* m_ctxSxmChannelElements;
    ChannelListModel *m_ctxSxmChannelModel;
    SportInformationElement* m_ctxSxmSportInformationElements;
    QTimer *m_timerCountTimeoutLostSignal;
    int m_currentIndexLinearTune;
    bool m_isNoSignal;

    //TODO: will be update
//    TeamElement* m_ctxSxmTeamLeft;
//    TeamElement* m_ctxSxmTeamRight;
};

#endif // SXMPLAYERADAPTER_H
