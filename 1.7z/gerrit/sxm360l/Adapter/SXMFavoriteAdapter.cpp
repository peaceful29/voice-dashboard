#include "SXMFavoriteAdapter.h"
#include "Common/SXMDefine.h"
#include "DataExchange/DataController.h"
#include "ResourceManager.h"
#include "UIBridge.h"

SXMFavoriteAdapter::SXMFavoriteAdapter() : BaseAdapter(SXM_FAVORITES_ADAPTER)
  , m_ctxSxmChannelElements(nullptr)
  , m_ctxFavoritesListModel(nullptr)
{
    //    createConnect2Interface();
    registerNotifiedDpId();
}

SXMFavoriteAdapter::~SXMFavoriteAdapter()
{
    SafeDelete<FavoritesListModel>(m_ctxFavoritesListModel);
    SafeDelete<ChannelElements>(m_ctxSxmChannelElements);

}

void SXMFavoriteAdapter::registerNotifiedDpId()
{
    QVector<DataIdentifier::E_EVENT_NOTIFIER> notifiedEvent;
    //register DPid for super category
//    LOGI().writeFormatted("[SXMFavoriteAdapter::registerNotifiedDpId]");
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SMART_FAVORITES;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_FAVORITES;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_FAVORITE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_FAVORITE;
    registerNotifier(notifiedEvent);
}

void SXMFavoriteAdapter::onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid)
{
//    LOGI().writeFormatted("[SXMFavoriteAdapter::onDataChanged]");
    switch (eventid) {
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SMART_FAVORITES:
        //TODO
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_FAVORITES:
        onEventFavoritesChanged();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION:
        onEventChannelInfomation();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_FAVORITE:
        onEventAddCurrentFavorite();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_FAVORITE:
        onEventRemoveCurrentFavorite();
        break;
    default:
        break;
    }
}

void SXMFavoriteAdapter::initializeScreen()
{
    //    LOGI().writeFormatted("[SXMFavoriteAdapter::initializeScreen]");
    const uint32_t currentScreenId = ScreenListInstance()->getCurrentScreenID();
    switch (currentScreenId) {
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_FAVORITES:
    {
        if (m_rootContext != nullptr) {
            SafeDelete<ChannelElements>(m_ctxSxmChannelElements);
            m_ctxSxmChannelElements = new ChannelElements();

            CHANNEL_INFORMATION_T &channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
            m_ctxSxmChannelElements->setValue(channelInfo);
            m_rootContext->setContextProperty("ctxSxmChannelInfomation", m_ctxSxmChannelElements);

            SafeDelete<FavoritesListModel>(m_ctxFavoritesListModel);
            m_ctxFavoritesListModel = new FavoritesListModel();
            m_rootContext->setContextProperty("ctxFavoriteModel", m_ctxFavoritesListModel);
        }
    }
        break;
    default:
        break;
    }
}

void SXMFavoriteAdapter::onEventScreenChanged()
{
    LOGI().writeFormatted("[SXMFavoriteAdapter::onEventScreenChanged]");
}

void SXMFavoriteAdapter::onEventFavoritesChanged()
{
    if (m_ctxFavoritesListModel == nullptr) {
//        LOGI().writeFormatted("HopND -- [SXMFavoriteAdapter::onEventFavoritesChanged]m_ctxFavoritesListModel: is NULL");
        return;
    }
    m_ctxFavoritesListModel->reset();
    CHANNEL_INFORMATION_T &channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
    //TODO: will be update reference
    QList <FAVORITE_T>& lstFavorite = DataController::instance()->getListFavorite();
    for (int i = 0; i < lstFavorite.size(); ++i) {
        int lengthName = QString(lstFavorite[i].name).length();
        if (lengthName > 0) {
            FavoritesListElementsPtr fav = std::make_shared<FavoritesListElements>();
            fav->setFavType(lstFavorite[i].type);
            fav->setFavName(lstFavorite[i].name);
            fav->setFavId(lstFavorite[i].id);
            fav->setFavBanner(lstFavorite[i].contextualBanner);
            fav->setNumber(lstFavorite[i].channelInfo.number);
            fav->setName(lstFavorite[i].channelInfo.name);
            fav->setShortDescription(lstFavorite[i].channelInfo.shortDescription);
            fav->setLogo(lstFavorite[i].channelInfo.logoUrl);
            //TODO: wait framework
            if(channelInfo.number == lstFavorite[i].channelInfo.number) {
                fav->setIsNowPlaying(true);
            }
            m_ctxFavoritesListModel->appendData(fav);
        }
    }
    m_ctxFavoritesListModel->onDataReady();
}

void SXMFavoriteAdapter::setChannelInfomation(CHANNEL_INFORMATION_T& channelInfomation)
{
    LOGI().writeFormatted("[SXMFavoriteAdapter::setChannelInfomation] Called");
    if ((nullptr != m_ctxSxmChannelElements) && (m_rootContext != nullptr)){
        m_ctxSxmChannelElements->setValue(channelInfomation);
        m_rootContext->setContextProperty("ctxSxmChannelInfomation", m_ctxSxmChannelElements);
    }
    else{
        LOGI().writeFormatted("[SXMFavoriteAdapter::setChannelInfomation]: m_ctxSxmChannelElements is NULL");
    }
}

void SXMFavoriteAdapter::onEventChannelInfomation()
{
    LOGI().writeFormatted("[SXMFavoriteAdapter::onEventChannelInfomation]: Called");
    updateChannelData(m_ctxFavoritesListModel, E_FAVORITES_CHANNELS_IS_NOWPLAYING);

    CHANNEL_INFORMATION_T &channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
    setChannelInfomation(channelInfo);
}

void SXMFavoriteAdapter::onEventAddCurrentFavorite()
{
    LOGI().writeFormatted("[SXMFavoriteAdapter::onEventAddCurrentFavorite]: Called");
    CHANNEL_INFORMATION_T& channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
    channelInfo.isFavorite = true;
    setChannelInfomation(channelInfo);
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_FAVORITES, "");
    updateChannelData(nullptr, E_FAVORITES_CHANNELS_IS_FAVORITE);
}
void SXMFavoriteAdapter::onEventRemoveCurrentFavorite()
{
    LOGI().writeFormatted("[SXMFavoriteAdapter::onEventRemoveCurrentFavorite]: Called");
    unsigned int channelNumber = ResourceManager::instance()->getCurrentChannelNumber();
    CHANNEL_INFORMATION_T& channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
    updateChannelData(nullptr, E_FAVORITES_CHANNELS_IS_FAVORITE);
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_FAVORITES, "");

    if(channelNumber == channelInfo.number){
        channelInfo.isFavorite = false;
        setChannelInfomation(channelInfo);
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_FAVORITES, "");
    }
}
