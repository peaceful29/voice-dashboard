#ifndef SPEECHADAPTER_H
#define SPEECHADAPTER_H

#include <QObject>
#include <QMap>

#include "BaseAdapter.h"
#include "Common/SXMDefine.h"
#include "ScreenIdentifier.h"
#include "UIBridge.h"
#include "ChannelListModel.h"
#include "SuperCategoryListModel.h"
#include "CategoryListModel.h"
#include "SuperCategoryElements.h"
#include "CategoryElements.h"
#include "VideoTunerListShowListModel.h"
#include "TeamListModel.h"

class SpeechAdapter : public BaseAdapter
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SpeechAdapter();
    virtual ~SpeechAdapter();
    /**
     * @brief change mode from other mode to speechmode
     */
    void activeSpeechMode(QString intent);
    void inactiveSpeechMode();

protected:
    //Register notify
    void registerNotifiedDpId();
    void onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid);
    void initializeScreen();
    void onEventScreenChanged();
private:
    void requestToSpeechMode();
    //Create map command and screen ID for speech mode
    void createMapCommandAndScreenID();
    int getScreenIdByCommand(const QString command);

#ifndef EXCLUDE_SPEECH
    QString requestedTeleprompterShow();
    QString requestedListShow();
    void onSystemVideoTunerStationListSat();
    void onSystemVideoTunerChannelList();
    void onSystemVideoTunerCategorySatList();
    void onSystemVideoTunerCategorySat(SPEECH_SCFA_LISTSHOW_INFO_ST &listShowInfo);
    void onSystemVideoTunerStationSat(SPEECH_SCFA_LISTSHOW_INFO_ST &listShowInfo);
    void onSystemVideoTunerCategoryStationListSat(QString strHeadline);
    void onSystemVideoTunerSdarsTeam(SPEECH_SCFA_TELEPROMPTERSHOW_INFO_ST &info);
    void onSpeechListPageNavigation();
    void onSpeechListDataGet();
    void onSpeechListFocusSet();
#endif

    void onStationList();
    void onChannelInformation();
    void onSuperCategorySatList();
    void onSxmCategory();
    void onSxmLiveChannels();
    void onEventSdarsTeam();
    void onEventSdarsDataChannel();
    void onEventSdarsCategorySatList();
    void onEventSdarsCategoryChannel();
    void onEventSpeechModeListCurrentIndexChanged();
    void clearAllList();

    QMap<QString, int> m_mapCommandScreenID;
    ChannelListModel *m_ctxSxmStationList;
    ChannelElements* m_ctxSxmActiveChannel;

    SuperCategoryListModel* m_ctxSxmSuperCategories;
    CategoryListModel*      m_ctxSxmCategories;

    VideoTunerListShowListModel *m_ctxSxmVideoTunerListShow;
    TeamListModel *m_teamListModel;

    QString m_latestCommand;
    QString m_currentSuperCategory;
};

#endif // SPEECHADAPTER_H
