#ifndef SXMSEARCHDAPTER_H
#define SXMSEARCHDAPTER_H

#include <QObject>
#include "BaseAdapter.h"
#include "Common/SXMDefine.h"

class SXMSearchAdapter : public BaseAdapter
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SXMSearchAdapter();
    virtual ~SXMSearchAdapter();
protected:
    //    void createConnect2Interface();
    //Register notify
    void registerNotifiedDpId();
    //Update data for current screen
    void onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid);
    //Initialize data for screen
    void initializeScreen();
    void onEventScreenChanged();
    void onEventGetAllChannels();
    void onEventChannelInfomation();

};

#endif // SXMSEARCHDAPTER_H
