#include "SpeechAdapter.h"
#include "DataExchange/SXMKeyPadHandler.h"
#include "ResourceManager.h"

/*
 * Speech command
 * SYSTEM_VIDEO_TUNER_STATION_LIST_SAT = "SiriusXM tune to channel name"
 * SYSTEM_VIDEO_TUNER_CHANNELLIST = "tune to channel number"
 * SYSTEM_VIDEO_TUNER_CATEGORY_SAT_LIST = "Sirius XM tune by genre"
 * SYSTEM_VIDEO_TUNER_CATEGORY_SAT = "SiriusXM tune by genre <genre name>"
 * SYSTEM_VIDEO_TUNER_STATION_SAT = "Sirius XM tune to <SAT_station_name>"
 * SYSTEM_VIDEO_TUNER_CATEGORY_STATION_LIST_SAT = "Sirius XM tune by genre <category name NFL Play-by-Play>"
 * SYSTEM_VIDEO_TUNER_SDARS_TEAM = "add to my team list"
 */


#define SPEECHCOMMAND(x) QString(#x)
#define LIST_PAGE_ITEM_NUMBER 5

SpeechAdapter::SpeechAdapter()
    : BaseAdapter(SXM_SPEECH_ADAPTER)
    , m_ctxSxmStationList(nullptr)
    , m_ctxSxmActiveChannel(nullptr)
    , m_ctxSxmSuperCategories(nullptr)
    , m_ctxSxmCategories(nullptr)
    , m_ctxSxmVideoTunerListShow(nullptr)
    , m_teamListModel(nullptr)
    , m_latestCommand("")
{
    m_ctxSxmActiveChannel = new ChannelElements();
    m_ctxSxmStationList = new ChannelListModel();
    m_ctxSxmVideoTunerListShow = new VideoTunerListShowListModel();
    m_ctxSxmVideoTunerListShow->configurePaging(LIST_PAGE_ITEM_NUMBER);
    m_teamListModel = new TeamListModel();
    createMapCommandAndScreenID();
    registerNotifiedDpId();
}

SpeechAdapter::~SpeechAdapter()
{
    SafeDelete<ChannelListModel>(m_ctxSxmStationList);
    SafeDelete<ChannelElements>(m_ctxSxmActiveChannel);
    SafeDelete<SuperCategoryListModel>(m_ctxSxmSuperCategories);
    SafeDelete<CategoryListModel>(m_ctxSxmCategories);
    SafeDelete<VideoTunerListShowListModel>(m_ctxSxmVideoTunerListShow);
    SafeDelete<TeamListModel>(m_teamListModel);
}

void SpeechAdapter::activeSpeechMode(QString intent)
{
#ifndef EXCLUDE_SPEECH
    clearAllList();
    setProperty("mainContent", "visible", QVariant::fromValue(false));
    DataController::instance()->resetCurrentIndexListSpeechMode();
    if (intent == QString("telepromptershow")){
        m_latestCommand = requestedTeleprompterShow();
    }else if (intent == QString("listshow")){
        m_latestCommand = requestedListShow();
    }
#else
    Q_UNUSED(intent);
#endif
}

void SpeechAdapter::inactiveSpeechMode()
{

}

void SpeechAdapter::registerNotifiedDpId()
{
    QVector<DataIdentifier::E_EVENT_NOTIFIER> notifiedEvent;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNELS;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SUPERCATEGORY;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CATEGORIES;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_PAGE_NAVIGATION;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_DATA_GET_LINE_NUM;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_FOCUS_SET;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_TEAM_DATA;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_DATA_CHANNEL;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_CATEGORY_SAT_LIST;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_CATEGORY_CHANNEL;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_CURRENT_INDEX_CHANGED;

    registerNotifier(notifiedEvent);
}

void SpeechAdapter::onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid)
{
    switch (eventid) {
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNELS:{
        onSxmLiveChannels();
    }
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION:{
        onChannelInformation();
    }
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SUPERCATEGORY:{
        onSuperCategorySatList();
    }
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CATEGORIES:{
        onSxmCategory();
    }
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_PAGE_NAVIGATION:{
        onSpeechListPageNavigation();
    }
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_DATA_GET_LINE_NUM:{
        onSpeechListDataGet();
    }
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_FOCUS_SET:{
        onSpeechListFocusSet();
    }
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_TEAM_DATA:
        onEventSdarsTeam();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_DATA_CHANNEL:
        onEventSdarsDataChannel();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_CATEGORY_SAT_LIST:
        onEventSdarsCategorySatList();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_CATEGORY_CHANNEL:
        onEventSdarsCategoryChannel();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_CURRENT_INDEX_CHANGED:
        onEventSpeechModeListCurrentIndexChanged();
        break;
    default:
        break;
    }
}

void SpeechAdapter::initializeScreen()
{
    const uint32_t currentScreenId = ScreenListInstance()->getCurrentScreenID();
    switch (currentScreenId) {
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CHANNELLIST:
        LOGI().writeFormatted("[SpeechAdapter::initializeScreen]");
        if (m_rootContext != nullptr) {
            LOGI().writeFormatted("[SpeechAdapter::initializeScreen]ContextProperty");
            m_rootContext->setContextProperty("ctxSxmActiveChannel", m_ctxSxmActiveChannel);
        }
        break;
    }
}

void SpeechAdapter::onEventScreenChanged()
{

}

void SpeechAdapter::requestToSpeechMode()
{

}

void SpeechAdapter::createMapCommandAndScreenID()
{
    //1. SYSTEM_VIDEO_TUNER_STATION_LIST_SAT
    m_mapCommandScreenID[SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_STATION_LIST_SAT)] = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_LIST_SAT;
    //2. SYSTEM_VIDEO_TUNER_CATEGORY_SAT
    m_mapCommandScreenID[SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_SAT)] = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_SAT;
    //3. SYSTEM_VIDEO_TUNER_SDARS_TEAM
    m_mapCommandScreenID[SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_SDARS_TEAM)] = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_SDARS_TEAM;
    //4. SYSTEM_VIDEO_TUNER_STATION_SAT
    m_mapCommandScreenID[SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_STATION_SAT)] = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_STATION_SAT;
    //5. SYSTEM_VIDEO_TUNER_CATEGORY_SAT_LIST
    m_mapCommandScreenID[SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_SAT_LIST)] = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_SAT_LIST;
    //6. SYSTEM_VIDEO_TUNER_CATEGORY_STATION_LIST_SAT
    m_mapCommandScreenID[SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_STATION_LIST_SAT)] = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_STATION_LIST_SAT;
    //7. SYSTEM_VIDEO_TUNER_CHANNELLIST
    m_mapCommandScreenID[SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CHANNELLIST)] = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CHANNELLIST;
}

int SpeechAdapter::getScreenIdByCommand(const QString command)
{
    int screendID = -1;
    if (m_mapCommandScreenID.count(command) != 0){
        screendID = m_mapCommandScreenID[command];
    }
    LOGI().writeFormatted("[SpeechAdapter::getScreenID][%s][%d]", command.toStdString().c_str(), screendID);
    return screendID;
}

#ifndef EXCLUDE_SPEECH
QString SpeechAdapter::requestedTeleprompterShow()
{
    LOGI().writeFormatted("[SpeechAdapter::activeSpeechMode]");

    DataController::instance()->retrieveTeleprompterShowInfo();
    SPEECH_SCFA_TELEPROMPTERSHOW_INFO_ST info = DataController::instance()->getScfaTeleprompterShowInfo();

    int32_t nNumText = info.nNumText;
    QString list("");
    for (int32_t i = 0; i < nNumText; i++){
        SPEECH_STRING_T tmp = info.listText[i];
        list += QString(tmp.sName);
        if (i != nNumText - 1)
            list += ",";
    }
    bool success = setProperty("obj_speech_mode_intent_bar", "stringData", QVariant::fromValue(list));
    LOGI().writeFormatted("[SpeechAdapter::requestedTeleprompterShow][%s][%d]", list.toStdString().c_str(), success);
    SPEECH_STRING_T strVideo = info.strVideo;
    LOGI().writeFormatted("[SpeechAdapter::requestedTeleprompterShow][%s][%d]", strVideo.sName, nNumText);

//    int screenID = getScreenIdByCommand(QString(strVideo.sName));
//    LOGI().writeFormatted("[SpeechAdapter::requestedTeleprompterShow]ScreenID[%d]", screenID);
//    if (screenID != -1){
//        onEventScreenReady(screenID);
//    }

    //TODO Begin testing application
    //Please change the command here if you want to test something
//    snprintf(strVideo.sName, SPEECH_STRING_MAX_LENGTH, "%s", "SYSTEM_VIDEO_TUNER_SDARS_TEAM");
    //End testing application

    if (QString(strVideo.sName) == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_STATION_LIST_SAT)){
        onSystemVideoTunerStationListSat();
    }else if (QString(strVideo.sName) == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CHANNELLIST)){
        onSystemVideoTunerChannelList();
    }else if (QString(strVideo.sName) == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_SAT_LIST)){
        onSystemVideoTunerCategorySatList();
    }else if (QString(strVideo.sName) == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_STATION_LIST_SAT)){
        onSystemVideoTunerCategoryStationListSat(QString(info.strHeadline.sName));
    }else if (QString(strVideo.sName) == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_SDARS_TEAM)){
        onSystemVideoTunerSdarsTeam(info);
    }

    //Build up screen base on command
    int screenID = getScreenIdByCommand(QString(strVideo.sName));
    LOGI().writeFormatted("[SpeechAdapter::requestedTeleprompterShow]ScreenID[%d]", screenID);
    if (screenID != -1){
        onEventScreenReady(screenID);
        setProperty("mainContent", "visible", QVariant::fromValue(true));
    }
    return QString(strVideo.sName);
}

QString SpeechAdapter::requestedListShow()
{
    LOGI().writeFormatted("[SpeechAdapter::requestedListShow]");

    //Get list show: intent bar
    DataController::instance()->retrieveListShowInfo();
    SPEECH_SCFA_LISTSHOW_INFO_ST info = DataController::instance()->getScfaListShowInfo();
    int32_t nNumText = info.nNumText;
    QString list("");
    for (int32_t i = 0; i < nNumText; i++){
        SPEECH_STRING_T tmp = info.listText[i];
        list += QString(tmp.sName);
        //remove last comma
        if (i != nNumText - 1)
            list += ",";
    }
    bool success = setProperty("obj_speech_mode_intent_bar", "stringData", QVariant::fromValue(list));
    LOGI().writeFormatted("[SpeechAdapter::requestedListShow][%s][%d]", list.toStdString().c_str(), success);

    //Get string video tuner
    SPEECH_STRING_T strVideo = info.strVideo;
    LOGI().writeFormatted("[SpeechAdapter::requestedListShow][%s][%d]", strVideo.sName, nNumText);

    //Decode command and implement
//    if (QString(strVideo.sName) == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_SAT)){
//        onSystemVideoTunerCategorySat(info);
//    }else if (QString(strVideo.sName) == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_STATION_SAT)){
//        onSystemVideoTunerStationSat(info);
//    }

    //Build up screen base on command
    int screenID = getScreenIdByCommand(QString(strVideo.sName));
    LOGI().writeFormatted("[SpeechAdapter::requestedListShow]ScreenID[%d]", screenID);
    if (screenID != -1){
        onEventScreenReady(screenID);
        setProperty("mainContent", "visible", QVariant::fromValue(true));
    }

    //Decode command and implement
    if (QString(strVideo.sName) == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_SAT)){
        onSystemVideoTunerCategorySat(info);
    }else if (QString(strVideo.sName) == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_STATION_SAT)){
        onSystemVideoTunerStationSat(info);
    }

    return QString(strVideo.sName);
}

void SpeechAdapter::onSystemVideoTunerStationListSat()
{
    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerStationListSat]");
    if (m_ctxSxmStationList != nullptr){
        LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerStationListSat]Reset list");
        m_ctxSxmStationList->reset();
    }else{
        m_ctxSxmStationList = new ChannelListModel();
    }
    if (m_rootContext != nullptr) {
        m_rootContext->setContextProperty("ctxStationList", m_ctxSxmStationList);
    }
    //Get list
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SDARS_DATA_CHANNEL, "");
}

void SpeechAdapter::onSystemVideoTunerChannelList()
{
    //Need to get current channel
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNEL_INFORMATION, "1");
    //get all list here
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNELS_2, "");
}

void SpeechAdapter::onSystemVideoTunerCategorySatList()
{
    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerCategorySatList]");
    SafeDelete<SuperCategoryListModel>(m_ctxSxmSuperCategories);
    SafeDelete<CategoryListModel>(m_ctxSxmCategories);
    m_ctxSxmSuperCategories = new SuperCategoryListModel();
    m_ctxSxmCategories = new CategoryListModel();

    if (m_rootContext != nullptr) {
        m_rootContext->setContextProperty("ctxSuperCategoryModel", m_ctxSxmSuperCategories);
        m_rootContext->setContextProperty("ctxCategoriesModel", m_ctxSxmCategories);
    }
    //Get super category
//    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SUPERCATEGORY, "");
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SDARS_CATEGORY_SAT_LIST, "");
}

void SpeechAdapter::onSystemVideoTunerCategorySat(SPEECH_SCFA_LISTSHOW_INFO_ST &listShowInfo)
{
    //TODO: Create context property here. Need to reset due to model is used by other. <Check it>
    if (m_ctxSxmVideoTunerListShow != nullptr){
        m_ctxSxmVideoTunerListShow->reset();
    }else {
        m_ctxSxmVideoTunerListShow = new VideoTunerListShowListModel();
    }

    if (m_rootContext != nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerCategorySat]ContextProperty");
        m_rootContext->setContextProperty("ctxVideoTunerCategorySat", m_ctxSxmVideoTunerListShow);
    }

    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerCategorySat]");
    if (listShowInfo.nNumString != listShowInfo.nNumID){
        LOGE().writeFormatted("[SpeechAdapter::onSystemVideoTunerCategorySat]NumString[%d]NumInd[%d]", listShowInfo.nNumString, listShowInfo.nNumID);
    }else{
        int numberElements = listShowInfo.nNumString;
        //Create list
        for(int i = 0; i < numberElements; i++) {
            QString listStringEle = QString(listShowInfo.listString[i].sName);
            QString indexEle = QString::number(i%LIST_PAGE_ITEM_NUMBER + 1);
            QString extraStr = QString(listShowInfo.listStringExtra1[i].sName);
            LOGE().writeFormatted("[SpeechAdapter::onSystemVideoTunerCategorySat]ListStr[%s]NumInd[%s]Path[%s]",
                                  listStringEle.toStdString().c_str(), indexEle.toStdString().c_str(), listShowInfo.listStringExtra1[i].sName);
            VideoTunerListShowElementPtr element = std::make_shared<VideoTunerListShowElement>();
            element->setNameComp(listStringEle);
            element->setIndexComp(indexEle);
            element->setImagePathComp(extraStr);
            m_ctxSxmVideoTunerListShow->appendData(element);
        }
        m_ctxSxmVideoTunerListShow->onDataReady();
        setProperty("list_index_component", "countItem", numberElements > LIST_PAGE_ITEM_NUMBER ? LIST_PAGE_ITEM_NUMBER : numberElements);
        setProperty("list_index_component", "highlightIdx", -1);
        LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerCategorySat]Size[%d]", m_ctxSxmVideoTunerListShow->rowCount());
    }
}

void SpeechAdapter::onSystemVideoTunerStationSat(SPEECH_SCFA_LISTSHOW_INFO_ST &listShowInfo)
{
    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerStationSat]");
    //TODO: Create context property here. Need to reset due to model is used by other. <Check it>
    if (m_ctxSxmVideoTunerListShow != nullptr){
        m_ctxSxmVideoTunerListShow->reset();
    }else {
        m_ctxSxmVideoTunerListShow = new VideoTunerListShowListModel();
    }

    if (m_rootContext != nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerStationSat]ContextProperty");
        m_rootContext->setContextProperty("ctxVideoTunerCategorySat", m_ctxSxmVideoTunerListShow);
    }

    //Create the list and push to screen
    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerStationSat]");
    if (listShowInfo.nNumString != listShowInfo.nNumID){
        LOGE().writeFormatted("[SpeechAdapter::onSystemVideoTunerStationSat]NumString[%d]NumInd[%d]", listShowInfo.nNumString, listShowInfo.nNumID);
    }else{
        int numberElements = listShowInfo.nNumString;
        //Create list
        for(int i = 0; i < numberElements; i++) {
            QString listStringEle = QString(listShowInfo.listString[i].sName);
            QString indexEle = QString::number(i%LIST_PAGE_ITEM_NUMBER + 1);
            QString extraStr = QString(listShowInfo.listStringExtra1[i].sName);
            LOGE().writeFormatted("[SpeechAdapter::onSystemVideoTunerStationSat]ListStr[%s]NumInd[%s]",
                                  listStringEle.toStdString().c_str(), indexEle.toStdString().c_str());
            extraStr = QString("/opt/bin/res/Landrover/Luxury/png/media_sirius(SXM)/day/icon_indicator_wifi.png");
            VideoTunerListShowElementPtr element = std::make_shared<VideoTunerListShowElement>();
            element->setNameComp(listStringEle);
            element->setIndexComp(indexEle);
            element->setImagePathComp(extraStr);
            m_ctxSxmVideoTunerListShow->appendData(element);
        }
        m_ctxSxmVideoTunerListShow->onDataReady();
        setProperty("list_index_component", "countItem", numberElements > LIST_PAGE_ITEM_NUMBER ? LIST_PAGE_ITEM_NUMBER : numberElements);
        setProperty("list_index_component", "highlightIdx", -1);
        LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerStationSat]Size[%d]", m_ctxSxmVideoTunerListShow->rowCount());
    }
}

void SpeechAdapter::onSystemVideoTunerCategoryStationListSat(QString strHeadline)
{
    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerCategoryStationListSat][%s]", strHeadline.toStdString().c_str());
    //Make context property. Reset list if other is now display
    if (m_ctxSxmStationList != nullptr){
        m_ctxSxmStationList->reset();
    }else{
        m_ctxSxmStationList = new ChannelListModel();
    }
    if (m_rootContext != nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerCategoryStationListSat]ContextProperty");
        m_rootContext->setContextProperty("ctxStationList", m_ctxSxmStationList);
    }

    //Request Live channels with category
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SDARS_CATEGORY_CHANNEL, strHeadline);
}

void SpeechAdapter::onSystemVideoTunerSdarsTeam(SPEECH_SCFA_TELEPROMPTERSHOW_INFO_ST &info)
{
//    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerSdarsTeam][%d]", info.nExtra1);
//    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerSdarsTeam][%d]", info.nExtra2);
//    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerSdarsTeam][%d]", info.nExtra3);
//    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerSdarsTeam][%s]", info.strHeadline.sName);
    LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerSdarsTeam]");
    //Make context property. Reset list if other is now display
    if (m_teamListModel != nullptr){
        m_teamListModel->reset();
    }else{
        m_teamListModel = new TeamListModel();
    }
    if (m_rootContext != nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onSystemVideoTunerSdarsTeam]ContextProperty");
        m_rootContext->setContextProperty("ctxSdarsTeamList", m_teamListModel);
    }

    //Request Live channels with category
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SDARS_TEAM_DATA, "");
}

void SpeechAdapter::onSpeechListPageNavigation()
{
    int pageNavigation = DataController::instance()->getData(DataIdentifier::E_DATA_IDENTIFIER_SPEECH_MODE_LIST_PAGE_NAVIGATION).toInt();
    //Process page navigation: next page or previous page
    LOGI().writeFormatted("[SpeechAdapter::onSpeechListPageNavigation][%d]", pageNavigation);

    int result = -1;
    if (m_latestCommand == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_STATION_SAT) ||
            m_latestCommand == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_SAT)){
        if (m_ctxSxmVideoTunerListShow != nullptr){
//            int currentIndex = DataController::instance()->getData(DataIdentifier::E_DATA_IDENTIFIER_SPEECH_MODE_LIST_CURRENT_INDEX).toInt();
//            m_ctxSxmVideoTunerListShow->setCurrentIndex(currentIndex);
            result = m_ctxSxmVideoTunerListShow->pageNavigation(static_cast<E_VIDEO_TUNER_PAGE_NAVIGATION>(pageNavigation));
        }
    }
    LOGI().writeFormatted("[SpeechAdapter::onSpeechListPageNavigation]Position[%d]", result);

    //Response for speech service
    if (result == -1)
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_RESPONSE_LIST_PAGE, QString::number((int)false));
    else if (result >= 0){
        //Set current index to QML
        LOGI().writeFormatted("[SpeechAdapter::onSpeechListPageNavigation][%d]", result);
        setProperty("objname_video_tuner_list_station", "currentIndex", result);
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_RESPONSE_LIST_PAGE, QString::number((int)true));
    }
}

void SpeechAdapter::onSpeechListDataGet()
{
    int lineNum = DataController::instance()->getData(DataIdentifier::E_DATA_IDENTIFIER_SPEECH_MODE_LIST_DATA_GET_LINE_NUM).toInt();
    //Process page navigation: next page or previous page
    LOGI().writeFormatted("[SpeechAdapter::onSpeechListDataGet][%d]", lineNum);

    int abosuluteIdx = -1;
    if (m_latestCommand == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_STATION_SAT) ||
            m_latestCommand == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_SAT)){
        if (m_ctxSxmVideoTunerListShow != nullptr){
            abosuluteIdx = m_ctxSxmVideoTunerListShow->requestToHighLight(lineNum);
            LOGI().writeFormatted("[SpeechAdapter::onSpeechListDataGet][%d]", abosuluteIdx);
        }
    }
    //Response for speech service
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_RESPONSE_LINE_NUM_ABSOLUTE_IDX, QString::number((int)abosuluteIdx));
}

void SpeechAdapter::onSpeechListFocusSet()
{
    int absoluteIdx = DataController::instance()->getData(DataIdentifier::E_DATA_IDENTIFIER_SPEECH_MODE_LIST_FOCUS_SET).toInt();
    //Process page navigation: next page or previous page
    LOGI().writeFormatted("[SpeechAdapter::onSpeechListFocusSet][%d]", absoluteIdx);

    bool result = true;
    if (m_latestCommand == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_STATION_SAT) ||
            m_latestCommand == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_SAT)){
        if (m_ctxSxmVideoTunerListShow != nullptr){
            int index = m_ctxSxmVideoTunerListShow->highLightItem(absoluteIdx);            
            m_ctxSxmVideoTunerListShow->updateData(index, E_VIDEO_TUNER_LIST_SHOW_HIGH_LIGHT, QVariant::fromValue(true));
            int lineNum = m_ctxSxmVideoTunerListShow->getLineNumber(absoluteIdx);
            LOGI().writeFormatted("[SpeechAdapter::onSpeechListFocusSet]Index[%d][%d]]", index, lineNum);
            setProperty("list_index_component", "highlightIdx", QVariant::fromValue(lineNum));
        }
    }
    // TO DO: highlight index for sdars team screen
    if (m_latestCommand == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_SDARS_TEAM))
    {
        int lineNum = m_teamListModel->getLineNumber(absoluteIdx);
        setProperty("list_index_component", "highlightIdx", QVariant::fromValue(lineNum));
    }
    //Response for speech service
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_RESPONSE_LIST_FOCUS_SET, QString::number((int)result));
}

#endif

void SpeechAdapter::onStationList()
{
    LOGI().writeFormatted("[SpeechAdapter::onStationList]");
    //Create data for direct tune
//    SXMKeyPadHandler::instance()->createValidNumberMapping();
    if (m_ctxSxmStationList == nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onStatioList]m_ctxSxmStationList: is NULL");
        return;
    }
    QList<CHANNEL_INFORMATION_T> channelList = DataController::instance()->getLstChannelInformation();
    m_ctxSxmStationList->reset();
    for(int i = 0; i < channelList.size(); i++) {
        ChannelElementPtr channel = std::make_shared<ChannelElements>();
        channel->setName(channelList[i].name);
        channel->setLogo(channelList[i].logoUrl);
        m_ctxSxmStationList->appendData(channel);
    }
    m_ctxSxmStationList->onDataReady();
}

void SpeechAdapter::onChannelInformation()
{
    CHANNEL_INFORMATION_T &channelInfomation = DataController::instance()->getChannelInformation();
    LOGI().writeFormatted("[SpeechAdapter::onChannelInformation][%d]", channelInfomation.number);
    if ((m_ctxSxmActiveChannel != nullptr) && (m_rootContext != nullptr)){
        m_ctxSxmActiveChannel->setValue(channelInfomation);
        m_rootContext->setContextProperty("ctxSxmActiveChannel", m_ctxSxmActiveChannel);
    }
    LOGI().writeFormatted("[SpeechAdapter::onChannelInformation]End");
}

void SpeechAdapter::onSuperCategorySatList()
{
    bool isMusic = false;
    bool superCategoryExist = false;

    if (m_ctxSxmSuperCategories == nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onSuperCategorySatList]m_ctxSxmSuperCategories: is NULL");
        return;
    }
    m_currentSuperCategory = ResourceManager::instance()->getCurrentSuperCategory();

    SUPER_CATEGORY_LIST_T &superCategoryList = DataController::instance()->getSuperCategorList();
    LOGI().writeFormatted("[SpeechAdapter::onSuperCategorySatList count: %d]: Called", superCategoryList.count);
    m_ctxSxmSuperCategories->reset();

    for(unsigned int i = 0; i < superCategoryList.count; i++) {
        SuperCategoryElementsPtr superCategory = std::make_shared<SuperCategoryElements>();
        superCategory->setSuperCategoryName(superCategoryList.name[i]);
        if(!(QString(superCategoryList.name[i]).compare("Music")) && isMusic == false){
            isMusic = true;
        }
        if (m_currentSuperCategory == superCategoryList.name[i]) {
            superCategory->setIsCurrent(true);
            superCategoryExist = true;
        } else {
            superCategory->setIsCurrent(false);
        }
        m_ctxSxmSuperCategories->appendData(superCategory);
    }
    m_ctxSxmSuperCategories->onDataReady();
    LOGI().writeFormatted("[SpeechAdapter::onSuperCategorySatList count: %d]: Called", m_ctxSxmSuperCategories->rowCount());

    if((!m_currentSuperCategory.compare("")) && isMusic) {
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CATEGORIES, "Music");
    }
    else if(superCategoryExist) {
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CATEGORIES, m_currentSuperCategory);
    }
    else {
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CATEGORIES, superCategoryList.name[0]);
    }
}

void SpeechAdapter::onSxmCategory()
{
    int length = 0;
    int isLogo = 0;
    m_currentSuperCategory = ResourceManager::instance()->getCurrentSuperCategory();
    if (m_ctxSxmCategories == nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onSxmCategory]m_ctxSxmCategories: is NULL");
        return;
    }
    m_ctxSxmCategories->reset();
    CATEGORY_LIST_T &categoriesList = DataController::instance()->getCategoryList();

    for(unsigned int i = 0; i < categoriesList.count; i++) {
        length = QString(categoriesList.name[i]).length();
        isLogo = QFile::exists(categoriesList.logo[i]);
        if(length > 0){
            CategoryElementsPtr categoriesInfo = std::make_shared<CategoryElements>();
            categoriesInfo->setCategoryName(categoriesList.name[i]);
            if(isLogo){
                categoriesInfo->setCategoryLogo(categoriesList.logo[i]);
            }
            m_ctxSxmCategories->appendData(categoriesInfo);
        }
    }
    m_ctxSxmCategories->onDataReady();
    if (m_ctxSxmSuperCategories == nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onSxmCategory]m_ctxSxmSuperCategories: is NULL");
        return;
    }
    for (int i = 0; i < m_ctxSxmSuperCategories->rowCount(); i++) {
        SuperCategoryElements* element = dynamic_cast<SuperCategoryElements*>(m_ctxSxmSuperCategories->getElement(i));
        if (ResourceManager::instance()->getCurrentSuperCategory() == element->superCategoryName()){
            m_ctxSxmSuperCategories->updateData(i, E_SUPER_CATEGORIES_LIST_ROLES_IS_CURRENT, QVariant::fromValue(true));
        } else {
            m_ctxSxmSuperCategories->updateData(i, E_SUPER_CATEGORIES_LIST_ROLES_IS_CURRENT, QVariant::fromValue(false));
        }
    }
    m_ctxSxmSuperCategories->onDataReady();
}

void SpeechAdapter::onSxmLiveChannels()
{
    //Create data for direct tune
    if (m_latestCommand == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CHANNELLIST)){
//        SXMKeyPadHandler::instance()->createValidNumberMapping();
        return;
    }

    if (m_ctxSxmStationList == nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onSxmLiveChannels]m_ctxSxmStationList is NULL");
        return;
    }
    int lengthName = 0;
    int lengthshortDescription = 0;
    int isLogo = 0;

    QList<CHANNEL_INFORMATION_T> &channelList = DataController::instance()->getLstChannelInformation();
    m_ctxSxmStationList->reset();

    LOGI().writeFormatted("[SpeechAdapter::onSxmLiveChannels]Size[%d]", channelList.size());
    for(int i = 0; i < channelList.size(); i++) {
        lengthName = QString(channelList[i].name).length();
        lengthshortDescription = QString(channelList[i].shortDescription).length();
        isLogo = QFile::exists(channelList[i].logoUrl);

        if ((lengthName > 0) && (lengthshortDescription > 0)){
            ChannelElementPtr channel = std::make_shared<ChannelElements>();
            channel->setName(channelList[i].name);
            channel->setNumber(channelList[i].number);
            channel->setShortDescription(channelList[i].shortDescription);
            channel->setIsFavorite(channelList[i].isFavorite);
            channel->setContextualBanner(channelList[i].show.contextualBanner);
            channel->setIsAvailable(channelList[i].isAvailable);
//            channel->setIsAvailable(true);
            channel->setIsNowPlaying(channelList[i].isNowPlaying);
            channel->setSportState(static_cast<UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE>(channelList[i].sports.state));
            if(isLogo == true){
                channel->setLogo(channelList[i].logoUrl);
            }else{
                channel->setLogo("");
            }
            m_ctxSxmStationList->appendData(channel);
        }
    }
    m_ctxSxmStationList->onDataReady();
}

void SpeechAdapter::onEventSdarsTeam()
{
    if(nullptr != m_teamListModel){
        SPEECH_SDARS_TEAM_DATA teamList = DataController::instance()->getSpeechSdarsTeamData();
        m_teamListModel->reset();

        for(int i = 0; i < teamList.count; i++) {
            TeamPtr team = std::make_shared<TeamElement>();
            team->setName(teamList.teams[i].name);
            team->setlogoUrl(teamList.teams[i].logoUrl);
            team->setId(teamList.teams[i].id);
            m_teamListModel->appendData(team);
        }
        m_teamListModel->onDataReady();
        LOGI().writeFormatted("[SpeechAdapter::onEventSdarsTeam]Size[%d]", teamList.count);
    }else{
        LOGI().writeFormatted("[SpeechAdapter::onEventSdarsTeam]ListModel is null");
    }
}

void SpeechAdapter::onEventSdarsDataChannel()
{
    LOGI().writeFormatted("[SpeechAdapter::onEventSdarsDataChannel]");
    if (m_ctxSxmStationList == nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onEventSdarsDataChannel]m_ctxSxmStationList is NULL");
        return;
    }
    int lengthName = 0;
    int isLogo = 0;

    QList<CHANNEL_INFORMATION_T>& channelList = DataController::instance()->getSpeechDataChannel();
    m_ctxSxmStationList->reset();

    LOGI().writeFormatted("[SpeechAdapter::onEventSdarsDataChannel]Size[%d]", channelList.size());
    for(int i = 0; i < channelList.size(); i++) {
        lengthName = QString(channelList[i].name).length();
        isLogo = QFile::exists(channelList[i].logoUrl);
        if (lengthName > 0){
            ChannelElementPtr channel = std::make_shared<ChannelElements>();
            channel->setName(channelList[i].name);
            if(isLogo == true){
                channel->setLogo(channelList[i].logoUrl);
            }else{
                channel->setLogo("");
            }
            channel->setId(channelList[i].id);
//            channel->setId("10000000");
            LOGI().writeFormatted("[========Id: %s",channelList[i].id);
            m_ctxSxmStationList->appendData(channel);
        }
    }
    m_ctxSxmStationList->onDataReady();
}

void SpeechAdapter::onEventSdarsCategorySatList()
{
    LOGI().writeFormatted("[SpeechAdapter::onEventSdarsCategorySatList]");
    SPEECH_SDARS_CATEGORY_LIST category = DataController::instance()->getSpeechCategorySatList();

    if (m_ctxSxmCategories == nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onEventSdarsCategorySatList]m_ctxSxmCategories: is NULL");
        return;
    }
    m_ctxSxmCategories->reset();
    for (int i = 0; i < category.count; i++){
        QString name = QString(category.name[i]);
        QString logo = QString(category.logo[i]);
        int32_t id = category.nCategoryID;
        int lengthName = name.length();
        bool logoExist = QFile::exists(logo);
        if(lengthName > 0){
            CategoryElementsPtr categoriesInfo = std::make_shared<CategoryElements>();
            categoriesInfo->setCategoryName(name);
            categoriesInfo->setCategoryId(id);
            if(logoExist){
                categoriesInfo->setCategoryLogo(logo);
            }
            m_ctxSxmCategories->appendData(categoriesInfo);
        }
        m_ctxSxmCategories->onDataReady();
    }
}

void SpeechAdapter::onEventSdarsCategoryChannel()
{
    if (m_ctxSxmStationList == nullptr) {
        LOGI().writeFormatted("[SpeechAdapter::onEventSdarsCategoryChannel]m_ctxSxmStationList is NULL");
        return;
    }
    int lengthName = 0;
    int lengthshortDescription = 0;
    int isLogo = 0;

    QList<CHANNEL_INFORMATION_T> &channelList = DataController::instance()->getSpeechDataChannel();
    m_ctxSxmStationList->reset();

    LOGI().writeFormatted("[SpeechAdapter::onEventSdarsCategoryChannel]Size[%d]", channelList.size());
    for(int i = 0; i < channelList.size(); i++) {
        lengthName = QString(channelList[i].name).length();
        lengthshortDescription = QString(channelList[i].shortDescription).length();
        isLogo = QFile::exists(channelList[i].logoUrl);

        if ((lengthName > 0) && (lengthshortDescription > 0)){
            ChannelElementPtr channel = std::make_shared<ChannelElements>();
            channel->setName(channelList[i].name);
            channel->setNumber(channelList[i].number);
            channel->setShortDescription(channelList[i].shortDescription);
            channel->setIsFavorite(channelList[i].isFavorite);
            channel->setContextualBanner(channelList[i].show.contextualBanner);
            channel->setIsAvailable(channelList[i].isAvailable);
            channel->setIsNowPlaying(channelList[i].isNowPlaying);
            channel->setSportState(static_cast<UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE>(channelList[i].sports.state));
            if(isLogo == true){
                channel->setLogo(channelList[i].logoUrl);
            }else{
                channel->setLogo("");
            }
            m_ctxSxmStationList->appendData(channel);
        }
    }
    m_ctxSxmStationList->onDataReady();
}

void SpeechAdapter::onEventSpeechModeListCurrentIndexChanged()
{
    int currentIndex = DataController::instance()->getData(DataIdentifier::E_DATA_IDENTIFIER_SPEECH_MODE_LIST_CURRENT_INDEX).toInt();
    if (m_ctxSxmVideoTunerListShow != nullptr){
        if (m_latestCommand == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_CATEGORY_SAT) || m_latestCommand == SPEECHCOMMAND(SYSTEM_VIDEO_TUNER_STATION_SAT)){
            m_ctxSxmVideoTunerListShow->setCurrentIndex(currentIndex);
            int numElements = m_ctxSxmVideoTunerListShow->rowCount();
            int remainElements = numElements - currentIndex;
            LOGI().writeFormatted("[SpeechAdapter::onEventSpeechModeListCurrentIndexChanged]Remain[%d][%d]", remainElements, numElements);
            setProperty("list_index_component", "countItem", remainElements > LIST_PAGE_ITEM_NUMBER ? LIST_PAGE_ITEM_NUMBER : remainElements);
        }
    }
}

void SpeechAdapter::clearAllList()
{
    if (m_ctxSxmStationList != nullptr){
        m_ctxSxmStationList->reset();
    }
    if (m_ctxSxmVideoTunerListShow != nullptr){
        m_ctxSxmVideoTunerListShow->reset();
    }
    if (m_teamListModel != nullptr){
        m_teamListModel->reset();
    }
}

