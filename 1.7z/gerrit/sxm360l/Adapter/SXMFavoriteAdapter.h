#ifndef SXMFAVORITEADAPTER_H
#define SXMFAVORITEADAPTER_H

#include <QObject>
#include "BaseAdapter.h"
#include "FavoritesListModel.h"
#include "ChannelElements.h"
class SXMFavoriteAdapter : public BaseAdapter
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SXMFavoriteAdapter();
    virtual ~SXMFavoriteAdapter();
protected:
//    void createConnect2Interface();
    //Register notify
    void registerNotifiedDpId();
    //Update data for current screen
    void onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid);
    //Initialize data for screen
    void initializeScreen();
    void onEventScreenChanged();
    void onEventFavoritesChanged();
    void onEventChannelInfomation();
    void onEventAddCurrentFavorite();
    void onEventRemoveCurrentFavorite();
private:
    void setChannelInfomation(CHANNEL_INFORMATION_T& channelInfomation);
    ChannelElements* m_ctxSxmChannelElements;
    FavoritesListModel *m_ctxFavoritesListModel;
};

#endif // SXMFAVORITEADAPTER_H
