#ifndef SCREENFACTORY_H
#define SCREENFACTORY_H

#include "Common/SingletonHmi.h"
#include "SXMBrowsersAdapter.h"
#include "SXMFavoriteAdapter.h"
#include "SXMPlayerAdapter.h"
#include "ScreenIdentifier.h"
#include <QQuickView>
#include "Common/SXMDefine.h"
#include "SXMForYouAdapter.h"
#include "SXMSettingsAdapter.h"
#include "SXMSearchAdapter.h"
#include "SpeechAdapter.h"

class ScreenFactory : public SingletonHmi<ScreenFactory>
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
public:
    static ScreenFactory* instance();
    bool initializeAdapter(QQuickView *view);
    bool setCurrentQQuickView(QQuickView *view);

    BaseAdapter *getAdapter(int screenId);
protected:
    virtual ~ScreenFactory();
private:
    friend class SingletonHmi<ScreenFactory>;
    ScreenFactory();
    bool isBrowsersScreen(int screenId);
    bool isFavoriteScreen(int screenId);
    bool isForYouScreen(int screenId);
    bool isPlayerScreen(int screenId);
    bool isSearchScreen(int screenId);
    bool isSettingsScreen(int screenId);
    bool isSpeechScreen(int screenId);

    void lockNonActiveAdapters(BaseAdapter *activeHandler);

    SXMBrowsersAdapter  *m_sxmBrowsersAdapter;
    SXMFavoriteAdapter  *m_sxmFavoriteAdapter;
    SXMPlayerAdapter    *m_sxmPlayerAdapter;
    SXMForYouAdapter    *m_sxmForYouAdapter;
    SXMSettingsAdapter  *m_sxmSettingsAdapter;
    SXMSearchAdapter    *m_sxmSearchAdapter;
    SpeechAdapter       *m_speechAdapter;
    QList<BaseAdapter*> m_listAdapters;
};

#endif // SCREENFACTORY_H


