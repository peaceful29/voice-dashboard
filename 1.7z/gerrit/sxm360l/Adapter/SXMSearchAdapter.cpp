#include "SXMSearchAdapter.h"
#include "ScreenList.h"
#include "DataExchange/DataController.h"
#include "Common/ResourceManager.h"
#include "UIBridge.h"
#include "DataExchange/SXMKeyPadHandler.h"
#include "Adapter/ScreenFactory.h"

SXMSearchAdapter::SXMSearchAdapter() : BaseAdapter(SXM_SEARCH_ADAPTER)
{
    registerNotifiedDpId();
}

SXMSearchAdapter::~SXMSearchAdapter()
{
}

void SXMSearchAdapter::registerNotifiedDpId()
{
    LOGI().writeFormatted("[SXMForYouAdapter::registerNotifiedDpId]");
    QVector<DataIdentifier::E_EVENT_NOTIFIER> notifiedEvent;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNELS;
//    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION;

    registerNotifier(notifiedEvent);
}

void SXMSearchAdapter::onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid)
{
    LOGI().writeFormatted("[SXMForYouAdapter::onDataChanged]");
    switch (eventid) {
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNELS:
        onEventGetAllChannels();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION:
//        request2ChangeScreen(ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER);
        onEventChannelInfomation();
        break;
    default:
        break;
    }
}

void SXMSearchAdapter::initializeScreen()
{
    LOGI().writeFormatted("SXMSearchAdapter:: initializeScreen Called");
}

void SXMSearchAdapter::onEventScreenChanged()
{
    LOGI().writeFormatted("SXMSearchAdapter:: onEventScreenChanged Called");

}

void SXMSearchAdapter::onEventGetAllChannels()
{
    LOGI().writeFormatted("SXMSearchAdapter:: onEventGetAllChannels Called");
}

void SXMSearchAdapter::onEventChannelInfomation(){
    BaseAdapter *adapter = ScreenFactory::instance()->getAdapter(ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER);
    if (adapter != nullptr){
        LOGI().writeFormatted("[SXMAppMain::onScreenReady][%s]onForeground", adapter->name().toStdString().c_str());
        adapter->onEventScreenReady(ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER);
    }
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_HIDE_KEYBOARD, "0");
}

