#include "SXMBrowsersAdapter.h"
#include "ScreenList.h"
#include "DataExchange/DataController.h"
#include "QmlModel/SuperCategoryElements.h"
#include "QmlModel/CategoryElements.h"
#include "QmlModel/ChannelElements.h"
#include "Common/ResourceManager.h"
#include "SXMDefine.h"
#include "UIBridge.h"
#include "QFile"
#include "SportInformationElement.h"

SXMBrowsersAdapter::SXMBrowsersAdapter() : BaseAdapter(SXM_BROWSERS_ADAPTER)
  , m_ctxSxmSuperCategories(nullptr)
  , m_ctxSxmCategories(nullptr)
  , m_ctxSxmLiveChannels(nullptr)
  , m_ctxSxmTeams(nullptr)
  , m_currentCategory("")
  , m_currentSuperCategory("")
//  , m_ctxSxmSportInformationElements(nullptr)
//  , m_ctxSxmSportChannels(nullptr)
{
//    createConnect2Interface();
    registerNotifiedDpId();
}

SXMBrowsersAdapter::~SXMBrowsersAdapter()
{
    SafeDelete<SuperCategoryListModel>(m_ctxSxmSuperCategories);
    SafeDelete<CategoryListModel>(m_ctxSxmCategories);
    SafeDelete<ChannelListModel>(m_ctxSxmLiveChannels);
    SafeDelete<TeamListModel>(m_ctxSxmTeams);
//    SafeDelete<TeamListModel>(m_ctxSxmSportInformationElements);
//    SafeDelete<SportInformationListModel>(m_ctxSxmSportChannels);
}

void SXMBrowsersAdapter::registerNotifiedDpId()
{
    QVector<DataIdentifier::E_EVENT_NOTIFIER> notifiedEvent;
    //register DPid for super category
    LOGI().writeFormatted("[SXMBrowsersAdapter::registerNotifiedDpId]");
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SUPERCATEGORY;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CATEGORIES;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNELS;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_ON_CMD_GO_BACK;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_HIDE_SYSTEM_COMPONENT;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_FAVORITE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_FAVORITE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_TEAMS;
    registerNotifier(notifiedEvent);
}

void SXMBrowsersAdapter::onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid)
{
//    LOGI().writeFormatted("[RadioAnalogStationAdapter::onDataChanged]Event[%d]Lock[%s]", eventid, base::bool2string(m_lockStatus));
    LOGI().writeFormatted("[SXMBrowsersAdapter::onDataChanged]");
    switch (eventid) {
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SUPERCATEGORY:
        onEventSuperCategory();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CATEGORIES:
        onEventCategories();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNELS:
        onEventLiveChannels();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_ON_CMD_GO_BACK:
        onGoBackScreen();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_HIDE_SYSTEM_COMPONENT:
        onHideSystemComponent();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION:
        onEventChannelInfomation();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_FAVORITE:
        onEventAddFavorite();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_FAVORITE:
        onEventRemoveFavorite();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_TEAMS:
        onEventGetTeams();
        break;
    default:
        break;
    }
}

void SXMBrowsersAdapter::initializeScreen()
{
    LOGI().writeFormatted("SXMBrowsersAdapter:: initializeScreen Called");
    //Check the screen and request data
    const uint32_t currentScreenId = ScreenListInstance()->getCurrentScreenID();
    switch (currentScreenId) {
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_SUPER_CATEGORIES:
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_CATEGORIES:
        LOGI().writeFormatted("[SXMBrowsersAdapter::initializeScreen]SXM Super Category: %d", currentScreenId);
        DELETE_PTR(m_ctxSxmSuperCategories);
        m_ctxSxmSuperCategories = new SuperCategoryListModel();
        DELETE_PTR(m_ctxSxmCategories);
        m_ctxSxmCategories = new CategoryListModel();
        m_currentSuperCategory = "";

        if (m_rootContext != nullptr) {
            m_rootContext->setContextProperty("ctxSuperCategoryModel", m_ctxSxmSuperCategories);
            m_rootContext->setContextProperty("ctxCategoriesModel", m_ctxSxmCategories);
            m_rootContext->setContextProperty("currentSuperCategory", m_currentSuperCategory);
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_LIVE_CHANNEL:
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_SPORTS_PLAY_BY_PLAY:
        DELETE_PTR(m_ctxSxmLiveChannels);
//        DELETE_PTR(m_ctxSxmSportInformationElements);
//        m_ctxSxmSportInformationElements = new SportInformationElement();
        m_ctxSxmLiveChannels = new ChannelListModel();
        m_currentCategory = "";

        if (m_rootContext != nullptr) {
            m_rootContext->setContextProperty("ctxLiveChannelModel", m_ctxSxmLiveChannels);
//            m_rootContext->setContextProperty("ctxSxmSportInformationElements", m_ctxSxmSportInformationElements);
            m_rootContext->setContextProperty("currentCategory", m_currentCategory);
        }
        break;

    default:
        break;
    }
}

void SXMBrowsersAdapter::onEventScreenChanged()
{

}

void SXMBrowsersAdapter::onEventSuperCategory()
{
    bool isMusic = false;
    bool superCategoryExist = false;

    if (m_ctxSxmSuperCategories == nullptr) {
        LOGI().writeFormatted("HopND -- [SXMBrowsersAdapter::onEventSuperCategory ]m_ctxSxmSuperCategories: is NULL");
        return;
    }
    m_currentSuperCategory = ResourceManager::instance()->getCurrentSuperCategory();

    SUPER_CATEGORY_LIST_T &superCategoryList = DataController::instance()->getSuperCategorList();
    LOGI().writeFormatted("[SXMBrowsersAdapter::superCategoryList count: %d]: Called", superCategoryList.count);
    m_ctxSxmSuperCategories->reset();

    for(unsigned int i = 0; i < superCategoryList.count; i++) {
        SuperCategoryElementsPtr superCategory = std::make_shared<SuperCategoryElements>();
        superCategory->setSuperCategoryName(superCategoryList.name[i]);
        if(!(QString(superCategoryList.name[i]).compare("Music")) && isMusic == false){
            isMusic = true;
        }
        if (m_currentSuperCategory == superCategoryList.name[i]) {
            superCategory->setIsCurrent(true);
            superCategoryExist = true;
        } else {
            superCategory->setIsCurrent(false);
        }
        m_ctxSxmSuperCategories->appendData(superCategory);
    }
    m_ctxSxmSuperCategories->onDataReady();

    if((!m_currentSuperCategory.compare("")) && isMusic) {
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CATEGORIES, "Music");
    }
    else if(superCategoryExist) {
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CATEGORIES, m_currentSuperCategory);
    }
    else {
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CATEGORIES, superCategoryList.name[0]);
    }
}

void SXMBrowsersAdapter::onEventCategories()
{
    int length = 0;
    int isLogo = 0;
    m_currentSuperCategory = ResourceManager::instance()->getCurrentSuperCategory();
    if (m_ctxSxmCategories == nullptr) {
        LOGI().writeFormatted("HopND -- [SXMBrowsersAdapter::onEventCategories ]m_ctxSxmCategories: is NULL");
        return;
    }
    m_ctxSxmCategories->reset();
    CATEGORY_LIST_T &categoriesList = DataController::instance()->getCategoryList();

    for(unsigned int i = 0; i < categoriesList.count; i++) {
        length = QString(categoriesList.name[i]).length();
        isLogo = QFile::exists(categoriesList.logo[i]);
        if(length > 0){
            CategoryElementsPtr categoriesInfo = std::make_shared<CategoryElements>();
            categoriesInfo->setCategoryName(categoriesList.name[i]);
            if(isLogo){
                categoriesInfo->setCategoryLogo(categoriesList.logo[i]);
            }
            m_ctxSxmCategories->appendData(categoriesInfo);
        }
    }
    m_ctxSxmCategories->onDataReady();
    if (m_ctxSxmSuperCategories == nullptr) {
        LOGI().writeFormatted("HopND -- [SXMBrowsersAdapter::onEventCategories]m_ctxSxmSuperCategories: is NULL");
        return;
    }
    for (int i = 0; i < m_ctxSxmSuperCategories->rowCount(); i++) {
        SuperCategoryElements* element = dynamic_cast<SuperCategoryElements*>(m_ctxSxmSuperCategories->getElement(i));
        if (ResourceManager::instance()->getCurrentSuperCategory() == element->superCategoryName()){
            m_ctxSxmSuperCategories->updateData(i, E_SUPER_CATEGORIES_LIST_ROLES_IS_CURRENT, QVariant::fromValue(true));
        } else {
            m_ctxSxmSuperCategories->updateData(i, E_SUPER_CATEGORIES_LIST_ROLES_IS_CURRENT, QVariant::fromValue(false));
        }

//        if (!(element->superCategoryName().compare("Sports"))){
//            DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_LEAGUES, "");
//        }
    }
    m_ctxSxmSuperCategories->onDataReady();
}

void SXMBrowsersAdapter::onEventLiveChannels()
{
    int lengthName = 0;
    int lengthshortDescription = 0;
    bool isLogo = false;
    bool isPlaybyPlay = false;
     isPlaybyPlay = ScreenListInstance()->getCurrentScreenID() == ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_SPORTS_PLAY_BY_PLAY;

    if (m_ctxSxmLiveChannels == nullptr) {
        LOGI().writeFormatted("HopND -- [SXMBrowsersAdapter::onEventLiveChannels]m_ctxSxmLiveChannels: is NULL");
        return;
    }
    QList<CHANNEL_INFORMATION_T> &channelList = DataController::instance()->getLstChannelInformation();
    m_ctxSxmLiveChannels->reset();
    LOGI().writeFormatted("HopND -- [SXMBrowsersAdapter::onEventLiveChannels] SIZE [%d]", channelList.size());

    for(int i = 0; i < channelList.size(); i++) {
        lengthName = QString(channelList[i].name).length();
        lengthshortDescription = QString(channelList[i].shortDescription).length();
        isLogo = QFile::exists(channelList[i].logoUrl);

        if (i == 0){
            m_currentCategory = channelList[0].category;
        }
        if ((lengthName > 0) && (lengthshortDescription > 0)){
            ChannelElementPtr channel = std::make_shared<ChannelElements>();
            channel->setName(channelList[i].name);
            channel->setNumber(channelList[i].number);
            channel->setShortDescription(channelList[i].shortDescription);
            channel->setIsFavorite(channelList[i].isFavorite);
            channel->setContextualBanner(channelList[i].show.contextualBanner);
            channel->setIsAvailable(channelList[i].isAvailable);
//            channel->setIsAvailable(true);
            channel->setIsNowPlaying(channelList[i].isNowPlaying);
            if (isPlaybyPlay){
                channel->setSportState(static_cast<UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE>(channelList[i].sports.state));
                LOGI().writeFormatted("HopND -- [SXMBrowsersAdapter::onEventLiveChannels]STATE %d", channelList[i].sports.state);
            }
            if(isLogo){
                channel->setLogo(channelList[i].logoUrl);
            }
            else{
                channel->setLogo("");
            }
            if (channelList[i].isNowPlaying) {
                setProperty("gridviewRoot", "currentIndex", i);
            }
            m_ctxSxmLiveChannels->appendData(channel);
        }
    }
    m_ctxSxmLiveChannels->onDataReady();
}

void SXMBrowsersAdapter::onGoBackScreen()
{
    LOGI().writeFormatted("HOPND--> [SXMBrowsersAdapter::onGoBackScreen]: Called");
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TO_HIDE_SYSTEM_COMPONENT, "31,3, ");
}

void SXMBrowsersAdapter::onHideSystemComponent()
{
    QObject* item = nullptr;

    int currentScreenId = ScreenListInstance()->getCurrentScreenID();
    if(ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_LIVE_CHANNEL == currentScreenId){
        item = findChild("sxm_browser_live_channel");
    }
    else if(ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_SPORTS_PLAY_BY_PLAY == currentScreenId){
        item = findChild("sxm_browser_Sports_Play_By_Play");
    }
    else{
        //do nothing
    }
    if (item != nullptr) {
        uint32_t previousScreenId = getScreenIdForBack();
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CATEGORIES, m_currentSuperCategory);
        QMetaObject::invokeMethod(item, "requestToChangeScreen",
                                  Q_ARG(QVariant, previousScreenId));
//                                  Q_ARG(QVariant,ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_CATEGORIES));
    }
}

void SXMBrowsersAdapter::onEventChannelInfomation()
{
    LOGI().writeFormatted("[SXMPlayerAdapter::onEventChannelInfomation]: ScreenListInstance()->getCurrentScreenID() %d", ScreenListInstance()->getCurrentScreenID());
    updateChannelData(m_ctxSxmLiveChannels, E_CHANNELS_LIST_ROLES_IS_NOWPLAYING);

    if (16391 == ScreenListInstance()->getCurrentScreenID()) {
        CHANNEL_INFORMATION_T &channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
        QObject* item = nullptr;
        item = findChild("sxm_browser_Sports_Play_By_Play");
        if ((channelInfo.sports.state == UIBridge::E_HMI_EVENT_SPORTS_PREGAME)
                || (channelInfo.sports.state == UIBridge::E_HMI_EVENT_SPORTS_INPROGRESS)
                || (channelInfo.sports.state == UIBridge::E_HMI_EVENT_SPORTS_FINAL)) {
            QMetaObject::invokeMethod(item, "requestToChangeScreen",
                                      Q_ARG(QVariant, ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_PLAY_BY_PLAY));
        }
        else if (channelInfo.sports.state == UIBridge::E_HMI_EVENT_SPORTS_SCHEDULED) {
            QMetaObject::invokeMethod(item, "requestToChangeScreen",
                                      Q_ARG(QVariant, ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPORTS_PLAY_BY_PLAY_SCHEDULED));
        }
        else if (channelInfo.sports.state == UIBridge::E_HMI_EVENT_SPORTS_RESCHEDULED) {
            QMetaObject::invokeMethod(item, "requestToChangeScreen",
                                      Q_ARG(QVariant, ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPORTS_PLAY_BY_PLAY_RESCHEDULED));
        }
        else{
            LOGI().writeFormatted("[SXMPlayerAdapter::onEventChannelInfomation]: NOTHING");
        }
    }

}

void SXMBrowsersAdapter::onEventAddFavorite()
{
    updateChannelData(m_ctxSxmLiveChannels, E_CHANNELS_LIST_ROLES_IS_FAVORITE, true);
}
void SXMBrowsersAdapter::onEventRemoveFavorite()
{
    updateChannelData(m_ctxSxmLiveChannels, E_CHANNELS_LIST_ROLES_IS_FAVORITE, false);
}

void SXMBrowsersAdapter::onEventGetTeams()
{
    if(nullptr != m_ctxSxmTeams){
        SPORTS_TEAM_T & teamList = DataController::instance()->getSportTeams();
        m_ctxSxmTeams->reset();

        for(int i = 0; i < teamList.count; i++) {
            TeamPtr team = std::make_shared<TeamElement>();
            team->setName(teamList.teams[i].name);
            team->setlogoUrl(teamList.teams[i].logoUrl);
            team->setId(teamList.teams[i].id);
            m_ctxSxmTeams->appendData(team);
        }
        m_ctxSxmTeams->onDataReady();
    }
}
