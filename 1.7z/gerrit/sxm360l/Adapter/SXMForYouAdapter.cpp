#include "SXMForYouAdapter.h"
#include "ScreenList.h"
#include "DataExchange/DataController.h"
#include "Common/ResourceManager.h"
#include "UIBridge.h"
#include "RecommendedElement.h"

SXMForYouAdapter::SXMForYouAdapter() : BaseAdapter(SMX_FOR_YOU_ADAPTER)
  , m_ctxSxmRecommendChannels(nullptr)
  , m_ctxSxmHistoryListenChannel(nullptr)
{
    registerNotifiedDpId();
}

SXMForYouAdapter::~SXMForYouAdapter()
{
    SafeDelete<RecommendedListModel>(m_ctxSxmRecommendChannels);
    SafeDelete<ChannelListModel>(m_ctxSxmHistoryListenChannel);
}

void SXMForYouAdapter::registerNotifiedDpId()
{
    LOGI().writeFormatted("[SXMForYouAdapter::registerNotifiedDpId]");
    QVector<DataIdentifier::E_EVENT_NOTIFIER> notifiedEvent;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_RECOMMENDATION;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_LISTEN_HISTORY;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SHOW_SYSTEM_COMPONENT;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_HIDE_SYSTEM_COMPONENT;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_ON_CMD_GO_BACK;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_FAVORITE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_FAVORITE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION;
    registerNotifier(notifiedEvent);
}

void SXMForYouAdapter::onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid)
{
    LOGI().writeFormatted("[SXMForYouAdapter::onDataChanged]");
    switch (eventid) {
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_RECOMMENDATION:
        onRecommendChannels();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_HIDE_SYSTEM_COMPONENT:
        onHideSystemComponent();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_ON_CMD_GO_BACK:
        onGoBackScreen();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SHOW_SYSTEM_COMPONENT:
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_FAVORITE:
        onEventAddFavorite();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_FAVORITE:
        onEventRemoveFavorite();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION:
        onEventChannelInfomation();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_LISTEN_HISTORY:
        onEventListenHistory();
        break;
    default:
        break;
    }
}

void SXMForYouAdapter::initializeScreen()
{
    LOGI().writeFormatted("SXMForYouAdapter:: initializeScreen Called");
    //Check the screen and request data
    const uint32_t currentScreenId = ScreenListInstance()->getCurrentScreenID();
    switch (currentScreenId) {
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECOMMENDATION:
//        LOGI().writeFormatted("[SXMForYouAdapter::initializeScreen] current screen id: %d", currentScreenId);
        DELETE_PTR(m_ctxSxmRecommendChannels);
        m_ctxSxmRecommendChannels = new RecommendedListModel();
        if (m_rootContext != nullptr) {
            m_rootContext->setContextProperty("ctxRecomendChannelsModel", m_ctxSxmRecommendChannels);
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECENT_HISTORY:
//        LOGI().writeFormatted("[SXMForYouAdapter::initializeScreen] current screen id: %d", currentScreenId);
        DELETE_PTR(m_ctxSxmHistoryListenChannel);
        m_ctxSxmHistoryListenChannel = new ChannelListModel();
        if (m_rootContext != nullptr) {
            m_rootContext->setContextProperty("ctxHistoryListenChannelsModel", m_ctxSxmHistoryListenChannel);
        }
        break;
    default:
        break;
    }
}

void SXMForYouAdapter::onEventScreenChanged()
{

}

void SXMForYouAdapter::onRecommendChannels()
{
    int lengthName = 0;
//    int lengthshortDescription = 0;
    bool isLogo = false;
    if (m_ctxSxmRecommendChannels == nullptr) {
        LOGI().writeFormatted("[SXMForYouAdapter::onEventChannels]m_ctxSxmRecommendChannels: is NULL");
        return;
    }
    QList<CHANNEL_INFORMATION_T> &recommenedlList = DataController::instance()->getRecommendationList();
    m_ctxSxmRecommendChannels->reset();
    LOGI().writeFormatted("[SXMForYouAdapter::onRecommendChannels]SIZE: %d", recommenedlList.size());

    for(int i = 0; i < recommenedlList.size(); i++) {
        RecommendedElementPtr channel = std::make_shared<RecommendedElement>();
        isLogo = QFile::exists(recommenedlList[i].logoUrl);
        lengthName = QString(recommenedlList[i].name).length();
        if(isLogo){
            channel->setLogo(recommenedlList[i].logoUrl);
        }
        else{
            channel->setLogo("");
        }

        if(isLogo == true || lengthName > 0){
            channel->setLogo(recommenedlList[i].logoUrl);
            channel->setShortDes(recommenedlList[i].shortDescription);
            channel->setNumber(recommenedlList[i].number);
            channel->setName(recommenedlList[i].name);
            channel->setCategory(recommenedlList[i].category);
            channel->setIsFavorite(recommenedlList[i].isFavorite);
            channel->setIsNowPlaying(recommenedlList[i].isNowPlaying);
            channel->setMediumTitle(recommenedlList[i].show.mediumTitle);
            channel->setLongTitle(recommenedlList[i].show.longTitle);
            channel->setShowGui(recommenedlList[i].show.showGUID);
            channel->setProgramType(recommenedlList[i].show.programType);
            channel->setAudioEpisode(recommenedlList[i].show.audioOnDemandEpisodeCount);
            channel->setVideoEpisode(recommenedlList[i].show.videoOnDemandEpisodeCount);
            channel->setNewEpisodeCount(recommenedlList[i].show.onDemandNewEpisodeCount);
            channel->setContextual(recommenedlList[i].show.contextualBanner);

            channel->setIsMature(recommenedlList[i].show.isMature);
            if (recommenedlList[i].isNowPlaying) {
                LOGI().writeFormatted("[SXMForYouAdapter::onEventListenHistory]NUMBER: %d", recommenedlList[i].number);
            }

            m_ctxSxmRecommendChannels->appendData(channel);
        }
    }
    m_ctxSxmRecommendChannels->onDataReady();
}

void SXMForYouAdapter::onGoBackScreen()
{
//    LOGI().writeFormatted("SXMForYouAdapter::onGoBackScreen()");
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TO_HIDE_SYSTEM_COMPONENT,
                                                   "31,3, ");
}

void SXMForYouAdapter::onHideSystemComponent()
{
    QObject* item = nullptr;
    uint32_t currentScreenId = ScreenList::getInstance()->getCurrentScreenID();

    if(currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECOMMENDATION){
        item = findChild("sxm_foryou_recomendations");
    }
    else{
        item = findChild("sxm_foryou_history_listen");
    }

    if (item != nullptr) {
        uint32_t previousScreenId = getScreenIdForBack();
        QMetaObject::invokeMethod(item, "requestToChangeScreen",
                                  Q_ARG(QVariant, previousScreenId));
    }
}

void SXMForYouAdapter::onEventAddFavorite()
{
    int currentScreenId = ScreenListInstance()->getCurrentScreenID();
    if(currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECOMMENDATION){
        updateChannelData(m_ctxSxmRecommendChannels, E_CHANNELS_LIST_ROLES_IS_FAVORITE, true);
    }
    else if(currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECENT_HISTORY){
        updateChannelData(m_ctxSxmHistoryListenChannel, E_CHANNELS_LIST_ROLES_IS_FAVORITE, true);
    }
    else{
        // Do nothing
    }
}

void SXMForYouAdapter::onEventRemoveFavorite()
{
    int currentScreenId = ScreenListInstance()->getCurrentScreenID();
    if(currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECOMMENDATION){
        updateChannelData(m_ctxSxmRecommendChannels, E_CHANNELS_LIST_ROLES_IS_FAVORITE, false);
    }
    else if(currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECENT_HISTORY){
        updateChannelData(m_ctxSxmHistoryListenChannel, E_CHANNELS_LIST_ROLES_IS_FAVORITE, false);
    }
    else{
        // Do nothing
    }
}

void SXMForYouAdapter::onEventChannelInfomation()
{
    int currentScreenId = ScreenListInstance()->getCurrentScreenID();

    if(currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECOMMENDATION){
        LOGI().writeFormatted("[SXMForYouAdapter::onEventListenHistory]onEventChannelInfomation: is Called");
        updateChannelData(m_ctxSxmRecommendChannels, E_RECOMMENDED_NOWPLAYING);
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_RECOMMENDATION, "");
    }
    else if(currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECENT_HISTORY){
//        updateChannelData(m_ctxSxmHistoryListenChannel, E_CHANNELS_LIST_ROLES_IS_NOWPLAYING);
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_LISTENING_HISTORY, "");
    }
    else{
        // Do nothing
    }
}

void SXMForYouAdapter::onEventListenHistory()
{
    int lengthName = 0;
    int lengthshortDescription = 0;
    int isLogo = 0;
    if (m_ctxSxmHistoryListenChannel == nullptr) {
        LOGI().writeFormatted("[SXMForYouAdapter::onEventListenHistory]m_ctxSxmHistoryListenChannel: is NULL");
        return;
    }
    LIVE_CHANNEL_LIST_T &channelList = DataController::instance()->getHistoryList();
    m_ctxSxmHistoryListenChannel->reset();
    for(int i = 0; i < channelList.packetTotal; i++) {
        lengthName = QString(channelList.channel[i].name).length();
        lengthshortDescription = QString(channelList.channel[i].shortDescription).length();
        isLogo = QFile::exists(channelList.channel[i].logoUrl);

        if ((lengthName > 0 || isLogo == 0) && lengthshortDescription > 0){
            ChannelElementPtr channel = std::make_shared<ChannelElements>();
            channel->setName(channelList.channel[i].name);
            channel->setLogo(channelList.channel[i].logoUrl);
            channel->setShortDescription(channelList.channel[i].shortDescription);
            channel->setIsFavorite(channelList.channel[i].isFavorite);
            channel->setIsNowPlaying(channelList.channel[i].isNowPlaying);
            channel->setContextualBanner(channelList.channel[i].show.contextualBanner);
            channel->setIsAvailable(channelList.channel[i].isAvailable);
            channel->setNumber(channelList.channel[i].number);

            m_ctxSxmHistoryListenChannel->appendData(channel);
        }
    }
    m_ctxSxmHistoryListenChannel->onDataReady();
}
