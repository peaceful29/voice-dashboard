#ifndef BASEADAPTER_H
#define BASEADAPTER_H

#include <QObject>
#include <QQuickItem>
#include <QQmlContext>
#include "ScreenList.h"
#include "sxm360l/Sxm360lMsgDef.h"

#include "DataExchange/DataHandler.h"
#include "BaseListModel.h"

class SxmServiceInterface;

class BaseAdapter : public DataHandler
{
	LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    explicit BaseAdapter(QString name);
    virtual ~BaseAdapter();
    void resetRootObject(QQmlContext *rootContext, QQuickItem *rootObject);
    QString name();
    void onEventScreenReady(int screenId);
    virtual void onEventScreenChanged() = 0;
protected:
//    virtual void createConnect2Interface() = 0;
    bool setProperty(QString objectName, QString property, const QVariant variant);
    QObject *findChild(QString objectName);
    void request2ChangeScreen(int screenID);
    virtual void initializeScreen() = 0;
    BaseAdapter* adapter(QString name);
    void updateChannelData(BaseListModel *baseListModel, int role, bool value);
    void updateChannelData(BaseListModel *baseListModel, int role);
    uint32_t getScreenIdForBack();

    QString m_name;
    QQmlContext *m_rootContext;
    QQuickItem *m_rootObject;
    SxmServiceInterface *m_sxmServiceInterface;

private:
    std::map<QString, BaseAdapter*> m_registerAdapter;
};

#endif // BASEADAPTER_H
