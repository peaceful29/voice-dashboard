#include <QTimer>
#include "SXMPlayerAdapter.h"
#include "ScreenList.h"
#include "DataExchange/DataController.h"
#include "DataExchange/SXMKeyPadHandler.h"
#include "ResourceManager.h"
#include "UIBridge.h"

SXMPlayerAdapter::SXMPlayerAdapter(): BaseAdapter(SXM_PLAYER_ADAPTER)
  , m_ctxSxmChannelElements(nullptr)
  , m_ctxSxmChannelModel(nullptr)
//  , m_ctxSxmTeamLeft(nullptr)
//  , m_ctxSxmTeamRight(nullptr)
  , m_ctxSxmSportInformationElements(nullptr)
  , m_currentIndexLinearTune(0)
  , m_isNoSignal(false)
{
    m_ctxSxmChannelElements = new ChannelElements();
    m_ctxSxmSportInformationElements = new SportInformationElement();
    registerNotifiedDpId();
    // timer
//    m_timerCountTimeoutLostSignal = new QTimer(this);
//    connect(m_timerCountTimeoutLostSignal, SIGNAL(timeout()), this, SLOT(funcTimeoutResumingSignal()));
}

SXMPlayerAdapter::~SXMPlayerAdapter()
{
    DELETE_PTR(m_ctxSxmChannelElements);
    DELETE_PTR(m_ctxSxmChannelModel);
    DELETE_PTR(m_timerCountTimeoutLostSignal);
//    DELETE_PTR(m_ctxSxmTeamLeft);
//    DELETE_PTR(m_ctxSxmTeamRight);
    DELETE_PTR(m_ctxSxmSportInformationElements);
}

void SXMPlayerAdapter::setChannelInfomation(CHANNEL_INFORMATION_T& channelInfomation)
{
    LOGI().writeFormatted("[SXMPlayerAdapter::setChannelInfomation] Called");
    if ((nullptr != m_ctxSxmChannelElements) && (m_rootContext != nullptr)){
        m_ctxSxmChannelElements->setValue(channelInfomation);
        m_rootContext->setContextProperty("ctxSxmChannelInfomation", m_ctxSxmChannelElements);

        if (channelInfomation.isNowPlaying){
            updateChannelData(m_ctxSxmChannelModel, E_CHANNEL_INFOMATION_ROLES_ISNOWPLAYING);
        }
    }
    else{
        LOGI().writeFormatted("[SXMPlayerAdapter::setChannelInfomation]: m_ctxSxmChannelElements is NULL");
    }
}

void SXMPlayerAdapter::funcTimeoutResumingSignal()
{
    if (ScreenListInstance()->getCurrentScreenID() != ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_RESUMING_SATELLITE) {
        LOGI().writeFormatted("Screen isn't [resuming satellite], don't need request screen [time out lost signal]");
        return;
    }
    LOGI().writeFormatted("Timeout to re-connect signals");
    onEventScreenReady(ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_AUDIO_TIMEOUT);
    m_timerCountTimeoutLostSignal->stop();
}

void SXMPlayerAdapter::registerNotifiedDpId()
{
    QVector<DataIdentifier::E_EVENT_NOTIFIER> notifiedEvent;
    //register DPid for super category
    LOGI().writeFormatted("[SXMPlayerAdapter::registerNotifiedDpId]");
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNELS;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_TUNE_REQUEST;

    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_TUNE_CHANNEL;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SEEK_CHANNEL;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_LAST_CHANNEL_INFO;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_TUNE_LAST_CHANNEL;
    // signals lost
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SIGNAL_STATE_NOTAVAIABLE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_SIGNAL_STATE_AVAIABLE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_AUDIO_AUDIONOTAVAILABLE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_AUDIO_AUDIOAVAILABLE;
    //request next page data
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_CHANNEL_LIST;
    // PlayerResumingSatelliteBroadcastChannel.qml onCompleted -> init timer count timeout
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_RESUMING_ONCOMPLETED;
    //back button
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_ON_CMD_GO_BACK;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_HIDE_SYSTEM_COMPONENT;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_FAVORITE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_FAVORITE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_RELATED_LIST;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_PLAYBACK_UPDATE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_CURRENT_INDEX_LINEAR_TUNER;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_ANTENNA_AVAILABLE;
    notifiedEvent << DataIdentifier::E_EVENT_NOTIFIER_SXM_ANTENNA_NOT_AVAILABLE;
    registerNotifier(notifiedEvent);
}

void SXMPlayerAdapter::onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid)
{
    //LOGI().writeFormatted("[RadioAnalogStationAdapter::onDataChanged]Event[%d]Lock[%s]", eventid, base::bool2string(m_lockStatus));
    LOGI().writeFormatted("[SXMPlayerAdapter::onDataChanged] eventId: %d", eventid);
    switch (eventid) {
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_TUNE_REQUEST:
        onEventTuneRequest();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNELS:
        onEventChannelChanged();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SEEK_CHANNEL:
        onEventSeekChannelInfomation();
        break;
//    case DataIdentifier::E_EVENT_NOTIFIER_SXM_LAST_CHANNEL_INFO:
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_TUNE_CHANNEL:{
        DELETE_PTR(m_ctxSxmChannelElements);
        m_ctxSxmChannelElements = new ChannelElements();
        m_ctxSxmChannelElements->setNumber(ResourceManager::instance()->getCurrentChannelNumber());
        if (m_rootContext != nullptr)
            m_rootContext->setContextProperty("ctxSxmChannelInfomation", m_ctxSxmChannelElements);
        break;
    }
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_ANTENNA_AVAILABLE:
        onEventAntennaAvailable();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_ANTENNA_NOT_AVAILABLE:
        onEventAntennaNotAvailable();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SIGNAL_STATE_NOTAVAIABLE:
        onEventSignalNotAvailable();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_SIGNAL_STATE_AVAIABLE:
        onEventSignalAvailable();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_AUDIO_AUDIOAVAILABLE:
        onEventAudioAvailable();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_AUDIO_AUDIONOTAVAILABLE:
        onEventAudioNotAvailable();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_CHANNEL_LIST:
        onEventNextPageChannel();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_LAST_CHANNEL_INFO:
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION:
        onEventChannelInfomation();
        break;
//    case DataIdentifier::E_EVENT_NOTIFIER_SXM_RESUMING_ONCOMPLETED:
//        m_timerCountTimeoutLostSignal->setSingleShot(true);
//        m_timerCountTimeoutLostSignal->start(TIMEOUT_LOST_SIGNAL);
//        break;
    case DataIdentifier::E_EVENT_NOTIFIER_ON_CMD_GO_BACK:
        onGoBackScreen();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_HIDE_SYSTEM_COMPONENT:
        onHideSystemComponent();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_FAVORITE:
        onEventAddFavorite();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_FAVORITE:
        onEventRemoveFavorite();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_RELATED_LIST:
        onEventRelatedList();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_PLAYBACK_UPDATE:
        onEventPlayBackUpdate();
        break;
    case DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_CURRENT_INDEX_LINEAR_TUNER:
        onEventGetCurrentIndexLinearTune();
        break;
    default:
        break;
    }
}

void SXMPlayerAdapter::initializeScreen()
{
    LOGI().writeFormatted("SXMPlayerAdapter:: initializeScreen Called");
    //Check the screen and request data
    const uint32_t currentScreenId = ScreenListInstance()->getCurrentScreenID();
    LOGI().writeFormatted("SXMPlayerAdapter:: initializeScreen currentScreenId [%d]", currentScreenId);

    switch (currentScreenId) {
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER:
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_DIRECT_TUNE:
//        LOGI().writeFormatted("[SXMPlayAdapter::initializeScreen] current screen: %d", currentScreenId);
        DELETE_PTR(m_ctxSxmChannelElements);
        m_ctxSxmChannelElements = new ChannelElements();
        if (m_rootContext != nullptr) {
            m_rootContext->setContextProperty("ctxSxmChannelInfomation", m_ctxSxmChannelElements);
            onEventChannelInfomationNowPlaying();
            if (ScreenIdentifier::E_HMI_VIEW_ID_SXM_DIRECT_TUNE == currentScreenId) {
                onEventChannelChanged();
            }
            else {
                m_isNoSignal = DataController::instance()->getIsNoSignal();
                m_rootContext->setContextProperty("isNoSignal", m_isNoSignal);
                if (m_isNoSignal) {
                    LOGI().writeFormatted("SXMPlayerAdapter:: initializeScreen m_isNoSignal is TRUE");
                    onEventSignalNotAvailable();
                }
            }
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_LINER_TUNER:
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_RELATED_CONTENT:
//        LOGI().writeFormatted("[SXMPlayerAdapter::initializeScreen]SXM Linner Tuner: %d", currentScreenId);
        DELETE_PTR(m_ctxSxmChannelModel);
        m_ctxSxmChannelModel = new ChannelListModel();
        if (m_rootContext != nullptr) {
            m_rootContext->setContextProperty("ctxChannelModel", m_ctxSxmChannelModel);
            m_rootContext->setContextProperty("ctxSxmChannelInfomation", m_ctxSxmChannelElements);
            if (ScreenIdentifier::E_HMI_VIEW_ID_SXM_LINER_TUNER == currentScreenId) {
                onEventChannelChanged();
            }
        }
        break;
    //TODO will be update
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_PLAY_BY_PLAY:
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPORTS_PLAY_BY_PLAY_SCHEDULED:
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPORTS_PLAY_BY_PLAY_RESCHEDULED:
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPORTS_NOUPCOMING:
        m_ctxSxmSportInformationElements = new SportInformationElement();
        if (m_rootContext != nullptr) {
            LOGI().writeFormatted("SXMPlayerAdapter:: initializeScreen NOT NULL");
            m_rootContext->setContextProperty("ctxSxmSportInformationElements", m_ctxSxmSportInformationElements);
            onEventChannelInfomation();
        }
        break;
    default:
        break;
    }
}

void SXMPlayerAdapter::onEventScreenChanged()
{

}

void SXMPlayerAdapter::onEventChannelInfomation()
{
    LOGI().writeFormatted("[SXMPlayerAdapter::onEventChannelInfomation]: Called");
    CHANNEL_INFORMATION_T &channelInfo = DataController::instance()->getChannelInformation();
    LOGI().writeFormatted("[SXMPlayerAdapter::onEventChannelInfomation]: CHANNEL TYPE [%d]", channelInfo.type);

    if (channelInfo.isNowPlaying) {
        updateChannelData(nullptr, E_CHANNELS_LIST_ROLES_IS_NOWPLAYING);
    }
    if ((channelInfo.type == 3) && (m_rootContext != nullptr) && (m_ctxSxmSportInformationElements != nullptr)){
        //        CHANNEL_INFORMATION_T &channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();

        m_ctxSxmSportInformationElements->setValue(channelInfo);
        m_rootContext->setContextProperty("ctxSxmSportInformationElements", m_ctxSxmSportInformationElements);
        QObject* item = nullptr;
        item = findChild("playerTuningChannel");
        if (item != nullptr) {
            QMetaObject::invokeMethod(item, "requestToChangeScreen",
                                      Q_ARG(QVariant, ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_PLAY_BY_PLAY));
        }
    }
    else {
        LOGI().writeFormatted("[SXMPlayerAdapter::onEventChannelInfomation]: Called 2");
        setChannelInfomation(channelInfo);
        QObject* item = nullptr;
        item = findChild("playerTuningChannel");
        if (item != nullptr) {
            QMetaObject::invokeMethod(item, "requestToChangeScreen",
                                      Q_ARG(QVariant, ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER));
        }
    }
}

void SXMPlayerAdapter::onEventChannelChanged()
{
    if (ScreenListInstance()->getCurrentScreenID() == ScreenIdentifier::E_HMI_VIEW_ID_SXM_LINER_TUNER) {
        if (m_ctxSxmChannelModel == nullptr) {
            LOGI().writeFormatted("[SXMPlayerAdapter::onEventChannelChanged]m_ctxSxmChannelModel: is NULL");
            return;
        }
        int currentChannelNumber = ResourceManager::instance()->getCurrentChannelNumber();
//        CHANNEL_INFORMATION_T &currentChannel = DataController::instance()->getCurrentChannelIsNowPlaying();
        QList<CHANNEL_INFORMATION_T> &channelList = DataController::instance()->getAllChannelInformation();
        m_ctxSxmChannelModel->reset();
        for(int i = 0; i < channelList.size(); i++) {
            ChannelElementPtr channel = std::make_shared<ChannelElements>();
            channel->setName(channelList[i].name);
            channel->setLogo(channelList[i].logoUrl);
            channel->setNumber(channelList[i].number);
            channel->setChannelType(static_cast<UIBridge::E_HMI_EVENT_CHANNEL_TYPE>(channelList[i].type));
            channel->setIsNowPlaying(channelList[i].isNowPlaying);
//            channel->setArtistName(channelList[i].show.mediumTitle);
            channel->setIsFavorite(channelList[i].isFavorite);

            if(channelList[i].number == currentChannelNumber) {
                m_currentIndexLinearTune = i;
            }
            if (0 == i) {
                channel->setShortDescription(channelList[0].shortDescription);
            }
            m_ctxSxmChannelModel->appendData(channel);
        }

        ChannelElementPtr channel = std::make_shared<ChannelElements>();
        channel->setNumber(-1);
        m_ctxSxmChannelModel->appendData(channel);

        m_ctxSxmChannelModel->onDataReady();
        LOGI().writeFormatted("[SXMPlayerAdapter::liner_tunner_station]currentIndex: %d", m_currentIndexLinearTune);
//        setProperty("liner_tunner_station", "currentIndex", QVariant::fromValue(m_currentIndexLinearTune));
        m_rootContext->setContextProperty("linear_tune_current_index", m_currentIndexLinearTune);
    }
    else {
//        SXMKeyPadHandler::instance()->createValidNumberMapping();
    }
}

void SXMPlayerAdapter::onEventSeekChannel()
{
    LOGI().writeFormatted("[SXMPlayerAdapter::onEventSeekChannel]: Called");
    if (m_ctxSxmChannelElements == nullptr) {
        return;
    }
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNEL_INFORMATION,
                                                   QString("%1").arg(ResourceManager::instance()->getCurrentChannelNumber()));
}

void SXMPlayerAdapter::onEventRequestTuneLastChannel()
{
    LOGI().writeFormatted("[SXMPlayerAdapter::onEventRequestTuneLastChannel]: Called");
    CHANNEL_INFORMATION_T &channelInfo = DataController::instance()->getChannelInformation();
    setChannelInfomation(channelInfo);
}

void SXMPlayerAdapter::onEventNextPageChannel()
{
//    QList<CHANNEL_INFORMATION_T> channelList = DataController::instance()->getSublistChannelInformation();

//    for(int i = 0; i < channelList.size(); i++) {
//        LOGI().writeFormatted("HopND -- [SXMPlayerAdapter::channelList.channel[%d].name: %s]: Called", i, channelList[i].name);
//        LOGI().writeFormatted("HopND -- [SXMPlayerAdapter::channelList.channel[%d].number: %d]: Called", i, channelList[i].number);
//        LOGI().writeFormatted("HopND -- [SXMPlayerAdapter::channelList.channel[%d].logoUrl: %s]: Called", i, channelList[i].logoUrl);
//        LOGI().writeFormatted("HopND -- [SXMPlayerAdapter::channelList.channel[%d].album.artistName: %s]: Called", i, channelList[i].show.mediumTitle);
//        ChannelElementPtr channel = std::make_shared<ChannelElements>();
//        channel->setName(channelList[i].name);
//        channel->setLogo(channelList[i].logoUrl);
//        channel->setNumber(channelList[i].number);
//        channel->setArtistName(channelList[i].show.mediumTitle);

//        m_ctxSxmChannelModel->appendData(channel);
//    }
//    if (m_ctxSxmChannelModel != nullptr)
//        m_ctxSxmChannelModel->onDataReady();
}

void SXMPlayerAdapter::onEventSignalNotAvailable()
{
//    if (ScreenListInstance()->getCurrentScreenID() != ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER) {
//        LOGI().writeFormatted("Screen isn't player, return now");
//        return;
//    }
    // if screen [player] is display, request screen [lost signal]
//    onEventScreenReady(ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_RESUMING_SATELLITE);
//    m_timerCountTimeoutLostSignal->setSingleShot(true);
//    m_timerCountTimeoutLostSignal->start(TIMEOUT_LOST_SIGNAL);
    m_isNoSignal = true;
    if (nullptr != m_rootContext)
        m_rootContext->setContextProperty("isNoSignal", m_isNoSignal);
}

void SXMPlayerAdapter::onEventSignalAvailable()
{

//    if ( ScreenListInstance()->getCurrentScreenID() == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_RESUMING_SATELLITE    ||
//         ScreenListInstance()->getCurrentScreenID() == ScreenIdentifier::E_HMI_VIEW_ID_SXM_SATELLITE_SIGNAL_RECONNECT    ) {
//        LOGI().writeFormatted("Screen isn't resuming or lost signal screen, return now");
//        return;
//    }

//     if screen [lost signal] or [resuming] is display, request screen player
    onEventScreenReady(ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER);
//    m_timerCountTimeoutLostSignal->stop();
    m_isNoSignal = false;
    if (nullptr != m_rootContext)
        m_rootContext->setContextProperty("isNoSignal", m_isNoSignal);
}

void SXMPlayerAdapter::onEventAudioNotAvailable()
{
    LOGI().writeFormatted("SXMPlayerAdapter:: initializeScreen m_isNoSignal is TRUE");
    if (ScreenListInstance()->getCurrentScreenID() == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER)
        onEventScreenReady(ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_AUDIO_TIMEOUT);
}

void SXMPlayerAdapter::onEventAudioAvailable()
{
    LOGI().writeFormatted("SXMPlayerAdapter:: initializeScreen m_isNoSignal is TRUE");

    if ( ScreenListInstance()->getCurrentScreenID() == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_RESUMING_SATELLITE ||
            ScreenListInstance()->getCurrentScreenID() == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_AUDIO_TIMEOUT)
        onEventScreenReady(ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER);
}

void SXMPlayerAdapter::onGoBackScreen()
{
    LOGI().writeFormatted("SXMPlayerAdapter::onGoBackScreen()");
    DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TO_HIDE_SYSTEM_COMPONENT,
                                                   "31,3, ");
}

void SXMPlayerAdapter::onHideSystemComponent()
{
    LOGI().writeFormatted("SXMPlayerAdapter::onHideSystemComponent()");
    uint32_t currentScreenId = ScreenList::getInstance()->getCurrentScreenID();
    QObject* item = nullptr;
    if (currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_LINER_TUNER) {
        item = findChild("sxm_liner_tunner_screen");
    } else if (currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_DIRECT_TUNE) {
        item = findChild("sxm_keypad_jlr");
    } else if (currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_RELATED_CONTENT)  {
        item = findChild("sxm_player_related_content");
    } else if (currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_AVAILABLE_SHOWS)  {
//        item = findChild("sxm_player_related_content");
    }
    else{
        //
    }
    if (item != nullptr) {
        QMetaObject::invokeMethod(item, "requestToChangeScreen",
                                  Q_ARG(QVariant,ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER));
    } else {
        //
    }
}

void SXMPlayerAdapter::onEventTuneRequest()
{
    LOGI().writeFormatted("SXMPlayerAdapter::onEventTuneRequest()");

//    DataController::instance()->setIsTuning(true);
    if (( nullptr != m_ctxSxmChannelElements) && (nullptr != m_rootContext)) {
        LOADING_CHANNEL_INFORMATION_T &loadingChannelInfo = DataController::instance()->getLoadingChannelInfo();
        LOGI().writeFormatted("[SXMPlayerAdapter::onEventChannelInfomationNowPlaying]: loadingChannelInfo.number [%d]", loadingChannelInfo.number);

        m_ctxSxmChannelElements->setNumber(loadingChannelInfo.number);
        m_ctxSxmChannelElements->setName(loadingChannelInfo.name);
        m_ctxSxmChannelElements->setLogo(loadingChannelInfo.logoUrl);
        m_ctxSxmChannelElements->setIsFavorite(loadingChannelInfo.isFavorite);
        m_rootContext->setContextProperty("ctxSxmChannelInfomation", m_ctxSxmChannelElements);
    }
//    onEventScreenReady(ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_TUNING);
}

void SXMPlayerAdapter::onEventChannelInfomationNowPlaying()
{
    LOGI().writeFormatted("[SXMPlayerAdapter::onEventChannelInfomationNowPlaying]: Called");
    CHANNEL_INFORMATION_T &channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
//    memcpy(channelInfo.album.artistName, "ARTIST", 20);
//    memcpy(channelInfo.album.songName, "SONG", 20);
    if (channelInfo.number > 0){
        setChannelInfomation(channelInfo);
    }
}

void SXMPlayerAdapter::onEventPlayBackUpdate()
{
//    setProperty("sxm_player_text_info", "statusPlayer", QVariant::fromValue(DataController::instance()->getPlayState()));
    if (ScreenListInstance()->getCurrentScreenID() == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER)
        setProperty("sxm_player_text_info", "statusPlayer", QVariant::fromValue(DataController::instance()->getPlayState()));
    else
        setProperty("sxm_player_pxp_screen", "statusPlayer", QVariant::fromValue(DataController::instance()->getPlayState()));
}

void SXMPlayerAdapter::onEventGetCurrentIndexLinearTune()
{
    LOGI().writeFormatted("[SXMPlayerAdapter::onEventGetCurrentIndexLinearTune]: Called m_currentIndexLinearTune = [%d]", m_currentIndexLinearTune);
//    setProperty("liner_tunner_station", "currentIndex", QVariant::fromValue(m_currentIndexLinearTune));
}

void SXMPlayerAdapter::onEventSeekChannelInfomation()
{
    LOGI().writeFormatted("[SXMPlayerAdapter::onEventSeekChannelInfomation]: Called m_currentIndexLinearTune = [%d]", m_currentIndexLinearTune);
    onEventGetCurrentIndexLinearTune();
}

//void SXMPlayerAdapter::onEventGetAntennaStatus()
//{
//    if (ScreenListInstance()->getCurrentScreenID() != ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER) {
//        LOGI().writeFormatted("Screen isn't player, return now");
//        return;
//    }
//    // if screen [player] is display, request screen [Check Antenna]
//    onEventScreenReady(ScreenIdentifier::E_HMI_VIEW_ID_SXM_CHECK_ANTENNA);
//}

void SXMPlayerAdapter::onEventAntennaAvailable()
{
    if ( ScreenListInstance()->getCurrentScreenID() == ScreenIdentifier::E_HMI_VIEW_ID_SXM_CHECK_ANTENNA) {
        onEventScreenReady(ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER);
    }
}

void SXMPlayerAdapter::onEventAntennaNotAvailable()
{
    if ( ScreenListInstance()->getCurrentScreenID() == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER) {
        onEventScreenReady(ScreenIdentifier::E_HMI_VIEW_ID_SXM_CHECK_ANTENNA);
    }
}

void SXMPlayerAdapter::onEventAddFavorite()
{
    // Update Property
    LOGI().writeFormatted("HOPND--> SXMPlayerAdapter::onEventAddFavorites(): Called");

    if(m_ctxSxmChannelElements != nullptr){
        m_ctxSxmChannelElements->setIsFavorite(true);
    }
    CHANNEL_INFORMATION_T &channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
    channelInfo.isFavorite = true;
    updateChannelData(nullptr, E_CHANNELS_LIST_ROLES_IS_FAVORITE, true);

    int currentScreenId = ScreenListInstance()->getCurrentScreenID();
    if(currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_RELATED_CONTENT
     ||currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_LINER_TUNER){
        updateChannelData(m_ctxSxmChannelModel, E_CHANNELS_LIST_ROLES_IS_FAVORITE, true);
    }
}
void SXMPlayerAdapter::onEventRemoveFavorite()
{
    // Update Property
    LOGI().writeFormatted("HOPND--> SXMPlayerAdapter::onEventRemoveFavorites(): Called");
    if(m_ctxSxmChannelElements != nullptr){
        m_ctxSxmChannelElements->setIsFavorite(false);
    }

    CHANNEL_INFORMATION_T &channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
    channelInfo.isFavorite = false;
    updateChannelData(nullptr, E_CHANNELS_LIST_ROLES_IS_FAVORITE, false);

    int currentScreenId = ScreenListInstance()->getCurrentScreenID();
    if(currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_RELATED_CONTENT
     ||currentScreenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_LINER_TUNER){
        updateChannelData(m_ctxSxmChannelModel, E_CHANNELS_LIST_ROLES_IS_FAVORITE, false);
    }
}

void SXMPlayerAdapter::onEventRelatedList()
{
    int lengthName = 0;
    int lengthshortDescription = 0;
    int isLogo = 0;
    if (m_ctxSxmChannelModel == nullptr) {
        LOGI().writeFormatted("[SXMPlayerAdapter::onEventRelatedList]m_ctxSxmChannelModel: is NULL");
        return;
    }
    LIVE_CHANNEL_LIST_T &channelList = DataController::instance()->getRelatedList();
    m_ctxSxmChannelModel->reset();
    LOGI().writeFormatted("[SXMPlayerAdapter::onEventRelatedList]m_ctxSxmChannelModel: %d", channelList.packetTotal);

    for(int i = 0; i < channelList.packetTotal; i++) {
        lengthName = QString(channelList.channel[i].name).length();
        lengthshortDescription = QString(channelList.channel[i].shortDescription).length();
        isLogo = QFile::exists(channelList.channel[i].logoUrl);

        if ((lengthName > 0) && (lengthshortDescription > 0)){
            ChannelElementPtr channel = std::make_shared<ChannelElements>();
            channel->setName(channelList.channel[i].name);
            channel->setNumber(channelList.channel[i].number);
            channel->setShortDescription(channelList.channel[i].shortDescription);
            channel->setIsFavorite(channelList.channel[i].isFavorite);
            channel->setContextualBanner(channelList.channel[i].show.contextualBanner);
            channel->setIsAvailable(channelList.channel[i].isAvailable);
            channel->setIsNowPlaying(channelList.channel[i].isNowPlaying);
            if(isLogo){
                channel->setLogo(channelList.channel[i].logoUrl);
            }
            else{
                channel->setLogo("");
            }
            m_ctxSxmChannelModel->appendData(channel);
        }
    }
    m_ctxSxmChannelModel->onDataReady();
}
