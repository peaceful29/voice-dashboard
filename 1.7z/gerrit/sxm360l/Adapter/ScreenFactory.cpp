#include "ScreenFactory.h"
#include "Common/ResourceManager.h"

ScreenFactory::ScreenFactory()
: m_sxmBrowsersAdapter(nullptr)
, m_sxmPlayerAdapter(nullptr)
{
    LOGI().writeFormatted("[ScreenFactory::ScreenFactory] Called");
    m_sxmBrowsersAdapter = new SXMBrowsersAdapter();
    m_sxmFavoriteAdapter = new SXMFavoriteAdapter();
    m_sxmPlayerAdapter   = new SXMPlayerAdapter();
    m_sxmForYouAdapter   = new SXMForYouAdapter();
    m_sxmSettingsAdapter  = new SXMSettingsAdapter();
    m_sxmSearchAdapter = new SXMSearchAdapter();
    m_speechAdapter = new SpeechAdapter();

    m_sxmPlayerAdapter->lockHandler(false);
}

ScreenFactory::~ScreenFactory()
{
    LOGI().writeFormatted("[ScreenFactory::~ScreenFactory] Called");
    SafeDelete<SXMBrowsersAdapter>(m_sxmBrowsersAdapter);
    SafeDelete<SXMPlayerAdapter>(m_sxmPlayerAdapter);
    SafeDelete<SXMFavoriteAdapter>(m_sxmFavoriteAdapter);
    SafeDelete<SXMForYouAdapter>(m_sxmForYouAdapter);
    SafeDelete<SXMSettingsAdapter>(m_sxmSettingsAdapter);
    SafeDelete<SXMSearchAdapter>(m_sxmSearchAdapter);
    SafeDelete<SpeechAdapter>(m_speechAdapter);

    m_listAdapters.clear();
    SingletonHmi::deleteInstance();
}

ScreenFactory* ScreenFactory::instance()
{
    return SingletonHmi::getInstance();
}

bool ScreenFactory::initializeAdapter(QQuickView *view)
{
    LOGI().writeFormatted("[ScreenFactory::initializeAdapter] Called");
    QQuickItem *rootObject = nullptr;
    QQmlContext *rootContext = nullptr;
    if (view != nullptr) {
        rootObject = view->rootObject();
        rootContext = view->rootContext();
    }

    //Insert adapter to the list
    m_listAdapters << m_sxmBrowsersAdapter;
    m_listAdapters << m_sxmPlayerAdapter;
    m_listAdapters << m_sxmForYouAdapter;
    m_listAdapters << m_sxmFavoriteAdapter;
    m_listAdapters << m_sxmSettingsAdapter;
    m_listAdapters << m_sxmSearchAdapter;
    m_listAdapters << m_speechAdapter;

    LOGI().writeFormatted("[ScreenFactory::initializeAdapter] Called size %d", m_listAdapters.size());
    for (int i = 0; i < m_listAdapters.size(); i++){
        LOGI().writeFormatted("[ScreenFactory::initializeAdapter] Called adapter name %s", m_listAdapters[i]->name().toStdString().c_str());
        m_listAdapters[i]->resetRootObject(rootContext, rootObject);
    }
    return true;
}

bool ScreenFactory::setCurrentQQuickView(QQuickView *view)
{
    bool ret = true;
    LOGI().writeFormatted("[ScreenFactory::setCurrentQQuickView]View[%s]Size[%d]", (view == nullptr) ? "nullptr" : "not", m_listAdapters.size());
    if ((view == nullptr) || (m_listAdapters.size() == 0)){
        ret = false;
    }else{
        QQuickItem *rootObject = view->rootObject();
        QQmlContext *rootContext = view->rootContext();
        if ((rootObject == nullptr) || (rootContext == nullptr)){
            LOGI().writeFormatted("[ScreenFactory::setCurrentQQuickView]NullObject");
        }
        for (int i = 0; i < m_listAdapters.size(); i++){
            m_listAdapters[i]->resetRootObject(rootContext, rootObject);
        }
    }
    return ret;
}

BaseAdapter *ScreenFactory::getAdapter(int screenId)
{
    LOGI().writeFormatted("[ScreenFactory::getAdapter]ScreenId %d", screenId);
    BaseAdapter* ret = nullptr;
    if (isBrowsersScreen(screenId) == true){
        ret = m_sxmBrowsersAdapter;
    } else if (isFavoriteScreen(screenId) == true) {
        ret = m_sxmFavoriteAdapter;
    } else if (isPlayerScreen(screenId) == true) {
        ret = m_sxmPlayerAdapter;
    } else if (isForYouScreen(screenId) == true) {
        ret = m_sxmForYouAdapter;
    } else if (isSettingsScreen(screenId) == true) {
        ret = m_sxmSettingsAdapter;
    } else if (isSearchScreen(screenId) == true) {
        ret = m_sxmSearchAdapter;
    } else if (isSpeechScreen(screenId) == true) {
        ret = m_speechAdapter;
    } else
        ret = nullptr;

    lockNonActiveAdapters(ret);
    return ret;
}

bool ScreenFactory::isBrowsersScreen(int screenId)
{
    if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_END)
        return true;
    else
        return false;
}

bool ScreenFactory::isFavoriteScreen(int screenId)
{
    if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_FAVORITES_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_FAVORITES_END)
        return true;
    //just set blank screen before has APIs
    else if (screenId == ScreenIdentifier::E_HMI_VIEW_ID_SXM_BLANK)
        return true;
    //end blank screen
    else
        return false;
}

bool ScreenFactory::isForYouScreen(int screenId)
{
    if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_FOR_YOU_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_FOR_YOU_END)
        return true;
    else
        return false;
}

bool ScreenFactory::isPlayerScreen(int screenId)
{
    if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_END)
        return true;
    else
        return false;
}

bool ScreenFactory::isSearchScreen(int screenId)
{
    if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_SEARCH_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_SEARCH_END)
        return true;
    else
        return false;
}

bool ScreenFactory::isSettingsScreen(int screenId)
{
    if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_END)
        return true;
    else
        return false;
}

bool ScreenFactory::isSpeechScreen(int screenId)
{
    if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_END)
        return true;
    else
        return false;
}

void ScreenFactory::lockNonActiveAdapters(BaseAdapter *activeHandler)
{
    if (activeHandler != nullptr){
        for (int i = 0; i < m_listAdapters.size(); i++){
            //lock non-active adapter
            if (activeHandler != m_listAdapters[i]){
                LOGI().writeFormatted("[ScreenFactory::lockNonActiveAdapters]AdapterLocked[%s]", m_listAdapters[i]->name().toStdString().c_str());
                m_listAdapters[i]->lockHandler(true);
            }
        }
        //Unlock active adapter
        LOGI().writeFormatted("[ScreenFactory::lockNonActiveAdapters]AdapterOpen[%s]", activeHandler->name().toStdString().c_str());
        activeHandler->lockHandler(false);
    }
}

