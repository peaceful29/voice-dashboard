#include "Interfaces/SxmServiceInterface.h"
#include "BaseAdapter.h"
#include "ChannelElements.h"
#include "Common/SXMDefine.h"
#include "ScreenFactory.h"

BaseAdapter::BaseAdapter(QString name)
    : m_name(name)
    , m_rootContext(nullptr)
    , m_rootObject(nullptr)
    , m_sxmServiceInterface(nullptr)
{

}

BaseAdapter::~BaseAdapter()
{
    m_rootContext = nullptr;
    m_rootObject = nullptr;
}

void BaseAdapter::resetRootObject(QQmlContext *rootContext, QQuickItem *rootObject)
{
    m_rootContext = rootContext;
    m_rootObject = rootObject;
}

QString BaseAdapter::name()
{
    return m_name;
}

void BaseAdapter::onEventScreenReady(int screenId)
{
    LOGI().writeFormatted("[BaseAdapter::onEventScreenReady] Called");
    //Update screen
    int preScreenId = ScreenListInstance()->getCurrentScreenID();
    LOGI().writeFormatted("[BaseAdapter::getCurrentScreenID] preScreenId[%d]", preScreenId);
    LOGI().writeFormatted("[BaseAdapter::onEventScreenReady] Current [%d]", screenId);

    ScreenListInstance()->setScreenID(preScreenId, screenId);
    //Prepare for screen
    initializeScreen();
    //Build-up screen
    request2ChangeScreen(screenId);
}

bool BaseAdapter::setProperty(QString objectName, QString property, const QVariant variant)
{
    LOGI().writeFormatted("[BaseAdapter::setProperty] Called ");
    bool ret = false;
    if (m_rootObject != nullptr) {
        QObject *object = m_rootObject->findChild<QObject*>(objectName);
        if (object != nullptr) {
            LOGI().writeFormatted("[BaseAdapter::object not null] Called");
            object->setProperty(property.toStdString().c_str(), variant);
            ret = true;
        }
    } else {
        LOGI().writeFormatted("[BaseAdapter::setProperty] Object null ");
    }
    return ret;
}

QObject *BaseAdapter::findChild(QString objectName)
{
    QObject * object = nullptr;
    if (m_rootObject != nullptr) {
        object = m_rootObject->findChild<QObject*>(objectName);
    }
    return object;
}

void BaseAdapter::request2ChangeScreen(int screenId)
{
    //Update screen
//    int preScreenId = ScreenListInstance()->getCurrentScreenID();
//    ScreenListInstance()->setScreenID(preScreenId, screenId);

    LOGI().writeFormatted("[BaseAdapter::request2ChangeScreen] Called screen id %d", screenId);
    QString screenPath = ScreenList::getInstance()->getScreenPathbyId(screenId);
    LOGI().writeFormatted("[BaseAdapter::request2ChangeScreen]ScreenPath[%s]", screenPath.toStdString().c_str());
    setProperty("mainContent", "source", screenPath);
}

BaseAdapter *BaseAdapter::adapter(QString name)
{
    BaseAdapter* adapter = nullptr;
    if (m_registerAdapter.count(name) > 0) {
        adapter = m_registerAdapter[name];
    }
    return adapter;
}

void BaseAdapter::updateChannelData(BaseListModel *listModel, int role, bool value)
{
    unsigned int channelNumber = ResourceManager::instance()->getCurrentChannelNumber();
    if (listModel != nullptr){
        for (int i = 0; i < listModel->rowCount(); i++){
            ChannelElements* element = dynamic_cast<ChannelElements*>(listModel->getElement(i));
            if ((element != nullptr) && (element->number() == static_cast<int>(channelNumber))){
                listModel->updateData(i, role, QVariant::fromValue(value));
                break;
            }
        }
    }
    LOGI().writeFormatted("[BaseAdapter::updateChannelData] getCurrentChannelNumber %d", channelNumber);

    QList<CHANNEL_INFORMATION_T> &channelList = DataController::instance()->getAllChannelInformation();
    for (int i = 0; i < channelList.size(); i ++) {
        if (channelList[i].number == static_cast<int>(channelNumber)){
            channelList[i].isFavorite = value;
            DataController::instance()->setAllChannelInformation(i, channelList[i]);
            break;
        }
    }

    CHANNEL_INFORMATION_T& channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
    if(channelInfo.number == channelNumber){
        channelInfo.isFavorite = value;
    }
}

void BaseAdapter::updateChannelData(BaseListModel *listModel, int role)
{
    CHANNEL_INFORMATION_T& channelInfo = DataController::instance()->getCurrentChannelIsNowPlaying();
    if (listModel != nullptr){
        for (int i = 0; i < listModel->rowCount(); i++){
            ChannelElements* element = dynamic_cast<ChannelElements*>(listModel->getElement(i));
            if ((element != nullptr) && (element->number() == static_cast<int>(channelInfo.number))){
                listModel->updateData(i, role, QVariant::fromValue(true));
            }
            else if (element != nullptr){
                listModel->updateData(i, role, QVariant::fromValue(false));
            }
            else{
                //Do nothing
            }
        }
    }
    LOGI().writeFormatted("[BaseAdapter::updateChannelData] getCurrentChannelIsNowPlaying %d", channelInfo.number);

    QList<CHANNEL_INFORMATION_T> &channelList = DataController::instance()->getAllChannelInformation();
    for (int i = 0; i < channelList.size(); i ++) {
        if (channelList[i].number == static_cast<int>(channelInfo.number)){
            DataController::instance()->setAllChannelInformation(i, channelList[i]);
        }
        else {
            DataController::instance()->setAllChannelInformation(i, channelList[i]);
        }
    }
}

uint32_t BaseAdapter::getScreenIdForBack()
{
    ResourceManager::instance()->m_lstBackScreen.pop_back();
    uint8_t size = ResourceManager::instance()->m_lstBackScreen.size();
    uint32_t screenId = 0;

    if (0 != size){
        screenId = ResourceManager::instance()->m_lstBackScreen.at(size - 1);

        if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_END){
            screenId = ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER;
        }
        else if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_END){
            screenId = ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_CATEGORIES;
        }
        else if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_FAVORITES_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_FAVORITES_END){
            screenId = ScreenIdentifier::E_HMI_VIEW_ID_SXM_FAVORITES;
        }
        else if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_FOR_YOU_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_FOR_YOU_END){
            screenId = ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECOMMENDATION;
        }
        else if (screenId >= ScreenIdentifier::E_HMI_VIEW_ID_SXM_SEARCH_START && screenId <= ScreenIdentifier::E_HMI_VIEW_ID_SXM_SEARCH_END){
            screenId = ScreenIdentifier::E_HMI_VIEW_ID_SXM_SEARCH;
        }
        else{
            //Do nothing
        }
    }

    return screenId;
}
