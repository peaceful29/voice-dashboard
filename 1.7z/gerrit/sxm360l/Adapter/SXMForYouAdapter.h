#ifndef SXMFORYOUADAPTER_H
#define SXMFORYOUADAPTER_H

#include <QObject>
#include "BaseAdapter.h"
#include "Common/SXMDefine.h"
#include "ChannelListModel.h"
#include "CategoryListModel.h"
#include "RecommendedListModel.h"

class SXMForYouAdapter : public BaseAdapter
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SXMForYouAdapter();
    virtual ~SXMForYouAdapter();
protected:
    //    void createConnect2Interface();
    //Register notify
    void registerNotifiedDpId();
    //Update data for current screen
    void onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid);
    //Initialize data for screen
    void initializeScreen();
    void onEventScreenChanged();
private:
    void onRecommendChannels();
    void onGoBackScreen();
    void onHideSystemComponent();
    void onEventAddFavorite();
    void onEventRemoveFavorite();
    void onEventChannelInfomation();
    void onEventListenHistory();

    RecommendedListModel*      m_ctxSxmRecommendChannels;
    ChannelListModel*       m_ctxSxmHistoryListenChannel;

};

#endif // SXMFORYOUADAPTER_H
