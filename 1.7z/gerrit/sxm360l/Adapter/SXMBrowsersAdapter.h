#ifndef SXMBROWSERSADAPTER_H
#define SXMBROWSERSADAPTER_H

#include <QObject>
#include "BaseAdapter.h"
#include "Common/SXMDefine.h"
#include "SuperCategoryListModel.h"
#include "CategoryListModel.h"
#include "ChannelListModel.h"
#include "TeamListModel.h"
#include "SportInformationListModel.h"

class SXMBrowsersAdapter : public BaseAdapter
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SXMBrowsersAdapter();
    virtual ~SXMBrowsersAdapter();
protected:
    //    void createConnect2Interface();
    //Register notify
    void registerNotifiedDpId();
    //Update data for current screen
    void onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventid);
    //Initialize data for screen
    void initializeScreen();
    void onEventScreenChanged();
private:
    SuperCategoryListModel* m_ctxSxmSuperCategories;
    CategoryListModel*      m_ctxSxmCategories;
    void onEventSuperCategory();
    void onEventCategories();
    void onEventLiveChannels();
    void onGoBackScreen();
    void onHideSystemComponent();
    void onEventChannelInfomation();
    void onEventAddFavorite();
    void onEventRemoveFavorite();
    void onEventGetTeams();

    ChannelListModel*      m_ctxSxmLiveChannels;
//    SportInformationListModel* m_ctxSxmSportChannels;
    TeamListModel*         m_ctxSxmTeams;
    QString m_currentCategory;
    QString m_currentSuperCategory;
//    SportInformationElement* m_ctxSxmSportInformationElements;

};

#endif // SXMBROWSERSADAPTER_H
