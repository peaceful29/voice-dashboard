#ifndef COMPONENTSTATES_H
#define COMPONENTSTATES_H

#include <QObject>

class ComponentStates : public QObject
{
    Q_OBJECT
public:
    enum COMPONENTSTATES
    {
        DEFAULT = 0,
        PRESSED,
        SELECTED,
        DISABLED,
        CONTENT_1,
        THEME,
        INACTIVE,
        INVERT,

        TOGGLE_BUTTON_ON,
        TOGGLE_BUTTON_OFF,
        TOGGLE_BUTTON_PARTIAL,
        TOGGLE_BUTTON_ALL,

        RADIO_BUTTON_ON,
        RADIO_BUTTON_OFF,
        RADIO_BUTTON_DISABLE,

        LIVE_BUTTON_SELECT
    };
    Q_ENUMS(COMPONENTSTATES)
};

#endif // COMPONENTSTATES_H
