#ifndef SXMAPPMAIN_H
#define SXMAPPMAIN_H

#include <QQmlError>
#include <QQuickView>
#include <QObject>
#include "Testing/AutoClickTest.h"
#include <QTimer>
#include "Common/Utils.h"
#include "SXMDefine.h"

class SxmInterfaceFactory;
class SxmAppServiceInterface;
class SxmServiceInterface;
class SxmKeyboardInterface;
class SxmPopupServiceInterface;
class UIBridge;
class BaseAdapter;
class SxmSpeechServiceInterface;

class SXMAppMain : public QObject
{
#ifndef APP_ON_DESKTOP
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
#endif
    Q_OBJECT
public:
    explicit SXMAppMain(QObject *parent = 0);
    ~SXMAppMain();

    QString getCurrentStyleMode();

    bool isValid() const;
    QString lastError() const;

private:
    void registerType();
    void initializeContextProperty();
    void initializeScreenFactory();

    void createInterface();
    void initializeView();
    void initButtonBack(int screenID);
    void readJsonTestFile();
    void onAutoClick();
    void requestToShowApplication(QString appRole, QString intent);
    bool requestToShowFromVoicetags(QString appRole, QString intent);
    /**
     * @brief sxm application work in normal mode
     */
    void switch2NormalMode();
    /**
     * @brief sxm application work in speech mode
     */
    void switch2SpeechMode(QString strIntent);

    SXM_APP_ROLE getCurrentAppRole(QString appRole);


    QQuickView *m_view;
    UIBridge* m_uiBridge;
    SxmInterfaceFactory* m_ifactory;
    SxmAppServiceInterface *m_appInterface;
    SxmServiceInterface *m_sxmInterface;
    SxmKeyboardInterface *m_keyboardInterface;
    SxmPopupServiceInterface *m_popupInterface;
    BaseAdapter *m_currentActAdapter;

    QQuickItem* m_rootObject;
    QString m_styleMode;
    QQmlError m_lastError;
    AutoClickTest* m_autoClickTest;
    QTimer m_autoClickTimer;
    //For speech
    QQuickView *m_speechView;
    SxmSpeechServiceInterface *m_speechInterface;
    bool m_isInitialized;
    bool m_isSATSubscriptionStatus;
    int m_speechVoicetags;
//    bool m_isLossSignal;

signals:

public slots:
    void onWarnings(const QList<QQmlError>& _warnings);
    void onRequestShow(QString objectName, int screenId);
    void onHmiEvent(int fncId, QString parameters);
    void onCmdCreateAppWindow();
    void onCmdDestroyAppWindow();
    void onCmdShowApplication(QString appRole, QString intent);
    void onCmdShowAppWindow(QString appRole, QString intent);
    void onSatSubscriptionState(const int state);
    void onChangeStyleMode();
};

#endif // SXMAPPMAIN_H
