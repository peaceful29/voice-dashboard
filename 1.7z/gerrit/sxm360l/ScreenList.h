#ifndef SCREENLIST_H
#define SCREENLIST_H

#include <stdint.h>
#include <QMap>
#include <QObject>
#include "ScreenIdentifier.h"

class ScreenList : public QObject
{
    Q_OBJECT
public:
    void createScreenMapping();
    QString getScreenPathbyId(uint32_t screenId);
    uint32_t getScreenIdbyPath(QString screenPath);
    static ScreenList* getInstance();

    void setCurrentScreenID(const uint32_t id);
    void setPreviousScreenID(const uint32_t id);
    void setScreenID(const uint32_t current, const uint32_t previous);

    uint32_t getCurrentScreenID() const;
    uint32_t getPreviousScreenID() const;

    bool isCurrentScreen(const uint32_t id) const;
    bool isPreviousScreen(const uint32_t id) const;
private:
    ScreenList();

    static ScreenList *m_screenListInstance;
    QMap<uint32_t, QString> m_mapScreenPathId;
    ScreenIdentifier* m_screenIndentifier;

    uint32_t m_currentScreenID;
    uint32_t m_previousScreenID;
};

#define ScreenListInstance() ScreenList::getInstance()

#endif // SCREENLIST_H
