#include <QApplication>
#include <QQmlApplicationEngine>
#include "SXMAppMain.h"
#include "Common/Utils.h"

#ifndef APP_ON_DESKTOP
LOG_DEFINE_APP_IDS("XMAP", "HmiSxm");
LOG_DECLARE_CONTEXT(hmi_sxm_context, "XMAP", "HmiSxm");
LOG_SET_DEFAULT_CONTEXT(hmi_sxm_context);
#endif

int main(int argc, char *argv[])
{
    QGuiApplication a(argc, argv);
    SXMAppMain sxmAppMain;

    return a.exec();
}
