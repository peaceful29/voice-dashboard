#include "DataHandler.h"
#include "DataController.h"
#include "DataNotifier.h"

/*!
 * \brief DataHandler::DataHandler
 * \param parent
 */
DataHandler::DataHandler(QObject *parent) : QObject(parent)
  , m_lockStatus(true)
{
//    m_dataController = DataController::instance();
}

/*!
 * \brief DataHandler::~DataHandler
 */
DataHandler::~DataHandler()
{

}

/*!
 * \brief DataHandler::registerNotifier
 * \param notifierDpId
 * \return
 */
bool DataHandler::registerNotifier(QVector<DataIdentifier::E_EVENT_NOTIFIER> notifierDpId)
{
//    if (m_dataController == nullptr)
//        return false;
    m_dataNotifier = new DataNotifier(notifierDpId, this);
    DataController::instance()->registerDataNotifier(m_dataNotifier);
//    m_dataController->registerDataNotifier(m_dataNotifier);
    QObject::connect(m_dataNotifier, SIGNAL(eventScreenUpdate(DataIdentifier::E_EVENT_NOTIFIER))
                     , this, SLOT(onEventDataChanged(DataIdentifier::E_EVENT_NOTIFIER)));
    return true;
}

/*!
 * \brief DataHandler::onEventDataChanged
 * \param eventId
 */
void DataHandler::onEventDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventId)
{
    if (!m_lockStatus)
        onDataChanged(eventId);
}

/*!
 * \brief DataHandler::lockHandler
 * \param locked
 */
void DataHandler::lockHandler(bool locked)
{
    m_lockStatus = locked;
}

/*!
 * \brief DataHandler::lockStatus
 * \return
 */
bool DataHandler::lockStatus() const
{
    return m_lockStatus;
}
