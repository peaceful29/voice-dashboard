#include "sxm360l/Sxm360lProvider.h"
#include "Interfaces/SxmServiceInterface.h"
#include "DataNotifier.h"
#include "DataController.h"
#include "SxmCmd.h"
#include "Common/Utils.h"
#include "ScreenIdentifier.h"
#include "ResourceManager.h"
#include "SXMKeyPadHandler.h"

DataController::DataController()
    :m_sxmCmd(nullptr)
    , m_isChannelListFinished(true)
    , m_playState(0)
    , m_isNoSignal(false)
    , m_isNoAntenna(false)
    , m_isTuning (false)
    , m_antennaState(ANTENNA_UNKNOWN)
{
    LOGI().writeFormatted("DataController::DataController() called");
    LOGI().writeFormatted("DataController::DataController() called %p", this);
    m_provider = Sxm360lProvider::getInstance();

    m_speechProvider = SpeechProvider::getInstance();
}

/*!
 * \brief DataController::updateData
 * \param _dpId
 * \param _value
 */
void DataController::updateData(const DataIdentifier::E_DATA_IDENTIFIER _dpId, QString _value)
{
    m_mapDpIdValueBefore[_dpId] = m_mapDpIdValue[_dpId];
    m_mapDpIdValue[_dpId] = _value;
    m_mapDpidValueUpdateTime[_dpId] = QDateTime::currentMSecsSinceEpoch();
}

/*!
 * \brief DataController::publishToSubscribe
 * \param _eventId
 */
void DataController::publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER _eventId)
{
    LOGI().writeFormatted("DataController::publishToSubscribe() called eventID %d", _eventId);
    for(std::vector<DataNotifier*>::iterator it = m_dataNotifiers.begin();
        it != m_dataNotifiers.end(); ++it) {
        DataNotifier *dataNotifier = *it;
        if (dataNotifier->existNotifiedEvent(_eventId) == true) {
            dataNotifier->notifyEvent(_eventId);
        }
    }
}

bool DataController::getIsTuning() const
{
    return m_isTuning;
}

void DataController::setIsTuning(bool isTuning)
{
    m_isTuning = isTuning;
}

bool DataController::getIsNoAntenna() const
{
    return m_isNoAntenna;
}

LOADING_CHANNEL_INFORMATION_T &DataController::getLoadingChannelInfo()
{
    return m_loadingChannelInfo;
}

ANTENNA_STATE DataController::getAntennaState() const
{
    return m_antennaState;
}

void DataController::setAntennaState(const ANTENNA_STATE &antennaState)
{
    m_antennaState = antennaState;
}

bool DataController::getIsNoSignal() const
{
    return m_isNoSignal;
}

void DataController::setIsNoSignal(bool isNoSignal)
{
    m_isNoSignal = isNoSignal;
}

uint8_t DataController::getPlayState() const
{
    return m_playState;
}
void DataController::setPlayState(const uint8_t &playState)
{
    m_playState = playState;
}

CHANNEL_INFORMATION_T& DataController::getCurrentChannelIsNowPlaying()
{
    return m_currentChannelIsNowPlaying;
}

ARTIST_SONG_ALERTS_T& DataController::getArtistAndSongAlerts()
{
    //TODO: generate fake data
//    generateArtistAndSongAlert(m_artistAndSongAlerts);
    return m_artistAndSongAlerts;
}

QList<TEAM_INFO_T> &DataController::getTeamAlerts()
{
    return m_teamAlerts;
}

void DataController::setArtistAndSongAlerts(const ARTIST_SONG_ALERTS_T &artistAndSongAlerts)
{
    m_artistAndSongAlerts = artistAndSongAlerts;
}

QList<CHANNEL_INFORMATION_T> &DataController::getAllChannelInformation()
{
    return m_allChannelInformation;
}

QList<FAVORITE_T>& DataController::getListFavorite()
{
    return m_lstFavoriteList;
}

//SONG_LIST_T &DataController::getSongList()
//{
//    return m_songList;
//}

//ARTIST_LIST_T &DataController::getArtistList()
//{
//    return m_artistList;
//}

/*!
 * \brief DataController::eventShowSystemComponent
 * \param _requestID
 * \param eResult
 */
void DataController::eventShowSystemComponent(const int _requestID, E_REQ_RESULT_MSG eResult)
{
    Q_UNUSED(_requestID)
    Q_UNUSED(eResult)
    LOGI().writeFormatted("DataController::eventShowSystemComponent() called");
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SHOW_SYSTEM_COMPONENT);
}

/*!
 * \brief DataController::eventHideSystemComponent
 * \param _requestId
 * \param eResult
 */
void DataController::eventHideSystemComponent(const int _requestID, E_REQ_RESULT_MSG eResult)
{
    Q_UNUSED(_requestID)
    Q_UNUSED(eResult)
    LOGI().writeFormatted("DataController::eventHideSystemComponent() called");
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_HIDE_SYSTEM_COMPONENT);
}

/*!
 * \brief DataController::eventCmdGoBack
 * \param requestID
 */
void DataController::eventCmdGoBack(const int requestID)
{
    LOGI().writeFormatted("DataController::eventCmdGoBack() called request %d", requestID);
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_ON_CMD_GO_BACK);
}

void DataController::eventButtonHardkey(const E_SWITCH &eSwitchType, const E_BUTTON &eButton, const E_ACTION &eAction)
{
    LOGI().writeFormatted("SxmAppService::onButtonEvent() called switchType %d, button %d action %d",
                          eSwitchType, eButton, eAction);
    if ((E_SWITCH_STEERING_WHEEL != eSwitchType) || (m_lstFavoriteList.size() == 0)) {
        return;
    }
    LOGI().writeFormatted("SxmAppService::onButtonEvent() SIZE [%d]", m_lstFavoriteList.size());
    CHANNEL_INFORMATION_T &currentChannel = getCurrentChannelIsNowPlaying();
    int currentIndex = -1;
    for (int i = 0; i < m_lstFavoriteList.size(); i++) {
        if (m_lstFavoriteList[i].channelInfo.number == currentChannel.number) {
            currentIndex = i;
            LOGI().writeFormatted("SxmAppService::onButtonEvent() NOWPLAYING [%d]", currentIndex);
            break;
        }
    }

    if (currentIndex == -1) {
        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TUNE_CHANNEL, QString::number(m_lstFavoriteList[0].channelInfo.number));
        return;
    }
    if (E_BUTTON_SEEK_UP == eButton) {
        if (currentIndex == m_lstFavoriteList.size() - 1) {
            currentIndex = 0;
        }
        else {
            currentIndex++;
        }
        LOGI().writeFormatted("SxmAppService::onButtonEvent() SEEK_UP currentIndex [%d]", currentIndex);
    }
    else if (E_BUTTON_SEEK_DOWN == eButton) {
        if (currentIndex == 0) {
            currentIndex = m_lstFavoriteList.size() - 1;
        }
        else {
            currentIndex--;
        }
        LOGI().writeFormatted("SxmAppService::onButtonEvent() SEEK_DOWN currentIndex [%d]", currentIndex);
    }
    else{
    }
    makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TUNE_CHANNEL, QString::number(m_lstFavoriteList[currentIndex].channelInfo.number));
}

LIVE_CHANNEL_LIST_T &DataController::getRelatedList()
{
    //TODO: generate fake data
//    generateRelatedList(m_lstRelatedChannel);
    //TODO: delete when having real data
    return m_lstRelatedChannel;
}

LIVE_CHANNEL_LIST_T &DataController::getHistoryList()
{
    //TODO: generate fake data
//    generateHistoryList(m_lstHistoryChannel);
    //TODO: delete when having real data
    return m_lstHistoryChannel;
}

void DataController::eventRelatedList()
{
    LOGI().writeFormatted("DataController::eventRelatedList() called");
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_RELATED_LIST);
}

/*!
 * \brief DataController::getRecommendationList
 * \return
 */
QList<CHANNEL_INFORMATION_T> &DataController::getRecommendationList()
{
    LOGI().writeFormatted("DataController::getRecommendationList() called");
    return m_lstRecommendation;
}

bool DataController::getIsChannelListFinished() const
{
    return m_isChannelListFinished;
}

/*!
 * \brief DataController::eventGetChannelList
 * \param _count
 */
void DataController::eventGetChannelList(const int _count)
{
    LOGI().writeFormatted("DataController::eventGetChannelList() called count %d", _count);
    if (m_isChannelListFinished || (_count <= 0))
        return;
    // m_lstRecommendation.clear();

    for (int i = _count * Utils::NUMBER_CHANNEL_ONE_REQUEST; i < (_count + 1) * Utils::NUMBER_CHANNEL_ONE_REQUEST; ++i) {
        //this code for right case, do not delete
        //        if (i < m_lstAvailableChannel.size()) {
        //            m_isChannelListFinished = false;
        //            m_sublistChannelInformation.append(m_lstAvailableChannel.at(i));
        //        }
        if (i < m_lstChannelInformation.size()) {
            m_isChannelListFinished = false;
            m_lstChannelInformation[i].isAvailable = true;
            // m_lstRecommendation.append(m_lstChannelInformation.at(i));
        }
        else {
            m_isChannelListFinished = true;
            break;
        }
    }
    if (!m_isChannelListFinished)
        publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_CHANNEL_LIST);
}

/*!
 * \brief DataController::getLstChannelInformation
 * \return
 */
QList<CHANNEL_INFORMATION_T> &DataController::getLstChannelInformation()
{
    return m_lstChannelInformation;
}


void DataController::setAllChannelInformation(const int index, CHANNEL_INFORMATION_T &element)
{
    m_allChannelInformation[index] = element;
}

/*!
 * \brief DataController::~DataController
 */
DataController::~DataController()
{
    LOGI().writeFormatted("DataController::~DataController() called");
    m_provider = nullptr;
    SafeDelete<SxmCmd>(m_sxmCmd);
    SingletonHmi::deleteInstance();
}

/*!
 * \brief DataController::instance
 * \return
 */
DataController* DataController::instance()
{
    return SingletonHmi::getInstance();
}

/*!
 * \brief DataController::initialize
 * \param _interface
 */
void DataController::initialize(SxmServiceInterface *_interface, SxmAppServiceInterface* _appInterface,
                                SxmKeyboardInterface* _keyboardInterface, SxmSpeechServiceInterface *speechInterface, SxmPopupServiceInterface *_popupInterface){
    LOGI().writeFormatted("DataController::initialize() called");
    m_sxmCmd = new SxmCmd("SxmCmd" ,_interface, _appInterface, _keyboardInterface, speechInterface, _popupInterface);
    if (m_sxmCmd != nullptr) {
        m_sxmCmd->initialize();
    }
}

/*!
 * \brief DataController::registerDataNotifier
 * \param dataNotifier
 * \return
 */
bool DataController::registerDataNotifier(DataNotifier *dataNotifier)
{
    LOGI().writeFormatted("DataController::registerDataNotifier() called");
    for (std::vector<DataNotifier*>::iterator it = m_dataNotifiers.begin();
         it != m_dataNotifiers.end(); ++it) {
        if (dataNotifier == *it) {
            return false;
        }
    }
    m_dataNotifiers.push_back(dataNotifier);
    return true;
}

/*!
 * \brief DataController::deregisterDataNotifier
 * \param dataNotifier
 * \return
 */
bool DataController::deregisterDataNotifier(DataNotifier *dataNotifier)
{
    LOGI().writeFormatted("DataController::deregisterDataNotifier() called");
    bool ret = false;
    for (std::vector<DataNotifier*>::iterator it = m_dataNotifiers.begin();
         it != m_dataNotifiers.end(); ++it) {
        if (dataNotifier == *it) {
            ret = true;
            break;
        }
    }
    return ret;
}

/*!
 * \brief DataController::requestDataDependScreen
 * \param screenId
 */
void DataController::requestDataDependScreen(int screenId)
{
    switch(screenId){
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER:
        //        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNELS_2, "");
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_CATEGORIES:            //FALL THROUGH
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_SUPER_CATEGORIES:
        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SUPERCATEGORY,"");
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_FAVORITES:
        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_FAVORITES, "");
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECOMMENDATION:
        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_RECOMMENDATION, "");
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_RELATED_CONTENT:
        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_RELATED_LIST, "");
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECENT_HISTORY:
        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_LISTENING_HISTORY, "");
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_ARTIST_SONG_NOTIFICATIONS:
//        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ARTIST_AND_SONG_ALERT, "");
//        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SONG_ALERT, "");
//        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ARTIST_ALERT, "");
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SEARCH_LISTENING:
        makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNELS_2, "");
        break;
    default:
        break;
    }
}

/*!
 * \brief DataController::getData
 * \param dataId
 * \return
 */
QString DataController::getData(const DataIdentifier::E_DATA_IDENTIFIER dataId)
{
    LOGI().writeFormatted("DataController::getData() called");
    QString ret = "";
    if (m_mapDpIdValue.count(dataId) > 0)
        ret = m_mapDpIdValue[dataId];
    return ret;
}

/*!
 * \brief DataController::getDataBefore
 * \param dpId
 * \return
 */
QString DataController::getDataBefore(uint32_t dpId)
{
    LOGI().writeFormatted("DataController::getDataBefore() called");
    QString ret = "";
    if (m_mapDpIdValueBefore.count(dpId) > 0)
        ret = m_mapDpIdValue[dpId];
    return ret;
}

/*!
 * \brief DataController::getDataUpdateTimeStamp
 * \param dpId
 * \return
 */
uint64_t DataController::getDataUpdateTimeStamp(uint32_t dpId)
{
    LOGI().writeFormatted("DataController::getDataUpdateTimeStamp() called");
    uint64_t ret = 0;
    if (m_mapDpidValueUpdateTime.count(dpId) > 0)
        ret = m_mapDpidValueUpdateTime[dpId];
    return ret;
}

/*!
 * \brief DataController::getSuperCategorList
 * \return
 */
SUPER_CATEGORY_LIST_T &DataController::getSuperCategorList()
{
    LOGI().writeFormatted("DataController::getSuperCategorList() called");
    return m_superCategoryList;
}

/*!
 * \brief DataController::getCategoryList
 * \return
 */
CATEGORY_LIST_T &DataController::getCategoryList()
{
    LOGI().writeFormatted("DataController::getCategoryList() called");
    return m_categoryList;
}

/*!
 * \brief DataController::getAlbumInformation
 * \return
 */
ALBUM_INFORMATION_T &DataController::getAlbumInformation()
{
    LOGI().writeFormatted("DataController::getAlbumInformation() called");
    return m_albumInformation;
}

/*!
 * \brief DataController::getShowInformation
 * \return
 */
//RECOMMENDED_SHOW_T &DataController::getShowInformation()
//{
//    return m_showInformation;
//}

/*!
 * \brief DataController::getChannelInformation
 * \return
 */
CHANNEL_INFORMATION_T &DataController::getChannelInformation()
{
    return m_channelInformation;
}

/*!
 * \brief DataController::getLiveChannelList
 * \return
 */
LIVE_CHANNEL_LIST_T &DataController::getLiveChannelList()
{
    return m_liveChannelList;
}

/*!
 * \brief DataController::getImageSetList
 * \return
 */
IMAGE_SET_LIST_T &DataController::getImageSetList()
{
    return m_imageSetList;
}

/*!
 * \brief DataController::getSmartFavoriteList
 * \return
 */
SMART_FAVORITE_LIST_T &DataController::getSmartFavoriteList()
{
    return m_smartFavoriteList;
}

/*!
 * \brief DataController::getShowChannelList
 * \return
 */
//SHOW_CHANNEL_LIST_T &DataController::getShowChannelList()
//{
//    return m_showChannelList;
//}

/*!
 * \brief DataController::getFavoriteList
 * \return
 */
FAVORITE_LIST_T &DataController::getFavoriteList()
{
    //make color
//    generateFavoriteList(m_favoriteList);
    //make color
    return m_favoriteList;
}

SPORTS_TEAM_T &DataController::getSportTeams()
{
    return m_sportTeams;
}

/*!
 * \brief DataController::getFavoriteInformation
 *        get favorite information
 * \return  0: found, favoriteInfor(0)
 *          -1: not found
 */
int DataController::getFavoriteInformation(FAVORITE_T &favoriteInfor, const unsigned int &number)
{
    for (int dwCount=0; dwCount<MAX_FAVORITES_CNT; dwCount++) {
        if (m_favoriteList.favorite[dwCount].channelInfo.number == number) {
            favoriteInfor = m_favoriteList.favorite[dwCount];
            return 0;
        }
    }
    return -1;      // not found
}

//TO DO ha.tran getChannelInformation by channel number for voicetag SXM_CHANNEL
//*!
// * \brief DataController::getChannelInformation
// *        get channel information
// * \return  0: found,
// *          -1: not found
// */
int DataController::getChannelInformation(CHANNEL_INFORMATION_T &channelInfor, const unsigned int &number)
{
    for (int count = 0; count < m_allChannelInformation.length(); count ++)
    {
        if (m_allChannelInformation[count].number == number)
        {
            channelInfor = m_allChannelInformation[count];
            return 0;
        }
    }
    return -1;  // not found
}


QList<LEAGUE_INFO_T>& DataController::getSportLeagues()
{
    return m_sportLeagues;
}

#ifndef EXCLUDE_SPEECH
SPEECH_SCFA_TELEPROMPTERSHOW_INFO_ST DataController::getScfaTeleprompterShowInfo()
{
    return m_scfaInfo;
}

SPEECH_SCFA_LISTSHOW_INFO_ST DataController::getScfaListShowInfo()
{
    return m_scfaListShowInfo;
}

SPEECH_SDARS_TEAM_DATA DataController::getSpeechSdarsTeamData()
{
    return m_speechTeamData;
}

QList<CHANNEL_INFORMATION_T> &DataController::getSpeechDataChannel()
{
    return m_speechDataChannel;
}

SPEECH_SDARS_CATEGORY_LIST DataController::getSpeechCategorySatList()
{
    return m_speechCategorySatList;
}

void DataController::currentIndexListSpeechModeChanged(int value)
{
    LOGI().writeFormatted("[DataController::currentIndexListSpeechModeChanged][%d]", value);
    updateData(DataIdentifier::E_DATA_IDENTIFIER_SPEECH_MODE_LIST_CURRENT_INDEX, QString::number(value));
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_CURRENT_INDEX_CHANGED);
}

void DataController::resetCurrentIndexListSpeechMode()
{
    updateData(DataIdentifier::E_DATA_IDENTIFIER_SPEECH_MODE_LIST_CURRENT_INDEX, QString::number(0));
}
#endif

/*!
 * \brief DataController::getListChannel
 * \return
 */
QList<int> DataController::getListChannel()
{
    return m_lstChannelNum;
}

QList<QString> DataController::getLstChannelName()
{
    return m_lstChannelName;
}

/*!
 * \brief DataController::makeCommandRequest
 * \param fncId
 * \param parameters
 */
void DataController::makeCommandRequest(int fncId, QString parameters)
{
    LOGI().writeFormatted("DataController::makeCommandRequest() called");
    if (m_sxmCmd != nullptr) {
        //         std::thread t1(&SxmCmd::parseCmd, m_sxmCmd, fncId, parameters);
        //         t1.join();
        m_sxmCmd->parseCmd(static_cast<UIBridge::E_HMI_EVENT_FNC_ID>(fncId), parameters);
    } else {
        LOGI().writeFormatted("DataController::makeCommandRequest() called m_sxmCmd is NULL");
    }
}

/*!
 * \brief DataController::eventSATDiagnostics
 * \param state
 */
void DataController::eventSATDiagnostics(const SXM_SATDIAGNOSTICS_T &data)
{
    Q_UNUSED(data)
    LOGI().writeFormatted("DataController::eventSATDiagnostics() called");
    try {
//        std::lock_guard<std::mutex> lock(m_mutex);
//        if (state == STATE_OK) {
//            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SAT_DIAGNOSTICS);
//        } else {
//            //
//        }
    } catch(std::exception &e) {
        LOGE().writeFormatted("Exception: %s", e.what());
    }
}

/*!
 * \brief DataController::eventInitState
 * \param state
 */
void DataController::eventInitState(const INIT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventInitState() called");
    if (state == INIT_COMPLETE)
        publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_INIT_STATE);
}

/*!
 * \brief DataController::eventSuperCategories
 * \param state
 */
void DataController::eventSuperCategories(const RESULT_STATE& state)
{
    LOGI().writeFormatted("DataController::eventSuperCategories() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            if (m_provider != nullptr) {
                m_provider->getSxm360lSuperCategoryList(m_superCategoryList);
            }
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SUPERCATEGORY);
        } else {
            return;
        }
    } catch(std::exception &e) {
        LOGE().writeFormatted("Exception: %s", e.what());
    }
}

/*!
 * \brief DataController::eventAllCategories
 * \param state
 */
void DataController::eventAllCategories(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventAllCategories() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            if (m_provider != nullptr) {
                m_provider->getSxm360lCategoryList(m_categoryList);
            }
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ALL_CATEGORIES);
        } else {
            //
        }
    } catch(std::exception &e) {
        LOGE().writeFormatted("Exception: %s", e.what());
    }
}

/*!
 * \brief DataController::eventCategories
 * \param state
 */
void DataController::eventCategories(const RESULT_STATE& state)
{
    LOGI().writeFormatted("DataController::eventCategories() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            if (m_provider != nullptr) {
                m_provider->getSxm360lCategoryList(m_categoryList);
                for(int i = 0; i < MAX_CATEGORY_COUNT; i++) {
                    if(strlen(m_categoryList.name[i]) <= 0)
                        continue;

                    //                printf("category name : %s\n", t360lCategoryList.name[i]);
                    //                printf("         logo : %s\n", t360lCategoryList.logo[i]);
                    ResourceManager::instance()->addCategoryLogo(m_categoryList.name[i],m_categoryList.logo[i]);
                }
            }
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_CATEGORIES);
        } else {
            return;
        }
    } catch(std::exception &e) {
        LOGE().writeFormatted("Exception: %s", e.what());
    }
}

/*!
 * \brief DataController::eventChannels
 * \param state
 */
void DataController::eventChannels(const RESULT_STATE& state)
{
    static bool isFirstRequest = false;

    LOGI().writeFormatted("DataController::eventChannels() called state [%d]", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            if (m_provider != nullptr) {
                m_provider->getSxm360lLiveChannelList(m_liveChannelList);

                //get new channel list
                if ((m_liveChannelList.deliveryState == CHANNEL_DELIVERY_START) ||
                        (m_liveChannelList.deliveryState == CHANNEL_DELIVERY_ONE_END)) {
                    LOGI().writeFormatted("DataController::eventChannels() called start channel list");
                    m_lstChannelInformation.clear();
                    if (isFirstRequest == false) {
                        m_allChannelInformation.clear();
                        m_lstChannelNum.clear();
                        m_lstChannelName.clear();
                    }
                }
                LOGI().writeFormatted("DataController::eventChannels() called m_liveChannelList.deliveryState %d", m_liveChannelList.deliveryState);

//                for(int i = 0; i < m_liveChannelList.packetTotal; i++) {
                for(int i = 0; i < MAX_SEND_CHANNEL_CNT; i++) {
                    LOGI().writeFormatted("DataController::eventChannels()m_liveChannelList.channel[i].name %s", m_liveChannelList.channel[i].name);
                    LOGI().writeFormatted("DataController::eventChannels()m_liveChannelList.channel[i].number %d", m_liveChannelList.channel[i].number);
                    LOGI().writeFormatted("DataController::eventChannels()m_liveChannelList.channel[i].shortDescription %s", m_liveChannelList.channel[i].shortDescription);

                    if(strlen(m_liveChannelList.channel[i].name) <= 0)
                        continue;
                    //make all channels are available
                    //make color
                    m_liveChannelList.channel[i].isAvailable = true;
                    m_lstChannelInformation.append(m_liveChannelList.channel[i]);

                    if (isFirstRequest == false) {
                        m_allChannelInformation.append(m_liveChannelList.channel[i]);
                        m_lstChannelNum.append(m_liveChannelList.channel[i].number);
                        m_lstChannelName.append(m_liveChannelList.channel[i].name);
                    }
                }

                //TODO: will be remove "(m_liveChannelList.packetTotal < MAX_SEND_CHANNEL_CNT)"
                if ((m_liveChannelList.deliveryState == CHANNEL_DELIVERY_END) ||
                        (m_liveChannelList.deliveryState == CHANNEL_DELIVERY_ONE_END)) {
                    LOGI().writeFormatted("DataController::eventChannels() called end channel list SIZE [%d]", m_lstChannelInformation.size());
                    SXMKeyPadHandler::instance()->createValidNumberMapping();

                    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNELS);
                    isFirstRequest = true;
                }
            }
        } else {
            LOGI().writeFormatted("DataController::eventChannels() called state %d", state);
        }
    } catch(std::exception &e) {
        LOGE().writeFormatted("DataController::eventChannels: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventChannelInformation
 * \param state
 */
void DataController::eventChannelInformation(const RESULT_STATE& state)
{
    LOGI().writeFormatted("DataController::eventChannelInformation() called");
    try {
    std::lock_guard<std::mutex> lock(m_mutex);
    if ((state == STATE_OK) && (m_provider != nullptr)) {
        m_provider->getSxm360lChannelInformation(m_channelInformation);
        m_isTuning = false;
        if(m_channelInformation.isNowPlaying){
            m_provider->getSxm360lChannelInformation(m_currentChannelIsNowPlaying);
        }
        publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_CHANNEL_INFORMATION);
    } else {
        return;
    }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventChannelInformation: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventSmartFavorites
 * \param state
 */
void DataController::eventSmartFavorites(const RESULT_STATE& state)
{
    LOGI().writeFormatted("DataController::eventSmartFavorites() called");
    try {
    std::lock_guard<std::mutex> lock(m_mutex);

    if (state == STATE_OK) {
        if (m_provider != nullptr) {
            m_provider->getSxm360lSmartFavorites(m_smartFavoriteList);
            //            for(int i = 0; i < MAX_SMART_FAVORITES_SIZE; i++) {
            //                printf("channel number %ld\n", m_smartFavoriteList.smartFavorite[i]);
            //            }
        }
        publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SMART_FAVORITES);
    } else {
        return;
    }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventSmartFavorites: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventSatSubscriptieventStatus
 * \param state
 */
void DataController::eventSatSubscriptieventStatus(const int &state)
{
    LOGI().writeFormatted("DataController::eventSatSubscriptieventStatus() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);

        publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SATSUBSCRIPTION_STATUS);
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventSatSubscriptieventStatus: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventSignalState
 * \param state
 */
void DataController::eventSignalState(const SIGNAL_STATE &state)
{
    LOGI().writeFormatted("DataController::eventSignalState() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        LOGI().writeFormatted("DataController::eventSignalState() called threadid %d", std::this_thread::get_id());
        if (state == SIGNALAVAILABLE) {
            m_isNoSignal = false;
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SIGNAL_STATE_AVAIABLE);
        }
        else {
            m_isNoSignal = true;
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SIGNAL_STATE_NOTAVAIABLE);
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventSignalState: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventAudioAvailability
 * \param state
 */
void DataController::eventAudioAvailability(const AUD_AVAIL_STATE &state)
{
    LOGI().writeFormatted("DataController::eventAudioAvailability() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        LOGI().writeFormatted("DataController::eventAudioAvailability() called threadid %d", std::this_thread::get_id());
        if (state == AUDIOAVAILABLE) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_AUDIO_AUDIOAVAILABLE);
        }
        else {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_AUDIO_AUDIONOTAVAILABLE);
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventAudioAvailability: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventFavorites
 * \param state
 */
void DataController::eventFavorites(const RESULT_STATE& state)
{
    LOGI().writeFormatted("DataController::eventFavorites() called state %d", state);
    try {
        if (state == STATE_OK) {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (m_provider != nullptr) {
                m_provider->getSxm360lFavorites(m_favoriteList);
                m_lstFavoriteList.clear();
                LOGI().writeFormatted("DataController::eventFavorites() called COUNT %d", m_favoriteList.count);
                for(int i = 0; i < m_favoriteList.count; i++) {
                    if(strlen(m_favoriteList.favorite[i].name) <= 0)
                        continue;
                    m_lstFavoriteList.append(m_favoriteList.favorite[i]);
                }
                publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_FAVORITES);

            }
//        }
//                if ((m_favoriteList.deliveryState == DELIVERY_START) ||
//                        (m_favoriteList.deliveryState == DELIVERY_ONE_END) ||
//                        (m_favoriteList.packetTotal == 1)) {
//                    LOGI().writeFormatted("DataController::eventFavorites() called start channel list");
//                    m_lstFavoriteList.clear();
//                }
//                for(int i = 0; i < MAX_FAVORITES_CNT; i++) {
//                    if(strlen(m_favoriteList.favorite[i].name) <= 0)
//                        continue;
//                    m_lstFavoriteList.append(m_favoriteList.favorite[i]);
//                }
//                if ((m_favoriteList.deliveryState == DELIVERY_END) ||
//                        (m_favoriteList.deliveryState == DELIVERY_ONE_END) ||
//                        (m_favoriteList.packetTotal == 1)) {
//                    LOGI().writeFormatted("DataController::eventFavorites() called end channel list");
//                    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_FAVORITES);
//                }
//            }
        } else {
            return;
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventFavorites: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventAddFavorite
 * \param state
 */
void DataController::eventAddFavorite(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventAddFavorite() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            //TODO: Shall check new data?
//            m_provider->getSxm360lChannelInformation(m_channelInformation);
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_FAVORITE);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventAddFavorite: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventRemoveFavorite
 * \param state
 */
void DataController::eventRemoveFavorite(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventRemoveFavorite() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            //TODO: Shall check new data?
//            m_provider->getSxm360lChannelInformation(m_channelInformation);
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_FAVORITE);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventRemoveFavorite: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventTuneFavorite
 * \param state
 */
void DataController::eventTuneFavorite(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventTuneFavorite() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_TUNE_FAVORITE);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventTuneFavorite: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventPlayback
 * \param state
 */
void DataController::eventPlayback(const PLAY_STATE &state)
{
    LOGI().writeFormatted("DataController::eventPlayback() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        setPlayState(state);
        publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_PLAYBACK_UPDATE);
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventPlayback: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventTuneChannel
 * \param state
 * \param channelNumber
 */
void DataController::eventTuneChannel(const RESULT_STATE &state, const uint32_t &channelNumber)
{
    LOGI().writeFormatted("DataController::eventTuneChannel() called state %d channel %d", state, channelNumber);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            ResourceManager::instance()->setCurrentChannelNumber(channelNumber);
//            makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNEL_INFORMATION, QString("%1").arg(channelNumber));
            //    if (m_provider != nullptr) {
            //        m_provider->getSxm360lChannelInformation(m_channelInformation);
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_TUNE_CHANNEL);
            //    }
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventTuneChannel: Exception %s", e.what());
    }
}

void DataController::eventTuneRequest(const LOADING_CHANNEL_INFORMATION_T &chInfo)
{
    LOGI().writeFormatted("DataController::eventTuneRequest() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_loadingChannelInfo = chInfo;
        m_isTuning = true;
//        LOGE().writeFormatted("DataController::eventTuneChannel: m_loadingChannelInfo.channelLogoUrl %s", m_loadingChannelInfo.channelLogoUrl);
//        LOGE().writeFormatted("DataController::eventTuneChannel: m_loadingChannelInfo channelNumber %d", m_loadingChannelInfo.channelNumber);
        publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_TUNE_REQUEST);
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventTuneChannel: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventTuneLastChannel
 * \param state
 * \param channelNumber
 */
void DataController::eventTuneLastChannel(const RESULT_STATE &state, const uint32_t &channelNumber)
{
    LOGI().writeFormatted("DataController::eventTuneLastChannel() called state %d channel %d", state, channelNumber);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            ResourceManager::instance()->setCurrentChannelNumber(channelNumber);
            // TODO: fix onChannelInformation is not occur
//            makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNEL_INFORMATION, QString("%1").arg(channelNumber));
//            m_provider->getSxm360lChannelInformation(m_channelInformation);
//            m_provider->getSxm360lChannelInformation(m_currentChannelIsNowPlaying);
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_TUNE_LAST_CHANNEL);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventTuneLastChannel: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventSeekChannel
 * \param state
 */
void DataController::eventSeekChannel(const RESULT_STATE &state, const uint32_t &channelNumber)
{
    LOGI().writeFormatted("DataController::eventSeekChannel() called state %d, channel number %d",
                          state, channelNumber);
    if (channelNumber > 0) {
        ResourceManager::instance()->setCurrentChannelNumber(channelNumber);
    }
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            if (m_provider != nullptr) {
//                m_provider->getSxm360lChannelInformation(m_channelInformation);
//                makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNEL_INFORMATION, QString("%1").arg(channelNumber));
                //make color code
                //            if (m_channelInformation.number <= 0) {
                //                LOGI().writeFormatted("DataController::eventSeekChannel() channel number %d",
                //                                      ResourceManager::instance()->getCurrentChannel());
                //                makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNEL_INFORMATION,
                //                                   QString("%1").arg(ResourceManager::instance()->getCurrentChannel()));
                //            } else {
                //end make color code
                //real code
                publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SEEK_CHANNEL);
                //            }
            }
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventSeekChannel: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventAddSongAlert
 * \param state
 */
void DataController::eventAddSongAlert(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventAddSongAlert() called state %d", state);

    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if ((state == STATE_OK) || (state == STATE_EXIST)) {
            //Update for nowPlaying information for song notification
            m_currentChannelIsNowPlaying.album.isFavoriteSong = true;

            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_SONG_ALERT);
        } else if (state == STATE_OVER) {
            //TODO: Change to over screen
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_ALERT_OVER);
    }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventAddSongAlert: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventAddArtistAlert
 * \param state
 */
void DataController::eventAddArtistAlert(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventAddArtistAlert() called state %d", state);

    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if ((state == STATE_OK) || (state == STATE_EXIST)){
            //Update for nowPlaying information for artist notification
            m_currentChannelIsNowPlaying.album.isFavoriteArtist = true;

            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_ARTIST_ALERT);
        } else if (state == STATE_OVER) {
            //TODO: Change to over screen
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_ALERT_OVER);
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventAddArtistAlert: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventRewind
 * \param state
 */
void DataController::eventRewind(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventRewind() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_REWIND);
        } else {

        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventRewind: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventFastForward
 * \param state
 */
void DataController::eventFastForward(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventFastForward() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_FAST_FORWARD);
        } else {

        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventFastForward: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventJumpPoint
 * \param state
 */
void DataController::eventJumpPoint(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventJumpPoint() called state %d", state);
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_JUMP_POINT);
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventJumpPoint: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventRecommendation
 * \param state
 */
void DataController::eventRecommendation(const RESULT_STATE& state)
{
    LOGI().writeFormatted("DataController::eventRecommendation() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            //Get recommendation list
            if (m_provider != nullptr) {
                //Clear all the old data
                m_lstRecommendation.clear();
                //Get Recommendation
                m_provider->getSxm360lRecommendedChannels(m_recommendedChannels);
                LOGI().writeFormatted("[DataController::eventRecommendation]NumberFavorite[%d]", m_recommendedChannels.count);
                for (int i = 0; i < m_recommendedChannels.count; i++){
                    if (strlen(m_recommendedChannels.channel[i].name) <= 0)
                        continue;
                    m_lstRecommendation.append(m_recommendedChannels.channel[i]);
                }
                publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_RECOMMENDATION);
            }
        }else{
            LOGI().writeFormatted("[DataController::eventRecommendation]StateFail");
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventRecommendation: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventListeningHistory
 * \param state
 */
void DataController::eventListeningHistory(const RESULT_STATE& state)
{
    LOGI().writeFormatted("DataController::eventListeningHIstory() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_LISTEN_HISTORY);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventListeningHistory: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventLastChannelInfo
 * \param state
 */
void DataController::eventLastChannelInfo(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventLastChannelInfo() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            if (m_provider != nullptr) {
                m_provider->getSxm360lChannelInformation(m_channelInformation);
                m_provider->getSxm360lChannelInformation(m_currentChannelIsNowPlaying);
                ResourceManager::instance()->setCurrentChannelNumber(m_channelInformation.number);
                //make color start
//                if (m_channelInformation.number <= 0)
//                    makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNEL_INFORMATION, "2");
//                else
                    //make color end
                publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_LAST_CHANNEL_INFO);
            }
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventLastChannelInfo: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventResumingSatelliteOnCompleted
 * \param none
 */
void DataController::eventResumingSatelliteOnCompleted()
{
    LOGI().writeFormatted("DataController::eventResumingSatelliteOnCompleted() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_RESUMING_ONCOMPLETED);
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventResumingSatelliteOnCompleted: Exception %s", e.what());
    }
}

//TODO: will be removed
/*!
 * \brief DataController::eventArtistAlerts
 * \param state
 */
void DataController::eventArtistAlerts(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventArtistAlerts() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            m_provider->getSxm360lArtistAndSongAlerts(m_artistAndSongAlerts);
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ARTIST_ALERTS);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventArtistAlerts: Exception %s", e.what());
    }
}

//TODO: will be removed
/*!
 * \brief DataController::eventSongAlerts
 * \param state
 */
void DataController::eventSongAlerts(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventSongAlerts() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            m_provider->getSxm360lArtistAndSongAlerts(m_artistAndSongAlerts);
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SONG_ALERTS);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventSongAlerts: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventArtistAndSOngAlerts
 * \param state
 */
void DataController::eventArtistAndSOngAlerts(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventArtistAndSOngAlerts() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            m_provider->getSxm360lArtistAndSongAlerts(m_artistAndSongAlerts);
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ARTIST_AND_SONG_ALERTS);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventArtistAndSOngAlerts: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventRemoveArtistAlert
 * \param state
 */
void DataController::eventRemoveArtistAlert(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventRemoveArtistAlert() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            LOGI().writeFormatted("DataController::eventRemoveArtistAlert() Set false");
            //Update for nowPlaying information for artist notification
            m_currentChannelIsNowPlaying.album.isFavoriteArtist = false;

            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_ARTIST_ALERT);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventRemoveArtistAlert: Exception %s", e.what());
    }
}
/*!
 * \brief DataController::eventRemoveSongAlert
 * \param state
 */
void DataController::eventRemoveSongAlert(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventRemoveSongAlert() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            //Update for nowPlaying information for song notification
            LOGI().writeFormatted("DataController::eventRemoveSongAlert() Set false");
            m_currentChannelIsNowPlaying.album.isFavoriteSong = false;

            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_SONG_ALERT);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventRemoveSongAlert: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventGetActiveProfiles
 * \param state
 */
void DataController::eventGetActiveProfiles(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventGetActiveProfiles() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_ACTIVE_PROFILES);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventGetActiveProfiles: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventCreateProfile
 * \param state
 */
void DataController::eventCreateProfile(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventCreateProfile() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_CREATE_PROFILE);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventCreateProfile: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventSetDefaultProfile
 * \param state
 */
void DataController::eventSetDefaultProfile(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventSetDefaultProfile() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SET_DEFAULT_PROFILE);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventSetDefaultProfile: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventSwitchProfile
 * \param state
 */
void DataController::eventSwitchProfile(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventSwitchProfile() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SWITCH_PROFILES);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventSwitchProfile: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventDeleteProfile
 * \param state
 */
void DataController::eventDeleteProfile(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventDeleteProfile() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_DELETE_PROFILE);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventDeleteProfile: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventModifyProfileName
 * \param state
 */
void DataController::eventModifyProfileName(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventModifyProfileName() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_MODIFY_PROFILE_NAME);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventModifyProfileName: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventModifyProfileAvatar
 * \param state
 */
void DataController::eventModifyProfileAvatar(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventModifyProfileAvatar() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_MODIFY_PROFILE_AVATAR);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventModifyProfileAvatar: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventGetSettingNotification
 * \param state
 */
void DataController::eventGetSettingNotification(const SETTING_NOTIFICATION_STATE &state)
{
    LOGI().writeFormatted("DataController::eventGetSettingNotification() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        LOGI().writeFormatted("DataController::eventGetSettingNotification() EnableNotification %d", state.EnableNotification);
        LOGI().writeFormatted("DataController::eventGetSettingNotification() ArtistAndSong %d", state.ArtistAndSong);
        LOGI().writeFormatted("DataController::eventGetSettingNotification() Sports %d", state.Sports);
        LOGI().writeFormatted("DataController::eventGetSettingNotification() ContinueListening %d", state.ContinueListening);
        //    if (state == STATE_OK) {
        //        publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_SETTING_NOTIFICATION);
        //    } else {
        //        //
        //    }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventGetSettingNotification: Exception %s", e.what());
    }
}

/*!
 * \brief DataController::eventSetSettingNotification
 * \param state
 */
void DataController::eventSetSettingNotification(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventSetSettingNotification() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SET_SETTING_NOTIFICATION);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventSetSettingNotification: Exception %s", e.what());
    }
}

void DataController::eventGetFavoriteTeams(const SPORTS_TEAM_FAVORITE_T &data)
{
    Q_UNUSED(data);
    LOGI().writeFormatted("DataController::eventGetFavoriteTeams() called");
}

void DataController::eventAddFavoriteTeam(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventAddFavoriteTeam() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_FAVORITE_TEAM);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventAddFavoriteTeam: Exception %s", e.what());
    }
}

void DataController::eventRemoveFavoriteTeam(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventRemoveFavoriteTeam() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_FAVORITE_TEAM);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventRemoveFavoriteTeam: Exception %s", e.what());
    }
}

void DataController::eventGetTeams(const RESULT_STATE &state, const int &count)
{
    Q_UNUSED(count);
    LOGI().writeFormatted("DataController::eventGetTeams() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (state == STATE_OK) {
            m_provider->getSxm360lSportsTeams(m_sportTeams);
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_TEAMS);
        } else {
            //
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventAddTeamAlerts: Exception %s", e.what());
    }
}

void DataController::eventGetLeagues(const SPORTS_LEAGUE_T &data)
{
//    Q_UNUSED(data);
    LOGI().writeFormatted("DataController::eventGetLeagues() called");
    setLeagues(data);
    m_sportLeagues.clear();
    for (int i = 0; i < data.count; i ++){
        m_sportLeagues.append(data.teams[i]);
    }
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_LEAGUE);

}

void DataController::eventAddTeamAlerts(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventAddTeamAlerts() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if ((state == STATE_OK) || (state == STATE_EXIST)){
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_TEAM_ALERTS);
        } else if (state == STATE_OVER) {
            //TODO: Change to over screen
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_ALERT_OVER);
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventAddTeamAlerts: Exception %s", e.what());
    }
}

void DataController::eventRemoveTeamAlerts(const RESULT_STATE &state)
{
    LOGI().writeFormatted("DataController::eventRemoveTeamAlerts() called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if ((state == STATE_OK) || (state == STATE_EXIST)){
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_REMOVE_ARTIST_ALERT);
        } else if (state == STATE_OVER) {
            //TODO: Change to over screen
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ADD_ALERT_OVER);
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventRemoveTeamAlerts: Exception %s", e.what());
    }
}

void DataController::eventGetTeamAlerts(const SPORTS_TEAM_ALERTS_T &data)
{
    Q_UNUSED(data);
    LOGI().writeFormatted("DataController::eventGetTeamAlerts() called:  count %d: ", data.count);
    m_teamAlerts.clear();
//    for (int i = 0; i < data.count; i ++){
//        m_teamAlerts.append(data.teams[i]);
//    }
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_TEAM_ALERT);

}

void DataController::eventGetCurrenIndexLinearTune()
{
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_GET_CURRENT_INDEX_LINEAR_TUNER);
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventAddTeamAlerts: Exception %s", e.what());
    }
}

void DataController::eventAntennaState(const ANTENNA_STATE &state)
{
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (UIBridge::E_HMI_EVENT_ANTENNA_OK == state) {
            m_isNoAntenna = false;
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ANTENNA_AVAILABLE);
        }
        else {
            m_isNoAntenna = true;
            publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_ANTENNA_NOT_AVAILABLE);
        }
    } catch (std::exception &e) {
        LOGE().writeFormatted("DataController::eventAddTeamAlerts: Exception %s", e.what());
    }
}

//make color
void DataController::generateFavoriteList(FAVORITE_LIST_T &_lstFavorite)
{
    for (int i = 0; i < MAX_FAVORITES_SIZE; ++i) {
//        _lstFavorite.packetTotal = MAX_FAVORITES_SIZE;
        _lstFavorite.favorite[i].type = static_cast<FAVORITE_TYPE>(i%5);
        strcpy(_lstFavorite.favorite[i].name, "Favorite Name");
        strcpy(_lstFavorite.favorite[i].id, "Favorite Id");
        strcpy(_lstFavorite.favorite[i].contextualBanner, "Contextual Banner");
        CHANNEL_INFORMATION_T channelInformation;
        strcpy(channelInformation.name, "Channel Name");
        strcpy(channelInformation.shortDescription, "Short Description");
        strcpy(channelInformation.category, "Music");
        strcpy(channelInformation.id, "Channel Id");
        strcpy(channelInformation.logoUrl, "/ivibcast/sxm360l/sxe_test/logoUrlChannel_1.png");
        channelInformation.number = i;
        channelInformation.sid = i;
        channelInformation.isAvailable = true;
        channelInformation.isFavorite = true;
        channelInformation.isPlayByPlay = false;
        channelInformation.isSatOnly = true;
        channelInformation.isFreeToAir = false;
        channelInformation.isSubscribed = true;
        channelInformation.isNowPlaying = false;
        _lstFavorite.favorite[i].channelInfo = channelInformation;
    }
}

void DataController::generateRecommendationList(LIVE_CHANNEL_LIST_T &_lstRecommendation)
{
    for(int i = 0; i < MAX_CHANNEL_BUFFER; ++i) {
        _lstRecommendation.packetTotal = MAX_CHANNEL_BUFFER;
        _lstRecommendation.deliveryState = CHANNEL_DELIVERY_END;
        CHANNEL_INFORMATION_T channelInformation;
        strcpy(channelInformation.show.contextualBanner, "");
        strcpy(channelInformation.name, "Channel Name");
        strcpy(channelInformation.shortDescription, "Short Description: Vanbom");
        strcpy(channelInformation.category, "Music");
        strcpy(channelInformation.id, "Channel Id");
        strcpy(channelInformation.logoUrl, "/ivibcast/sxm360l/sxe_test/logoUrlChannel_1.png");
        channelInformation.number = i;
        channelInformation.sid = i;
        channelInformation.isAvailable = true;
        channelInformation.isFavorite = true;
        channelInformation.isPlayByPlay = false;
        channelInformation.isSatOnly = true;
        channelInformation.isFreeToAir = false;
        channelInformation.isSubscribed = true;
        channelInformation.isNowPlaying = false;
        _lstRecommendation.channel[i] = channelInformation;
    }
}

void DataController::generateRelatedList(LIVE_CHANNEL_LIST_T &_lstRelated)
{
    for(int i = 0; i < MAX_CHANNEL_BUFFER; ++i) {
        _lstRelated.packetTotal = MAX_CHANNEL_BUFFER;
        _lstRelated.deliveryState = CHANNEL_DELIVERY_END;
        CHANNEL_INFORMATION_T channelInformation;
        strcpy(channelInformation.name, "Channel Name Related");
        strcpy(channelInformation.shortDescription, "Short Description: Vanbom");
        strcpy(channelInformation.category, "Music");
        strcpy(channelInformation.id, "Channel Id");
        strcpy(channelInformation.logoUrl, "/ivibcast/sxm360l/sxe_test/logoUrlChannel_1.png");
        channelInformation.number = i;
        channelInformation.sid = i;
        channelInformation.isAvailable = true;
        channelInformation.isFavorite = true;
        channelInformation.isPlayByPlay = false;
        channelInformation.isSatOnly = true;
        channelInformation.isFreeToAir = false;
        channelInformation.isSubscribed = true;
        channelInformation.isNowPlaying = false;
        _lstRelated.channel[i] = channelInformation;
    }
}

void DataController::generateHistoryList(LIVE_CHANNEL_LIST_T &lstHistory)
{
    lstHistory.packetTotal = MAX_CHANNEL_BUFFER;
    for(int i = 0; i < MAX_CHANNEL_BUFFER; ++i) {
        lstHistory.packetTotal = MAX_CHANNEL_BUFFER;
        lstHistory.deliveryState = CHANNEL_DELIVERY_END;
        CHANNEL_INFORMATION_T channelInformation;
        strcpy(channelInformation.name, "Channel Name History");
        strcpy(channelInformation.shortDescription, "Short Description: Vanbom History");
        strcpy(channelInformation.category, "Music");
        strcpy(channelInformation.id, "Channel Id");
        strcpy(channelInformation.logoUrl, "/ivibcast/sxm360l/sxe_test/logoUrlChannel_1.png");
        channelInformation.number = i;
        channelInformation.sid = i;
        channelInformation.isAvailable = true;
        channelInformation.isFavorite = true;
        channelInformation.isPlayByPlay = false;
        channelInformation.isSatOnly = true;
        channelInformation.isFreeToAir = false;
        channelInformation.isSubscribed = true;
        channelInformation.isNowPlaying = false;
        lstHistory.channel[i] = channelInformation;
    }
}

void DataController::generateArtistAndSongAlert(ARTIST_SONG_ALERTS_T &lstArtistSongAlerts)
{
//    ARTIST_ALERTS_T _artist;
//    SONG_ALERTS_T _song;
//    _artist.count = MAX_SONG_ALERT_CNT;
//    _song.count = MAX_ARTIST_ALERT_CNT;
    lstArtistSongAlerts.count = 4;
//    for (int i = 0; i < MAX_SONG_ALERT_CNT/2; i++) {
    for (int i = 0; i < 2; i++) {
        memcpy(lstArtistSongAlerts.name[i],"Artist Vanbom",13);
        lstArtistSongAlerts.type[i] = ArtistAlert;
    }

    for (int i = 0; i < 2; i++) {
        memcpy(lstArtistSongAlerts.name[i],"Song Vanbom",11);
        lstArtistSongAlerts.type[i] = SongAlert;
    }

//    lstArtistSongAlerts.artist = _artist;
    //    lstArtistSongAlerts.song = _song;
}

void DataController::setLeagues(const SPORTS_LEAGUE_T &leaguesInfo)
{
    LOGI().writeFormatted("DataController::setLeagues: Called");
    m_leaguesMap.clear();
    for (int i = 0; i < leaguesInfo.count; i++) {
        m_leaguesMap.insert(leaguesInfo.teams[i].id, leaguesInfo.teams[i].name);
    }
}

int DataController::lookupLeagueId(const QString &leagueName)
{
    int leaguesId = -1;
    bool isExist = false;
    QMap<int, QString>::const_iterator i = m_leaguesMap.constBegin();
    while (i != m_leaguesMap.constEnd()) {
        isExist = leagueName.contains(i.value());
        if (isExist){
            leaguesId = i.key();
            LOGI().writeFormatted("DataController::lookupLeagueId: %d", leaguesId);
            break;
        }
        ++i;
    }
    return leaguesId;
}

int DataController::getChnNumFromChnName(QString chnName)
{
    return m_lstChannelNum.at(m_lstChannelName.indexOf(QRegExp(chnName, Qt::CaseInsensitive)));
}

#ifndef EXCLUDE_SPEECH
void DataController::retrieveTeleprompterShowInfo()
{
    m_speechProvider->getSCFATeleprompterShowInfo_SHMEM(m_scfaInfo);
    SPEECH_STRING_T strVideo = m_scfaInfo.strVideo;
    int32_t nNumText = m_scfaInfo.nNumText;
    LOGI().writeFormatted("[DataController::retrieveTeleprompterShowInfo][%s][%d]", strVideo.sName, nNumText);
    for (int32_t i = 0; i < nNumText; i++){
        SPEECH_STRING_T tmp = m_scfaInfo.listText[i];
        LOGI().writeFormatted("[DataController::retrieveTeleprompterShowInfo][%s][%d]", tmp.sName, i);
    }
}

void DataController::retrieveListShowInfo()
{
    m_speechProvider->getSCFAListShowInfo_SHMEM(m_scfaListShowInfo);
    SPEECH_STRING_T strVideo = m_scfaListShowInfo.strVideo;
    int32_t nNumText = m_scfaListShowInfo.nNumText;
    SPEECH_STRING_T tmp;
    LOGI().writeFormatted("[DataController::retrieveListShowInfo][%s][%d]", strVideo.sName, nNumText);
    for (int32_t i = 0; i < nNumText; i++){
        SPEECH_STRING_T tmp = m_scfaInfo.listText[i];
        LOGI().writeFormatted("[DataController::retrieveListShowInfo][%s][%d]", tmp.sName, i);
    }
}

void DataController::eventScfaListPage(const E_VIDEO_TUNER_PAGE_NAVIGATION pageNavigation)
{
    updateData(DataIdentifier::E_DATA_IDENTIFIER_SPEECH_MODE_LIST_PAGE_NAVIGATION, QString::number(pageNavigation));
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_PAGE_NAVIGATION);
}

void DataController::eventScfaListDataGet(const int32_t nLineNum)
{
    updateData(DataIdentifier::E_DATA_IDENTIFIER_SPEECH_MODE_LIST_DATA_GET_LINE_NUM, QString::number(nLineNum));
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_DATA_GET_LINE_NUM);
}

void DataController::eventScfaListFocusSet(const int32_t absoluteIdx)
{
    updateData(DataIdentifier::E_DATA_IDENTIFIER_SPEECH_MODE_LIST_FOCUS_SET, QString::number(absoluteIdx));
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_LIST_FOCUS_SET);
}

void DataController::eventSpeechSdarsTeamData()
{
    m_speechProvider->getSDARSTeamData_SHMEM(m_speechTeamData);
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_TEAM_DATA);
}

void DataController::eventSpeechSdarsDataChannel()
{
    LOGI().writeFormatted("[DataController::eventSpeechSdarsDataChannel]Called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (m_provider != nullptr) {
            m_speechProvider->getSDARSChannelData_SHMEM(m_speechDataChannelPackage);
            if ((m_speechDataChannelPackage.deliveryState == CHANNEL_DELIVERY_START) ||
                    (m_speechDataChannelPackage.deliveryState == CHANNEL_DELIVERY_ONE_END)) {
                m_speechDataChannel.clear();
            }
            for(int i = 0; i < MAX_SEND_CHANNEL_CNT; i++) {
                if(strlen(m_speechDataChannelPackage.channel[i].name) <= 0)
                    continue;
                m_speechDataChannel.append(m_speechDataChannelPackage.channel[i]);
            }
            if ((m_speechDataChannelPackage.deliveryState == CHANNEL_DELIVERY_END) ||
                    (m_speechDataChannelPackage.deliveryState == CHANNEL_DELIVERY_ONE_END)) {
                LOGI().writeFormatted("DataController::eventChannels()SIZE list live channels %d", m_speechDataChannel.size());
                publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_DATA_CHANNEL);
            }
        }
    } catch(std::exception &e) {
        LOGE().writeFormatted("DataController::eventSpeechSdarsDataChannelException %s", e.what());
    }
}

void DataController::eventSpeechSdarsCategorySatList()
{
    LOGI().writeFormatted("[DataController::eventSpeechSdarsCategorySatList]");
    m_speechProvider->getSDARSCategoryData_SHMEM(m_speechCategorySatList);
    publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_CATEGORY_SAT_LIST);
}

void DataController::eventSpeechSdarsCategoryChannel(QString category)
{
    LOGI().writeFormatted("[DataController::eventSpeechSdarsCategoryChannel]Called");
    try {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (m_provider != nullptr) {
            m_speechProvider->getSDARSChannelData_SHMEM(m_speechDataChannelPackage);
            if ((m_speechDataChannelPackage.deliveryState == CHANNEL_DELIVERY_START) ||
                    (m_speechDataChannelPackage.deliveryState == CHANNEL_DELIVERY_ONE_END)) {
                m_speechDataChannel.clear();
            }
            for(int i = 0; i < MAX_SEND_CHANNEL_CNT; i++) {
                if(strlen(m_speechDataChannelPackage.channel[i].name) <= 0)
                    continue;
                m_speechDataChannel.append(m_speechDataChannelPackage.channel[i]);
            }
            if ((m_speechDataChannelPackage.deliveryState == CHANNEL_DELIVERY_END) ||
                    (m_speechDataChannelPackage.deliveryState == CHANNEL_DELIVERY_ONE_END)) {
                LOGI().writeFormatted("[DataController::eventSpeechSdarsCategorySatList]Size[%d]", m_speechDataChannel.size());
                publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER_SXM_SPEECH_MODE_SDARS_CATEGORY_CHANNEL);
            }
        }
    } catch(std::exception &e) {
        LOGE().writeFormatted("[DataController::eventSpeechSdarsCategoryChannel]Exception[%s]", e.what());
    }
}
#endif

