#include "DataNotifier.h"

/*!
 * \brief DataNotifier::DataNotifier
 * \param notifiedEvent
 * \param parent
 */
DataNotifier::DataNotifier(const QVector<DataIdentifier::E_EVENT_NOTIFIER> notifiedEvent,QObject *parent)
    : QObject(parent)
{
    for (int i = 0; i < notifiedEvent.size(); ++i) {
        m_notifiedEvent.insert(notifiedEvent[i], i);
    }
}

/*!
 * \brief DataNotifier::notifiedEvent
 * \return
 */
int DataNotifier::notifiedEvent() const
{
    return static_cast<int>(m_notifiedEvent.size());
}

/*!
 * \brief DataNotifier::addNotifiedEvent
 * \param eventId
 * \return
 */
bool DataNotifier::addNotifiedEvent(DataIdentifier::E_EVENT_NOTIFIER eventId)
{
    if (existNotifiedEvent(eventId) == true) {
        return false;
    } else {
        m_notifiedEvent.insert(eventId, 1);
        return true;
    }
}

/*!
 * \brief DataNotifier::removeNotifiedEvent
 * \param eventId
 * \return
 */
bool DataNotifier::removeNotifiedEvent(DataIdentifier::E_EVENT_NOTIFIER eventId)
{
    if (existNotifiedEvent(eventId) == true) {
        int removedItemNo = m_notifiedEvent.remove(eventId);
        Q_UNUSED(removedItemNo);
        return true;
    } else {
        return false;
    }
}

/*!
 * \brief DataNotifier::existNotifiedEvent
 * \param eventId
 * \return
 */
bool DataNotifier::existNotifiedEvent(DataIdentifier::E_EVENT_NOTIFIER eventId)
{
    return m_notifiedEvent.contains(eventId);
}

/*!
 * \brief DataNotifier::notifyEvent
 * \param eventId
 */
void DataNotifier::notifyEvent(DataIdentifier::E_EVENT_NOTIFIER eventId)
{
    emit eventScreenUpdate(eventId);
}
