#ifndef SXMCMD_H
#define SXMCMD_H

#include "sxm360l/Sxm360lMsgDef.h"
#include "ISxmCmd.h"
#include "appservice/AppMsgDef.h"
#include "keyboardservice/KeyboardMsgDef.h"
#include "popupservice/PopupMsgDef.h"
#include "UIBridge.h"
#include "Common/Utils.h"

class SxmCmd : public ISxmCmd
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SxmCmd(QString module, SxmServiceInterface* _interface,
           SxmAppServiceInterface* _appInterface,
           SxmKeyboardInterface* _keyboardInterface,
           SxmSpeechServiceInterface *speechInterface,
           SxmPopupServiceInterface* _popupInterface,
           QObject* parent= nullptr);
    virtual ~SxmCmd();

protected:
    bool implementCmd(UIBridge::E_HMI_EVENT_FNC_ID fncId, QStringList parameterList);
    void connectToInterface();

signals:
     void eventRequestSATDiagnostics();
     void eventRequestInitSet(const int& id, const bool& bFlag, const char* msg);
     void eventRequestInitState();
     void eventRequestSuperCategories();
     void eventRequestAllCategories();
     void eventRequestCategories(const char* superCategory);
     void eventRequestChannels(const char* category);
     void eventRequestChannels();
     void eventRequestChannelInformation(const uint32_t channelNumber);
     void eventRequestFavorites();
     void eventRequestAddFavorite(const uint32_t channelNumber);
     void eventRequestRemoveFavorite(const uint32_t channelNumber);
     void eventRequestTuneFavorite(const uint32_t channelNumber);
     void eventRequestSmartFavorites();
     void eventRequestMoveFavorite(const uint32_t index, const uint32_t new_index);
     void eventRequestPlayback(const PLAY_STATE state);
     void eventRequestTune(const uint32_t& channelNumber);
     void eventRequestTuneLastChannel();
     void eventRequestSeekChannel(const SEEK_ACTION action);
     void eventRequestSongAlerts();
     void eventRequestArtistAlerts();
     void eventRequestArtistAndSongAlerts();
     void eventRequestAddSongAlert(const char* songTitle);
     void eventRequestAddArtistAlert(const char* artistName);
     void eventRequestRemoveSongAlert(const char* songTitle);
     void eventRequestRemoveArtistAlert(const char* artistName);
     void eventRequestRewind(const uint32_t step);
     void eventRequestFastForward(const uint32_t step);
     void eventRequestJumpPoint(const uint32_t point);
     void eventRequestRecommendation();
     void eventRequestListeningHistory();
     void eventRequestLastChannelInfo();

     void eventRequestGetChannelList(const int _count);
     void eventRequestToGoApplication(const int& requestID, const char* strAppBinaryName, const char* strAppRole, const char* strIntent, const E_SHOW_OPT& eShowOpt=E_SHOW_OPT_CLEAR_AND_ADD);
     void eventRequestToShowSystemComponent(const int& requestId, const E_SYSTEM_COMPONENT& eSystemComponent, const char* strData=STRING_DATA_NONE);
     void eventRequestToHideSystemComponent(const int& requestId, const E_SYSTEM_COMPONENT& eSystemComponent, const char* strData=STRING_DATA_NONE);
     //Test loss signal
     void eventRequestTestLossSignal();
     // event when [PlayerResumingSatelliteBroadcastChannel.qml] completed
     void eventRequestResumingSatelliteOnCompleted();
     //Profile
     void eventRequestGetActiveProfiles();
     void eventRequestCreateProfile(const char* name);
     void eventRequestSetDefaultProfile();
     void eventRequestSwitchProfile(const char* name);
     void eventRequestDeleteProfile();
     void eventRequestModifyProfileName(const char* name);
     void eventRequestModifyProfileAvatar(const char* logoUrl);
    //Setting Notification
     void eventRequestGetSettingNotification();
     void eventRequestSetSettingNotification(const SETTING_NOTIFICATION_STATE state);
     //make color
     void eventRequestRelatedList();
     //make color

     // Sport Team
     void eventRequestAddFavoriteTeam(const SPORTS_TEAM_TYPE type);
     void eventRequestRemoveFavoriteTeam(const int teamId);
     void eventRequestGetTeams(const int leagueId);
     void eventRequestGetLeagues();
     void eventRequestAddTeamAlerts(const int teamId);
     void eventRequestRemoveTeamAlerts(const int teamId);
     void eventRequestGetTeamAlerts();
     void eventRequestGetFavoriteTeams();
//     void eventRequestGetLiveSports();
//     void eventRequestTuneLiveSports(const int leagueId);
     void eventRequestSatSubscriptionState();
     void eventRequestGetAntennaState();

     //keyboard
     void eventRequestShowKeyboard(const uint32_t& clientSessionID, const E_KEYBOARD_TYPE& eKeyboardType, const char* preFilledText, const char* defaultText, const uint32_t& maxLength);
     void eventRequestHideKeyboard(const uint32_t& clientSessionID);
     void eventResponseCandidateInfo(const uint32_t& clientSessionID, const uint32_t& userInputID, const char* suggestionResultContext);
     void eventResponseCandidateList(const uint32_t& clientSessionID, const uint32_t& candidateSessionID, const char* userInputText, const uint32_t& startIndex, const uint32_t& endIndex);

     //Speech mode
     void eventRequestSpeechModePttLongPress();
     void eventRequestSpeechModeSelect(QStringList param);
     void eventRequestSpeechModeTpSelect(int num);
     void eventRequestSpeechModeScrollStart();
     void eventRequestSpeechModeScrollStop();
     void eventRequestSpeechModeResponseListPage(bool result);
     void eventRequestSpeechModeResponseLineNumAbsoluteIdx(int absoluteIdx);
     void eventRequestSpeechModeResponseListFocusSet(bool result);
     void eventRequestSpeechModeSdarsTeamData();
     void eventRequestSpeechModeSdarsDataChannel();
     void eventRequestSpeechModeSdarsCategorySatList();
     void eventRequestSpeechModeSdarsCategoryChannel(QString category);
     // speech voicetag
     void eventRequestSpeechModeVoicetagFavorite(const uint32_t& number);
     void eventRequestSpeechModeVoicetagChannel(QString& number);
     void eventRequestSpeechModeVoicetagChannelInput(QString& number);

     //PopUp
     void eventRequestShowPopup(const uint32_t& clientSessionID, const E_POPUP_TYPE& ePopupType, const E_POPUP_SIDE_TYPE& ePopupSideType, const E_POPUP_SIZE& ePopupSize, const char* popupContext, const uint32_t& priority);
     void eventRequestHidePopup(const uint32_t& clientSessionID, const uint32_t& handle);
     void eventRequestUpdatePopup(const uint32_t& clientSessionID, const uint32_t& handle, const char* popupContext);
     void eventRequestShowScpecialPopup(const uint32_t& clientSessionID, const E_SPECIAL_POPUP_TYPE& eSpecialPopupType, const char* popupContext, const uint32_t& priority);

private:
     void requestSATDiagnostics();
     void requestInitSet(QStringList);
     void requestInitState();
     void requestSuperCategories();
     void requestAllCategories();
     void requestCategories(QStringList);
     void requestChannels(QStringList);
     void requestChannels();
     void requestChannelInformation(QStringList);
     void requestFavorites();
     void requestAddFavorite(QStringList);
     void requestRemoveFavorite(QStringList);
     void requestTuneFavorite(QStringList);
     void requestSmartFavorites();
     void requestMoveFavorites(QStringList);
     void requestPlayback(QStringList);
     void requestTuneChannel(QStringList);
     void requestTuneLastChannel();
     void requestSeekChannel(QStringList);
     void requestSongAlerts();
     void requestArtistAlerts();
     void requestArtistAndSongAlerts();
     void requestAddSongAlert(QStringList);
     void requestAddArtistAlert(QStringList);
     void requestRemoveSongAlert(QStringList);
     void requestRemoveArtistAlert(QStringList);
     void requestRewind(QStringList);
     void requestFastForward(QStringList);
     void requestJumpPoint(QStringList);
     void requestRecommendation();
     void requestListeningHistory();
     void requestLastChannelInfo();

     void requestGetChannelList(QStringList);

     void requestToGoApplication(QStringList);
     void requestToShowSystemComponent(QStringList);
     void requestToHideSystemComponent(QStringList);
     //Test loss signal
     void requestTestLossSignal();
     // request when [PlayerResumingSatelliteBroadcastChannel.qml] completed
     void requestResumingSatelliteOnCompleted();
     //Profile
     void requestGetActiveProfiles();
     void requestCreateProfile(QStringList);
     void requestSetDefaultProfile();
     void requestSwitchProfile(QStringList);
     void requestDeleteProfile();
     void requestModifyProfileName(QStringList);
     void requestModifyProfileAvatar(QStringList);
     void requestGetSettingNotification();
     void requestSetSettingNotification(QStringList);
     //make color start
     void requestRelatedList();
     //make color end
     // Sport Team
     void requestAddFavoriteTeam(QStringList);
     void requestRemoveFavoriteTeam(QStringList);
     void requestGetTeams(QStringList);
     void requestGetLeagues();
     void requestAddTeamAlerts(QStringList);
     void requestRemoveTeamAlerts(QStringList);
     void requestGetTeamAlerts();
     void requestGetFavoriteTeams();
//     void requestGetLiveSports();
//     void requestTuneLiveSports(QStringList);
     void requestSatSubscriptionState();
     void requestGetAntennaState();
     void requestGetCurrentIndexLinearTune();

     //keyboard
     void requestShowKeyboard(QStringList _parameter);
     void requestHideKeyboard(QStringList _parameter);
     void responseCandidateInfo(QStringList _parameter);
     void responseCandidateList(QStringList _parameter);

     //Speech
     void requestSpeechModePttLongPress();
     void requestSpeechModeSelect(QStringList parameterList);
     void requestSpeechModeTpSelect(QStringList parameterList);
     void requestSpeechModeScrollStart(QStringList parameterList);
     void requestSpeechModeScrollStop(QStringList parameterList);
     void requestSpeechModeResponseListPage(QStringList parameterList);
     void requestSpeechModeResponseLineNumAbsoluteIdx(QStringList parameterList);
     void requestSpeechModeResponseListFocusSet(QStringList parameterList);
     void requestSpeechModeSdarsTeamData();
     void requestSpeechModeSdarsDataChannel();
     void requestSpeechModeSdarsCategorySatList();
     void requestSpeechModeSdarsCategoryChannel(QStringList parameterList);
     void requestSpeechModeListCurrentIndexChanged(QStringList parameterList);
     void requestSpeechModeVoicetagsFavorite(QStringList parameterList);
     void requestSpeechModeVoicetagsChannel(QStringList parameterList);
     void requestSpeechModeVoicetagsChannelInput(QStringList parameterList);

     //PopUp
     void requestShowPopup(QStringList _parameter);
     void requestHidePopup(QStringList _parameter);
     void requestUpdatePopup(QStringList _parameter);
     void requestShowScpecialPopup(QStringList _parameter);
};

#endif // SXMCMD_H
