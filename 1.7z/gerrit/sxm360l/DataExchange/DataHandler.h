#ifndef DATAHANDLER_H
#define DATAHANDLER_H

#include <memory>
#include <QObject>
#include "Common/Utils.h"
#include "DataIdentifier.h"

class DataNotifier;
class DataController;

class DataHandler : public QObject
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    explicit DataHandler(QObject *parent = nullptr);
    virtual ~DataHandler();
    virtual void registerNotifiedDpId() = 0;
    virtual void onDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventId) = 0;

    void lockHandler(bool locked);
    bool lockStatus() const;

public slots:
    void onEventDataChanged(DataIdentifier::E_EVENT_NOTIFIER eventId);

protected:
    bool registerNotifier(QVector<DataIdentifier::E_EVENT_NOTIFIER> notifierDpId);

private:
//    DataController* m_dataController;
    DataNotifier* m_dataNotifier;
    mutable bool m_lockStatus;
};

#endif // DATAHANDLER_H
