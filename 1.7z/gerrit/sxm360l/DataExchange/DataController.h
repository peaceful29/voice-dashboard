#ifndef DATACONTROLLER_H
#define DATACONTROLLER_H

#include <vector>
#include <unordered_map>
#include <QDateTime>

#include "Common/Utils.h"
#include "Common/SingletonHmi.h"
#include "sxm360l/Sxm360lMsgDef.h"
#include "appservice/AppMsgDef.h"
#include "userinput/UserinputMsgDef.h"
#include "speech/SpeechProvider.h"
#include "DataIdentifier.h"
#include "SXMDefine.h"
#include <QMap>

class SxmServiceInterface;
class SxmAppServiceInterface;
class SxmKeyboardInterface;
class SxmPopupServiceInterface;
class Sxm360lProvider;
class DataNotifier;
class SxmCmd;
class SxmSpeechServiceInterface;

class DataController: public SingletonHmi<DataController>
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    friend class SingletonHmi<DataController>;
public:
    static DataController *instance();

    void initialize(SxmServiceInterface *_interface, SxmAppServiceInterface* _appInterface,
                    SxmKeyboardInterface* _keyboardInterface, SxmSpeechServiceInterface *speechInterface, SxmPopupServiceInterface* _popupInterface);
    bool registerDataNotifier(DataNotifier *dataNotifier);
    bool deregisterDataNotifier(DataNotifier *dataNotifier);
    void requestDataDependScreen(int screenId);

    // Get data
    QString getData(const DataIdentifier::E_DATA_IDENTIFIER dataId);
    QString getDataBefore(uint32_t dpId);
    uint64_t getDataUpdateTimeStamp(uint32_t dpId);

    SUPER_CATEGORY_LIST_T &getSuperCategorList();
    CATEGORY_LIST_T &getCategoryList();
    ALBUM_INFORMATION_T &getAlbumInformation();
    RECOMMENDED_SHOW_T &getShowInformation();
    CHANNEL_INFORMATION_T &getChannelInformation();
    LIVE_CHANNEL_LIST_T &getLiveChannelList();
    IMAGE_SET_LIST_T &getImageSetList();
    SMART_FAVORITE_LIST_T &getSmartFavoriteList();
//    SHOW_CHANNEL_LIST_T &getShowChannelList();
    FAVORITE_LIST_T &getFavoriteList();
    SPORTS_TEAM_T& getSportTeams();
    // voicetags
    int getFavoriteInformation(FAVORITE_T& favoriteInfor, const unsigned int& number);
    //TO DO ha.tran getChannelInformation by channel number for voicetag SXM_CHANNEL
    int getChannelInformation(CHANNEL_INFORMATION_T& channelInfor, const unsigned int& number);

#ifndef EXCLUDE_SPEECH
    SPEECH_SCFA_TELEPROMPTERSHOW_INFO_ST getScfaTeleprompterShowInfo();
    SPEECH_SCFA_LISTSHOW_INFO_ST getScfaListShowInfo();
    SPEECH_SDARS_TEAM_DATA getSpeechSdarsTeamData();
    QList<CHANNEL_INFORMATION_T>& getSpeechDataChannel();
    SPEECH_SDARS_CATEGORY_LIST getSpeechCategorySatList();
    void currentIndexListSpeechModeChanged(int value);
    void resetCurrentIndexListSpeechMode();
#endif
//    ARTIST_LIST_T &getArtistList();
//    SONG_LIST_T &getSongList();
    QList<int> getListChannel();
    QList<QString> getLstChannelName();
    //Execute command request
    void makeCommandRequest(int fncId, QString parameters);

    //SxmService send signal
    void eventSATDiagnostics(const SXM_SATDIAGNOSTICS_T &data);
    void eventInitState(const INIT_STATE& state);
    void eventSuperCategories(const RESULT_STATE& state);
    void eventAllCategories(const RESULT_STATE& state);
    void eventCategories(const RESULT_STATE& state);
    void eventChannels(const RESULT_STATE& state);
    void eventChannelInformation(const RESULT_STATE& state);
    void eventFavorites(const RESULT_STATE& state);
    void eventAddFavorite(const RESULT_STATE& state);
    void eventRemoveFavorite(const RESULT_STATE& state);
    void eventTuneFavorite(const RESULT_STATE& state);
    void eventSmartFavorites(const RESULT_STATE& state);
    void eventSatSubscriptieventStatus(const int& state);
    void eventSignalState(const SIGNAL_STATE& state);
    void eventAudioAvailability(const AUD_AVAIL_STATE& state);
    void eventPlayback(const PLAY_STATE& state);
    void eventTuneChannel(const RESULT_STATE& state, const uint32_t& channelNumber);
    void eventTuneRequest(const LOADING_CHANNEL_INFORMATION_T &chInfo);
    void eventTuneLastChannel(const RESULT_STATE& state, const uint32_t& channelNumber);
    void eventSeekChannel(const RESULT_STATE& state, const uint32_t& channelNumber);
    void eventAddSongAlert(const RESULT_STATE& state);
    void eventAddArtistAlert(const RESULT_STATE& state);
    void eventRewind(const RESULT_STATE& state);
    void eventFastForward(const RESULT_STATE& state);
    void eventJumpPoint(const RESULT_STATE& state);
    void eventRecommendation(const RESULT_STATE& state);
    void eventListeningHistory(const RESULT_STATE& state);
    void eventLastChannelInfo(const RESULT_STATE& state);
    //
    void eventResumingSatelliteOnCompleted();
    void eventArtistAlerts(const RESULT_STATE& state);
    void eventSongAlerts(const RESULT_STATE& state);
    void eventArtistAndSOngAlerts(const RESULT_STATE& state);
    void eventRemoveArtistAlert(const RESULT_STATE& state);
    void eventRemoveSongAlert(const RESULT_STATE& state);
    // Profile
    void eventGetActiveProfiles(const RESULT_STATE& state);
    void eventCreateProfile(const RESULT_STATE& state);
    void eventSetDefaultProfile(const RESULT_STATE& state);
    void eventSwitchProfile(const RESULT_STATE& state);
    void eventDeleteProfile(const RESULT_STATE& state);
    void eventModifyProfileName(const RESULT_STATE& state);
    void eventModifyProfileAvatar(const RESULT_STATE& state);
    //Setting Notification
    void eventGetSettingNotification(const SETTING_NOTIFICATION_STATE& state);
    void eventSetSettingNotification(const RESULT_STATE& state);
    //Sport Team
    void eventGetFavoriteTeams(const SPORTS_TEAM_FAVORITE_T &data);
    void eventAddFavoriteTeam(const RESULT_STATE& state);
    void eventRemoveFavoriteTeam(const RESULT_STATE& state);
    void eventGetTeams(const RESULT_STATE& state, const int& count);
    void eventGetLeagues(const SPORTS_LEAGUE_T& data);
    void eventAddTeamAlerts(const RESULT_STATE& state);
    void eventRemoveTeamAlerts(const RESULT_STATE& state);
    void eventGetTeamAlerts(const SPORTS_TEAM_ALERTS_T& data);

    void eventGetCurrenIndexLinearTune();
    void eventAntennaState(const ANTENNA_STATE& state);

    QList<CHANNEL_INFORMATION_T> &getLstChannelInformation();
    void setAllChannelInformation(const int index, CHANNEL_INFORMATION_T &element);

    bool getIsChannelListFinished() const;

    void eventGetChannelList(const int count = 0);

    QList<CHANNEL_INFORMATION_T> &getRecommendationList();

    LIVE_CHANNEL_LIST_T &getRecommendedChannels();

    QList<CHANNEL_INFORMATION_T> &getAllChannelInformation();
    LOADING_CHANNEL_INFORMATION_T &getLoadingChannelInfo();

    QList<FAVORITE_T>& getListFavorite();

    //App service notify
    void eventShowSystemComponent(const int _requestID, E_REQ_RESULT_MSG eResult);
    void eventHideSystemComponent(const int _requestID, E_REQ_RESULT_MSG eResult);
    void eventCmdGoBack(const int requestID);
    void eventButtonHardkey(const E_SWITCH &eSwitchType, const E_BUTTON &eButton, const E_ACTION &eAction);
    //make color start
    LIVE_CHANNEL_LIST_T &getRelatedList();
    LIVE_CHANNEL_LIST_T &getHistoryList();
    void eventRelatedList();
    //make color end
    ARTIST_SONG_ALERTS_T& getArtistAndSongAlerts();
    QList<TEAM_INFO_T>& getTeamAlerts();
    QList<LEAGUE_INFO_T>& getSportLeagues();

    void setArtistAndSongAlerts(const ARTIST_SONG_ALERTS_T &artistAndSongAlerts);

    CHANNEL_INFORMATION_T &getCurrentChannelIsNowPlaying();

    uint8_t getPlayState() const;
    void setPlayState(const uint8_t &playState);
    //TODO: will be delete
    int lookupLeagueId(const QString &value);
    int getChnNumFromChnName(QString chnName);
    ////////////////////////////////////////////////////////////////
    ///For speech mode
#ifndef EXCLUDE_SPEECH
    void retrieveTeleprompterShowInfo();
    void retrieveListShowInfo();
    void eventScfaListPage(const E_VIDEO_TUNER_PAGE_NAVIGATION pageNavigation);
    void eventScfaListDataGet(const int32_t nLineNum);
    void eventScfaListFocusSet(const int32_t absoluteIdx);
    void eventSpeechSdarsTeamData();
    void eventSpeechSdarsDataChannel();
    void eventSpeechSdarsCategorySatList();
    void eventSpeechSdarsCategoryChannel(QString category);
#endif

    bool getIsNoSignal() const;
    void setIsNoSignal(bool isNosignal);

    ANTENNA_STATE getAntennaState() const;
    void setAntennaState(const ANTENNA_STATE &antennaState);

    bool getIsNoAntenna() const;

    bool getIsTuning() const;
    void setIsTuning(bool isTuning);

protected:
    virtual ~DataController();
private:

    DataController();
    void updateData(const DataIdentifier::E_DATA_IDENTIFIER _dpId, QString _value);
    void publishToSubscribe(DataIdentifier::E_EVENT_NOTIFIER _eventId);

    std::vector<DataNotifier*> m_dataNotifiers;
    std::unordered_map<uint32_t, QString> m_mapDpIdValue;
    std::unordered_map<uint32_t, QString> m_mapDpIdValueBefore;
    std::unordered_map<uint32_t, qint64> m_mapDpidValueUpdateTime;
    Sxm360lProvider *m_provider;

    SUPER_CATEGORY_LIST_T m_superCategoryList;
    CATEGORY_LIST_T m_categoryList;
    ALBUM_INFORMATION_T m_albumInformation;
//    RECOMMENDED_SHOW_T m_showInformation;
    LOADING_CHANNEL_INFORMATION_T m_loadingChannelInfo;
    CHANNEL_INFORMATION_T m_channelInformation;
    LIVE_CHANNEL_LIST_T m_liveChannelList;
    CHANNEL_LIST_T m_recommendedChannels;
    IMAGE_SET_LIST_T m_imageSetList;
    SMART_FAVORITE_LIST_T m_smartFavoriteList;
//    SHOW_CHANNEL_LIST_T m_showChannelList;
    FAVORITE_LIST_T m_favoriteList;
    ARTIST_SONG_ALERTS_T m_artistAndSongAlerts;
//    SPORTS_TEAM_ALERTS_T m_teamAlerts;
    QList<TEAM_INFO_T> m_teamAlerts;
    SPORTS_TEAM_T m_sportTeams;
    QList<LEAGUE_INFO_T> m_sportLeagues;

    QList<int> m_lstChannelNum;
    QStringList m_lstChannelName;
    QList<CHANNEL_INFORMATION_T> m_lstChannelInformation;
    QList<CHANNEL_INFORMATION_T> m_allChannelInformation;
    QList<CHANNEL_INFORMATION_T> m_lstRecommendation;
    QList<FAVORITE_T> m_lstFavoriteList;
    CHANNEL_INFORMATION_T m_currentChannelIsNowPlaying;
    SxmCmd *m_sxmCmd;
    std::mutex m_mutex;
    bool m_isChannelListFinished;
    uint8_t m_playState;
    bool m_isNoSignal;

    bool m_isNoAntenna;
    ANTENNA_STATE m_antennaState;
    bool m_isTuning;


    //make color start
    LIVE_CHANNEL_LIST_T m_lstRelatedChannel;
    LIVE_CHANNEL_LIST_T m_lstHistoryChannel;
    void generateFavoriteList(FAVORITE_LIST_T &_lstFavorite);
    void generateRecommendationList(LIVE_CHANNEL_LIST_T &_lstRecommendation);
    void generateRelatedList(LIVE_CHANNEL_LIST_T &_lstRelated);
    void generateHistoryList(LIVE_CHANNEL_LIST_T &lstHistory);
    void generateArtistAndSongAlert(ARTIST_SONG_ALERTS_T &lstArtistSongAlerts);

    QMap<int, QString> m_leaguesMap;
    void setLeagues(const SPORTS_LEAGUE_T &leaguesInfo);
    //make color end

#ifndef EXCLUDE_SPEECH
    SpeechProvider *m_speechProvider;
    SPEECH_SCFA_TELEPROMPTERSHOW_INFO_ST m_scfaInfo;
    SPEECH_SCFA_LISTSHOW_INFO_ST m_scfaListShowInfo;
    SPEECH_SDARS_TEAM_DATA m_speechTeamData;
    SPEECH_SDARS_CHANNEL_DATA m_speechDataChannelPackage;
    QList<CHANNEL_INFORMATION_T> m_speechDataChannel;
    SPEECH_SDARS_CATEGORY_LIST m_speechCategorySatList;
#endif
};

#endif // DATACONTROLLER_H
