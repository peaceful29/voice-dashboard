#ifndef ISXMCMD_H
#define ISXMCMD_H

#include <QObject>
#include "Common/UIBridge.h"
#include "Common/Utils.h"

#include <QMap>

class SxmServiceInterface;
class SxmAppServiceInterface;
class SxmKeyboardInterface;
class SxmSpeechServiceInterface;
class SxmPopupServiceInterface;

class ISxmCmd : public QObject
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    explicit ISxmCmd(QString _module, SxmServiceInterface* _interface, SxmAppServiceInterface* _appInterface,
                     SxmKeyboardInterface* _keyboardInterface, SxmSpeechServiceInterface *speechInterface, SxmPopupServiceInterface *_popupInterface, QObject *parent = nullptr);
    virtual ~ISxmCmd();
    QString module() const;
    bool parseCmd(UIBridge::E_HMI_EVENT_FNC_ID fncId, QString parameter = QString());
    void initialize();

protected:
    void createMapFncIdParameterNumber();
    virtual void connectToInterface() = 0;
    bool matchFncIdParameterNumber(UIBridge::E_HMI_EVENT_FNC_ID fncId, int parameterNumber);
    virtual bool implementCmd(UIBridge::E_HMI_EVENT_FNC_ID fncId, QStringList parameterList) = 0;

    QString m_module;
    SxmServiceInterface *m_interface;
    SxmAppServiceInterface *m_appInterface;
    SxmKeyboardInterface *m_keyboardInterface;
    SxmPopupServiceInterface *m_popupInterface;
    SxmSpeechServiceInterface *m_speechInterface;
    QMap<UIBridge::E_HMI_EVENT_FNC_ID, int> m_fncIdParameterNo;
};

#endif // ISXMCMD_H
