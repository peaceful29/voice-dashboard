#include "SxmCmd.h"
#include "Interfaces/SxmServiceInterface.h"
#include "Interfaces/SxmAppServiceInterface.h"
#include "Interfaces/SxmKeyboardInterface.h"
#include "Interfaces/SxmSpeechServiceInterface.h"
#include "SxmPopupServiceInterface.h"
#include "popupservice/PopupJsonContextHandler.h"
#include "SxmCmd.h"
#include "DataController.h"
#include "ResourceManager.h"

/*!
 * \brief SxmCmd::SxmCmd
 * \param module
 * \param _interface
 * \param parent
 */
SxmCmd::SxmCmd(QString module, SxmServiceInterface *_interface,
               SxmAppServiceInterface* _appInterface,
               SxmKeyboardInterface* _keyboardInterface,
               SxmSpeechServiceInterface *speechInterface, SxmPopupServiceInterface *_popupInterface,
               QObject *parent)
    : ISxmCmd(module, _interface, _appInterface, _keyboardInterface, speechInterface, _popupInterface, parent)

{
    LOGI().writeFormatted("SxmCmd::SxmCmd() called");
}

/*!
 * \brief SxmCmd::~SxmCmd
 */
SxmCmd::~SxmCmd()
{
    LOGI().writeFormatted("SxmCmd::~SxmCmd() called");
}

/*!
 * \brief SxmCmd::implementCmd
 * \param fncId
 * \param parameterList
 * \return
 */
bool SxmCmd::implementCmd(UIBridge::E_HMI_EVENT_FNC_ID fncId, QStringList parameterList)
{
    LOGI().writeFormatted("SxmCmd::implementCmd() called functionID %d", fncId);
    LOGI().writeFormatted("SxmCmd::implementCmd() called param list count %d", parameterList.count());
    foreach (QString params, parameterList) {
        LOGI().writeFormatted("param: %s",params.toStdString().c_str());
    }
    if (matchFncIdParameterNumber(fncId, parameterList.size()) == false) {
        LOGI().writeFormatted("[SxmCmd::implementCmd]False[%d][%d]", fncId, parameterList.size());
        return false;
    }

    switch (fncId) {
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_INIT_SET:
        requestInitSet(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_INIT_STATE:
        requestInitState();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SUPERCATEGORY:
        requestSuperCategories();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ALL_CATEGORIES:
        requestAllCategories();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CATEGORIES:
        requestCategories(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNELS_1:
        requestChannels(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNELS_2:
        requestChannels();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNEL_INFORMATION:
        requestChannelInformation(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_FAVORITES:
        requestFavorites();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ADD_FAVORITE:
        requestAddFavorite(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_REMOVE_FAVORITE:
        requestRemoveFavorite(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TUNE_FAVORITE:
        requestTuneFavorite(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SMART_FAVORITES:
        requestSmartFavorites();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_MOVE_FAVORITES:
        requestMoveFavorites(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_PLAYBACK:
        requestPlayback(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TUNE_CHANNEL:
        requestTuneChannel(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TUNE_LAST_CHANNEL:
        requestTuneLastChannel();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SEEK_CHANNEL:
        requestSeekChannel(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SONG_ALERT:
        requestSongAlerts();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ARTIST_ALERT:
        requestArtistAlerts();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ARTIST_AND_SONG_ALERT:
        requestArtistAndSongAlerts();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ADD_SONG_ALERT:
        requestAddSongAlert(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ADD_ARTIST_ALERT:
        requestAddArtistAlert(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_REMOVE_SONG_ALERT:
        requestRemoveSongAlert(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_REMOVE_ARTIST_ALERT:
        requestRemoveArtistAlert(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_REWIND:
        requestRewind(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_FAST_FORWARD:
        requestFastForward(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_JUMP_POINT:
        requestJumpPoint(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_RECOMMENDATION:
        requestRecommendation();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_LISTENING_HISTORY:
        requestListeningHistory();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_LAST_CHANNEL_INFO:
        requestLastChannelInfo();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_CHANNEL_LIST:
        requestGetChannelList(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TO_SHOW_SYSTEM_COMPONENT:
        requestToShowSystemComponent(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TO_HIDE_SYSTEM_COMPONENT:
        requestToHideSystemComponent(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TO_GO_APPLICATION:
        requestToGoApplication(parameterList);
        break;
    // Test lost signal
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TEST_LOSS_SIGNAL:
        requestTestLossSignal();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_RESUMING_ONCOMPLETED:
        requestResumingSatelliteOnCompleted();
        break;
    // Profile
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_ACTIVE_PROFILES:
        requestGetActiveProfiles();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CREATE_PROFILE:
        requestCreateProfile(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SET_DEFAULT_PROFILE:
        requestSetDefaultProfile();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SWITCH_PROFILE:
        requestSwitchProfile(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_DELETE_PROFILE:
        requestDeleteProfile();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_MODIFY_PROFILE_NAME:
        requestModifyProfileName(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_MODIFY_PROFILE_AVATAR:
        requestModifyProfileAvatar(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SAT_DIAGNOSTICS:
        requestSATDiagnostics();
        break;
    // make color start
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_RELATED_LIST:
        requestRelatedList();
        break;
    //make color end
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_SETTING_NOTIFICATION:
        requestGetSettingNotification();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SET_SETTING_NOTIFICATION:
        requestSetSettingNotification(parameterList);
        break;
    //Sport Team
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ADD_FAVORITE_TEAM:
        requestAddFavoriteTeam(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_REMOVE_FAVORITE_TEAM:
        requestRemoveFavoriteTeam(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_TEAMS:
        requestGetTeams(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_LEAGUES:
        requestGetLeagues();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_ADD_TEAM_ALERTS:
        requestAddTeamAlerts(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_REMOVE_TEAM_ALERTS:
        requestRemoveTeamAlerts(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_TEAM_ALERT:
        requestGetTeamAlerts();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_FAVORITE_TEAMS:
        requestGetFavoriteTeams();
        break;
//    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_LIVE_SPORTS:
//        requestGetLiveSports();
//        break;
//    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TUNE_LIVE_SPORTS:
//        requestTuneLiveSports(parameterList);
//        break;

        //Keyboard
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SHOW_KEYBOARD:
        requestShowKeyboard(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_HIDE_KEYBOARD:
        requestHideKeyboard(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_RESPONSE_CANDIDATE_INFO:
        responseCandidateInfo(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_RESPONSE_CANDIDATE_LIST:
        responseCandidateList(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_XBUTTON:
        requestSpeechModePttLongPress();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_RESPONSE_LIST_PAGE:
        requestSpeechModeResponseListPage(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_RESPONSE_LINE_NUM_ABSOLUTE_IDX:
        requestSpeechModeResponseLineNumAbsoluteIdx(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_RESPONSE_LIST_FOCUS_SET:
        requestSpeechModeResponseListFocusSet(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SDARS_TEAM_DATA:
        requestSpeechModeSdarsTeamData();
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_CURRENT_INDEX_LINEAR_TUNER:
        requestGetCurrentIndexLinearTune();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SAT_SUBSCRIPTION_STATE:
        requestSatSubscriptionState();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_ANTENNA_STATE:
        requestGetAntennaState();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SDARS_DATA_CHANNEL:
        requestSpeechModeSdarsDataChannel();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SDARS_CATEGORY_SAT_LIST:
        requestSpeechModeSdarsCategorySatList();
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SDARS_CATEGORY_CHANNEL:
        requestSpeechModeSdarsCategoryChannel(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_LIST_CURRENT_INDEX:
        requestSpeechModeListCurrentIndexChanged(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SELECT:
        requestSpeechModeSelect(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_TP_SELECT:
        requestSpeechModeTpSelect(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SCROLL_START:
        requestSpeechModeScrollStart(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_SCROLL_STOP:
        requestSpeechModeScrollStop(parameterList);
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_VOICETAGS_FAVORITE:
        requestSpeechModeVoicetagsFavorite(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_VOICETAGS_CHANNEL:
        requestSpeechModeVoicetagsChannel(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SPEECH_MODE_VOICETAGS_CHANNEL_INPUT:
        requestSpeechModeVoicetagsChannelInput(parameterList);
        break;
    //PopUp
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SHOW_POPUP:
        requestShowPopup(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_HIDE_POPUP:
        requestHidePopup(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_UPDATE_POPUP:
        requestUpdatePopup(parameterList);
        break;
    case UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SHOW_SPECIAL_POPUP:
        requestShowScpecialPopup(parameterList);
        break;
    default:
        break;
    }
    return true;
}

/*!
 * \brief SxmCmd::connectToInterface
 */
void SxmCmd::connectToInterface()
{
    LOGI().writeFormatted("SxmCmd::connectToInterface() called");
    if (m_interface != nullptr) {
        QObject::connect(this, SIGNAL(eventRequestSATDiagnostics())
                         , m_interface, SLOT(onEventSATDiagnostics()));
        QObject::connect(this, SIGNAL(eventRequestInitSet(int,bool,const char*))
                         , m_interface, SLOT(onEventRequestInitSet(int,bool,const char*)));
        QObject::connect(this, SIGNAL(eventRequestInitState())
                         , m_interface, SLOT(onEventRequestInitState()));
        QObject::connect(this, SIGNAL(eventRequestSuperCategories()),
                         m_interface, SLOT(onEventRequestSuperCategories()));
        QObject::connect(this, SIGNAL(eventRequestAllCategories()),
                         m_interface, SLOT(onEventRequestAllCategories()));
        QObject::connect(this, SIGNAL(eventRequestCategories(const char*)),
                         m_interface, SLOT(onEventRequestCategories(const char*)));
        QObject::connect(this, SIGNAL(eventRequestChannels(const char*)),
                         m_interface, SLOT(onEventRequestChannels(const char*)));
        QObject::connect(this, SIGNAL(eventRequestChannels()),
                         m_interface, SLOT(onEventRequestChannels()));
        QObject::connect(this, SIGNAL(eventRequestChannelInformation(uint32_t)),
                         m_interface, SLOT(onEventRequestChannelInformation(uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestFavorites()),
                         m_interface, SLOT(onEventRequestFavorites()));
        QObject::connect(this, SIGNAL(eventRequestAddFavorite(const uint32_t)),
                         m_interface, SLOT(onEventRequestAddFavorite(uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestRemoveFavorite(const uint32_t)),
                         m_interface, SLOT(onEventRequestRemoveFavorite(const uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestTuneFavorite(uint32_t)),
                         m_interface, SLOT(onEventRequestTuneFavorite(uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestSmartFavorites()),
                         m_interface, SLOT(onEventRequestSmartFavorites()));
        QObject::connect(this, SIGNAL(eventRequestMoveFavorite(const uint32_t, const uint32_t)),
                         m_interface, SLOT(onEventRequestMoveFavorite(const uint32_t, const uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestPlayback(PLAY_STATE)),
                         m_interface, SLOT(onEventRequestPlayback(PLAY_STATE)));
        QObject::connect(this, SIGNAL(eventRequestTuneLastChannel()),
                         m_interface, SLOT(onEventRequestTuneLastChannel()));
        QObject::connect(this, SIGNAL(eventRequestTune(uint32_t)),
                         m_interface, SLOT(onEventRequestTune(uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestSeekChannel(SEEK_ACTION)),
                         m_interface, SLOT(onEventRequestSeekChannel(SEEK_ACTION)));
        QObject::connect(this, SIGNAL(eventRequestSongAlerts()),
                         m_interface, SLOT(onEventRequestSongAlerts()));
        QObject::connect(this, SIGNAL(eventRequestArtistAlerts()),
                         m_interface, SLOT(onEventRequestArtistAlerts()));
        QObject::connect(this, SIGNAL(eventRequestArtistAndSongAlerts()),
                         m_interface, SLOT(onEventRequestArtistAndSongAlerts()));
        QObject::connect(this, SIGNAL(eventRequestAddSongAlert(const char*)),
                         m_interface, SLOT(onEventRequestAddSongAlert(const char*)));
        QObject::connect(this, SIGNAL(eventRequestAddArtistAlert(const char*)),
                         m_interface, SLOT(onEventRequestAddArtistAlert(const char*)));
        QObject::connect(this, SIGNAL(eventRequestRemoveSongAlert(const char*)),
                         m_interface, SLOT(onEventRequestRemoveSongAlert(const char*)));
        QObject::connect(this, SIGNAL(eventRequestRemoveArtistAlert(const char*)),
                         m_interface, SLOT(onEventRequestRemoveArtistAlert(const char*)));
        QObject::connect(this, SIGNAL(eventRequestRewind(uint32_t)),
                         m_interface, SLOT(onEventRequestRewind(uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestFastForward(uint32_t)),
                         m_interface, SLOT(onEventRequestFastForward(uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestJumpPoint(uint32_t)),
                         m_interface, SLOT(onEventRequestJumpPoint(uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestRecommendation()),
                         m_interface, SLOT(onEventRequestRecommendation()));
        QObject::connect(this, SIGNAL(eventRequestListeningHistory()),
                         m_interface, SLOT(onEventRequestListeningHistory()));
        QObject::connect(this, SIGNAL(eventRequestLastChannelInfo()),
                         m_interface, SLOT(onEventRequestLastChannelInfo()));
        QObject::connect(this, SIGNAL(eventRequestTestLossSignal()),
                         m_interface, SLOT(onEventTestLossSignal()));
        QObject::connect(this, SIGNAL(eventRequestGetChannelList(int)),
                         m_interface, SLOT(onEventRequestGetChannelList(int)));
        QObject::connect(this, SIGNAL(eventRequestResumingSatelliteOnCompleted()),
                         m_interface, SLOT(onEventRequestResumingSatelliteOnCompleted()));
        QObject::connect(this, SIGNAL(eventRequestGetActiveProfiles()),
                         m_interface, SLOT(onEventRequestGetActiveProfiles()));
        QObject::connect(this, SIGNAL(eventRequestCreateProfile(const char*)),
                         m_interface, SLOT(onEventRequestCreateProfile(const char*)));
        QObject::connect(this, SIGNAL(eventRequestSetDefaultProfile()),
                         m_interface, SLOT(onEventRequestSetDefaultProfile()));
        QObject::connect(this, SIGNAL(eventRequestSwitchProfile(const char*)),
                         m_interface, SLOT(onEventRequestSwitchProfile(const char*)));
        QObject::connect(this, SIGNAL(eventRequestDeleteProfile()),
                         m_interface, SLOT(onEventRequestDeleteProfile()));
        QObject::connect(this, SIGNAL(eventRequestModifyProfileName(const char*)),
                         m_interface, SLOT(onEventRequestModifyProfileName(const char*)));
        QObject::connect(this, SIGNAL(eventRequestModifyProfileAvatar(const char*)),
                         m_interface, SLOT(onEventRequestModifyProfileAvatar(const char*)));
        QObject::connect(this, SIGNAL(eventRequestGetSettingNotification()),
                         m_interface, SLOT(onEventRequestGetSettingNotification()));
        QObject::connect(this, SIGNAL(eventRequestSetSettingNotification(SETTING_NOTIFICATION_STATE)),
                         m_interface, SLOT(onEventRequestSetSettingNotification(SETTING_NOTIFICATION_STATE)));
        //make color
        QObject::connect(this, SIGNAL(eventRequestRelatedList()),
                          m_interface, SLOT(onEventRequestRelatedList()));
        //make color
        // Sport Team
        QObject::connect(this, SIGNAL(eventRequestAddFavoriteTeam(const SPORTS_TEAM_TYPE)),
                         m_interface, SLOT(onEventRequestAddFavoriteTeam(const SPORTS_TEAM_TYPE)));
        QObject::connect(this, SIGNAL(eventRequestRemoveFavoriteTeam(const int)),
                         m_interface, SLOT(onEventRequestRemoveFavoriteTeam(const int)));
        QObject::connect(this, SIGNAL(eventRequestGetTeams(const int)),
                         m_interface, SLOT(onEventRequestGetTeams(const int)));
        QObject::connect(this, SIGNAL(eventRequestGetLeagues()),
                         m_interface, SLOT(onEventRequestGetLeagues()));
        QObject::connect(this, SIGNAL(eventRequestAddTeamAlerts(const int)),
                         m_interface, SLOT(onEventRequestAddTeamAlerts(const int)));
        QObject::connect(this, SIGNAL(eventRequestRemoveTeamAlerts(const int)),
                         m_interface, SLOT(onEventRequestRemoveTeamAlerts(const int)));
        QObject::connect(this, SIGNAL(eventRequestGetTeamAlerts()),
                         m_interface, SLOT(onEventRequestGetTeamAlerts()));
        QObject::connect(this, SIGNAL(eventRequestGetFavoriteTeams()),
                         m_interface, SLOT(onEventRequestGetFavoriteTeams()));
//        QObject::connect(this, SIGNAL(eventRequestGetLiveSports()),
//                         m_interface, SLOT(onEventRequestGetLiveSports()));
//        QObject::connect(this, SIGNAL(eventRequestTuneLiveSports(const int)),
//                         m_interface, SLOT(onEventRequestTuneLiveSports(const int)));
        QObject::connect(this, SIGNAL(eventRequestSatSubscriptionState()),
                         m_interface, SLOT(onEventRequestSatSubscriptionState()));
        QObject::connect(this, SIGNAL(eventRequestGetAntennaState()),
                         m_interface, SLOT(onEventRequestGetAntennaState()));
    }
    if (nullptr != m_keyboardInterface) {
        //keyboard
        QObject::connect(this, SIGNAL(eventRequestShowKeyboard(uint32_t,E_KEYBOARD_TYPE,const char*,const char*,uint32_t)),
                         m_keyboardInterface, SLOT(onEventRequestShowKeyboard(uint32_t,E_KEYBOARD_TYPE,const char*,const char*,uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestHideKeyboard(uint32_t)),
                         m_keyboardInterface, SLOT(onEventRequestHideKeyboard(uint32_t)));
        QObject::connect(this, SIGNAL(eventResponseCandidateInfo(uint32_t,uint32_t,const char*)),
                         m_keyboardInterface, SLOT(onEventResponseCandidateInfo(uint32_t,uint32_t,const char*)));
        QObject::connect(this, SIGNAL(eventResponseCandidateList(uint32_t,uint32_t,const char*,uint32_t,uint32_t)),
                         m_keyboardInterface, SLOT(onEventResponseCandidateList(uint32_t,uint32_t,const char*,uint32_t,uint32_t)));
    }

    if (nullptr != m_appInterface) {
        QObject::connect(this, SIGNAL(eventRequestToShowSystemComponent(int,E_SYSTEM_COMPONENT,const char*)),
                         m_appInterface, SLOT(onEventRequestToShowSystemComponent(int,E_SYSTEM_COMPONENT,const char*)));
        QObject::connect(this, SIGNAL(eventRequestToHideSystemComponent(int, E_SYSTEM_COMPONENT, const char*)),
                         m_appInterface, SLOT(onEventRequestToHideSystemComponent(int,E_SYSTEM_COMPONENT,const char*)));
        QObject::connect(this, SIGNAL(eventRequestToGoApplication(int,const char*,const char*,const char*,E_SHOW_OPT)),
                         m_appInterface, SLOT(onEventRequestToGoApplication(int,const char*,const char*,const char*,E_SHOW_OPT)));
    }

    if (m_speechInterface != nullptr){
        QObject::connect(this, SIGNAL(eventRequestSpeechModePttLongPress()),
                         m_speechInterface, SLOT(onEventRequestPttLongPress()));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeSelect(QStringList)),
                         m_speechInterface, SLOT(onEventRequestSpeechModeSelect(QStringList)));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeTpSelect(int)),
                         m_speechInterface, SLOT(onEventRequestSpeechModeTpSelect(int)));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeScrollStart()),
                         m_speechInterface, SLOT(onEventRequestSpeechModeScrollStart()));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeScrollStop()),
                         m_speechInterface, SLOT(onEventRequestSpeechModeScrollStop()));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeResponseListPage(bool)),
                         m_speechInterface, SLOT(onEventResponseListPage(bool)));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeResponseLineNumAbsoluteIdx(int)),
                         m_speechInterface, SLOT(onEventRequestSpeechModeResponseLineNumAbsoluteIdx(int)));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeResponseListFocusSet(bool)),
                         m_speechInterface, SLOT(onEventRequestSpeechModeResponseListFocusSet(bool)));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeSdarsTeamData()),
                         m_speechInterface, SLOT(onEventRequestSpeechModeSdarsTeamData()));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeSdarsDataChannel()),
                         m_speechInterface, SLOT(onEventRequestSpeechModeSdarsDataChannel()));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeSdarsCategorySatList()),
                         m_speechInterface, SLOT(onEventRequestSpeechModeSdarsCategorySatList()));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeSdarsCategoryChannel(QString)),
                         m_speechInterface, SLOT(onEventRequestSpeechModeSdarsCategoryChannel(QString)));
        //
        QObject::connect(this, SIGNAL(eventRequestSpeechModeVoicetagFavorite(uint32_t)),
                         m_appInterface, SLOT(onEventRequestSpeechModeVoicetagFavorite(uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeVoicetagChannel(QString&)),
                         m_appInterface, SLOT(onEventRequestSpeechModeVoicetagChannel(QString&)));
        QObject::connect(this, SIGNAL(eventRequestSpeechModeVoicetagChannelInput(QString&)),
                         m_appInterface, SLOT(onEventRequestSpeechModeVoicetagChannelInput(QString&)));
    }

    if (nullptr != m_popupInterface) {
        QObject::connect(this, SIGNAL(eventRequestShowPopup(uint32_t,E_POPUP_TYPE,E_POPUP_SIDE_TYPE,E_POPUP_SIZE,const char*,uint32_t)),
                         m_popupInterface, SLOT(onEventRequestShowPopup(uint32_t,E_POPUP_TYPE,E_POPUP_SIDE_TYPE,E_POPUP_SIZE,const char*,uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestHidePopup(uint32_t,uint32_t)),
                         m_popupInterface, SLOT(onEventRequestHidePopup(uint32_t,uint32_t)));
        QObject::connect(this, SIGNAL(eventRequestUpdatePopup(uint32_t,uint32_t,const char*)),
                         m_popupInterface, SLOT(onEventRequestUpdatePopup(uint32_t,uint32_t,const char*)));
        QObject::connect(this, SIGNAL(eventRequestShowScpecialPopup(uint32_t,E_SPECIAL_POPUP_TYPE,const char*,uint32_t)),
                         m_popupInterface, SLOT(onEventRequestShowSpecialPopup(uint32_t,E_SPECIAL_POPUP_TYPE,const char*,uint32_t)));
    }
}

/*!
 * \brief SxmCmd::requestSATDiagnostics
 */
void SxmCmd::requestSATDiagnostics()
{
    LOGI().writeFormatted("SxmCmd::requestSATDiagnostics() called");
    emit eventRequestSATDiagnostics();
}

/*!
 * \brief SxmCmd::requestInitSet
 * \param _parameterList
 */
void SxmCmd::requestInitSet(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestInitSet() called");
    int id = _parameterList[0].toInt();
    int iFlag = _parameterList[1].toInt();
    const char* msg = _parameterList[2].toStdString().c_str();
    bool bFlag;
    if (iFlag == 0)
        bFlag = false;
    else
        bFlag = true;
    emit eventRequestInitSet(id, bFlag, msg);
}

/*!
 * \brief SxmCmd::requestInitState
 */
void SxmCmd::requestInitState()
{
    LOGI().writeFormatted("SxmCmd::requestSmartFavorites() called");
    emit eventRequestInitState();
}

/*!
 * \brief SxmCmd::requestSuperCategories
 */
void SxmCmd::requestSuperCategories()
{
    LOGI().writeFormatted("SxmCmd::requestSuperCategories() called");
    emit eventRequestSuperCategories();
}

/*!
 * \brief SxmCmd::requestSuperCategories
 */
void SxmCmd::requestAllCategories()
{
    LOGI().writeFormatted("SxmCmd::requestAllCategories() called");
    emit eventRequestAllCategories();
}

/*!
 * \brief SxmCmd::requestCategories
 * \param _parameterList
 */
void SxmCmd::requestCategories(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestCategories() called");
    const char* superCategory = _parameterList[0].toStdString().c_str();
	ResourceManager::instance()->setCurrentSuperCategory(QString("%1").arg(superCategory));
    emit eventRequestCategories(superCategory);
}

/*!
 * \brief SxmCmd::requestChannels
 * \param _parameterList
 */
void SxmCmd::requestChannels(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestChannels() called");
    const char* category = _parameterList[0].toStdString().c_str();
    emit eventRequestChannels(category);
}

/*!
 * \brief SxmCmd::requestChannels
 */
void SxmCmd::requestChannels()
{
    LOGI().writeFormatted("SxmCmd::requestChannels() called");
    emit eventRequestChannels();
}

/*!
 * \brief SxmCmd::requestChannelInformation
 * \param _parameterList
 */
void SxmCmd::requestChannelInformation(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestChannelInformation() called");
    int channelNumber = _parameterList[0].toInt();
    emit eventRequestChannelInformation(channelNumber);
}

/*!
 * \brief SxmCmd::requestFavorites
 */
void SxmCmd::requestFavorites()
{
    LOGI().writeFormatted("SxmCmd::requestFavorites() called");
    emit eventRequestFavorites();
}

/*!
 * \brief SxmCmd::requestAddFavorite
 * \param _parameterList
 */
void SxmCmd::requestAddFavorite(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestAddFavorite() called");
    uint32_t channelNumber = static_cast<uint32_t>(_parameterList[0].toInt());
    ResourceManager::instance()->setCurrentChannelNumber(channelNumber);
    LOGI().writeFormatted("=========>SxmCmd::requestAddFavorite() number  %d", channelNumber);

//    uint8_t size = DataController::instance()->getListFavorite().size();
//    if (20 <= size) {
//        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SHOW_POPUP, "20,2,3,2,test,1000");
//    }
//    else {
        emit eventRequestAddFavorite(channelNumber);
//    }
}

/*!
 * \brief SxmCmd::requestRemoveFavorite
 * \param _parameterList
 */
void SxmCmd::requestRemoveFavorite(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestRemoveFavorite() called");
//    char* id;
//    strcpy(id, _parameterList[0].toStdString().c_str());
    uint32_t channelNumber = static_cast<uint32_t>(_parameterList[0].toInt());
    ResourceManager::instance()->setCurrentChannelNumber(channelNumber);
    LOGI().writeFormatted("=========>SxmCmd::requestRemoveFavorite() number  %d", channelNumber);

    emit eventRequestRemoveFavorite(channelNumber);
}

/*!
 * \brief SxmCmd::requestTuneFavorite
 * \param _parameterList
 */
void SxmCmd::requestTuneFavorite(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestTuneFavorite() called");
    uint32_t channelNumber = static_cast<uint32_t>(_parameterList[0].toInt());
    emit eventRequestTuneFavorite(channelNumber);
}

/*!
 * \brief SxmCmd::requestSmartFavorites
 */
void SxmCmd::requestSmartFavorites()
{
    LOGI().writeFormatted("SxmCmd::requestSmartFavorites() called");
    emit eventRequestSmartFavorites();
}

void SxmCmd::requestMoveFavorites(QStringList _parameterList)
{
    uint32_t index = static_cast<uint32_t>(_parameterList[0].toInt());
    uint32_t new_index = static_cast<uint32_t>(_parameterList[1].toInt());
    LOGI().writeFormatted("SxmCmd::requestMoveFavorites() called index: [%d], new_index [%d]", index, new_index);
    emit eventRequestMoveFavorite(index, new_index);
}

/*!
 * \brief SxmCmd::requestPlayback
 * \param _parameterList
 */
void SxmCmd::requestPlayback(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestPlayback() called");
    int iState = _parameterList[0].toInt();
    PLAY_STATE state = STATE_PAUSE;
    switch (iState) {
    case 0:
        state = STATE_PAUSE;
        break;
    case 1:
        state = STATE_PLAY;
        break;
    case 2:
        state = STATE_FORWARD;
        break;
    case 3:
        state = STATE_BACKWARD;
        break;
    case 4:
        state = STATE_LIVE;
        break;
    case 5:
        state = STATE_START;
        break;
    default:
        break;
    }
    emit eventRequestPlayback(state);
}

/*!
 * \brief SxmCmd::requestTuneLastChannel
 */
void SxmCmd::requestTuneLastChannel()
{
    LOGI().writeFormatted("SxmCmd::requestTuneLastChannel() called");
    emit eventRequestTuneLastChannel();
}

/*!
 * \brief SxmCmd::requestTuneChannel
 * \param _parameterList
 */
void SxmCmd::requestTuneChannel(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestTuneChannel() called");
    uint32_t channelNumber;
    QRegExp re("\\d*");
    if(re.exactMatch(_parameterList[0]))
        channelNumber = static_cast<uint32_t>(_parameterList[0].toInt());
    else
        channelNumber = static_cast<uint32_t>(DataController::instance()->getChnNumFromChnName(_parameterList[0]));
    LOGI().writeFormatted("SxmCmd::requestTuneChannel() CHANNEL NUMBER: [%d]", channelNumber);
    ResourceManager::instance()->setCurrentChannelNumber(channelNumber);
    emit eventRequestTune(channelNumber);
}

/*!
 * \brief SxmCmd::requestSeekChannel
 * \param _parameterList
 */
void SxmCmd::requestSeekChannel(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestSeekChannel() called");
    SEEK_ACTION action = static_cast<SEEK_ACTION>(_parameterList[0].toInt());
    CHANNEL_INFORMATION_T &channelNowPlaying = DataController::instance()->getCurrentChannelIsNowPlaying();
    uint16_t sizeListChannel = DataController::instance()->getListChannel().size();
    uint16_t indexChannelNowPlaying = DataController::instance()->getListChannel().indexOf(channelNowPlaying.number, 0);
    LOGI().writeFormatted("SxmCmd::requestSeekChannel() indexChannelNowPlaying [%d], channelNowPlaying[%d] sizeListChannel [%d]", indexChannelNowPlaying, channelNowPlaying.number, sizeListChannel);

    if (action == SEEK_UP) {
        if (channelNowPlaying.number == sizeListChannel -1) {
            indexChannelNowPlaying = 1;
        }
        else {
            indexChannelNowPlaying++;
        }
    }
    else {
        if (channelNowPlaying.number == 1) {
            indexChannelNowPlaying = sizeListChannel -1;
        }
        else {
            indexChannelNowPlaying--;
        }
    }
    uint32_t currentChannelNumber = DataController::instance()->getListChannel()[indexChannelNowPlaying];
    ResourceManager::instance()->setCurrentChannelNumber(currentChannelNumber);
    LOGI().writeFormatted("SxmCmd::requestSeekChannel() currentChannelNumber [%d] indexChannelNowPlaying[%d]", currentChannelNumber, indexChannelNowPlaying);

//    emit eventRequestSeekChannel(action);
}

/*!
 * \brief SxmCmd::requestSongAlerts
 */
void SxmCmd::requestSongAlerts()
{
    LOGI().writeFormatted("SxmCmd::requestSongAlerts() called");
    emit eventRequestSongAlerts();
}

/*!
 * \brief SxmCmd::requestArtistAlerts
 */
void SxmCmd::requestArtistAlerts()
{
    LOGI().writeFormatted("SxmCmd::requestArtistAlerts() called");
    emit eventRequestArtistAlerts();
}

/*!
 * \brief SxmCmd::requestArtistAndSongAlerts
 */
void SxmCmd::requestArtistAndSongAlerts()
{
    LOGI().writeFormatted("SxmCmd::requestArtistAndSongAlerts() called");
    emit eventRequestArtistAndSongAlerts();
}

/*!
 * \brief SxmCmd::requestAddSongAlert
 * \param _parameterList
 */
void SxmCmd::requestAddSongAlert(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestAddSongAlert() called");
//    uint32_t channelNumber = static_cast<uint32_t>(_parameterList[0].toInt());
    const char* songTitle = _parameterList[0].toStdString().c_str();
    emit eventRequestAddSongAlert(songTitle);
}

/*!
 * \brief SxmCmd::requestAddArtistAlert
 * \param _parameterList
 */
void SxmCmd::requestAddArtistAlert(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestAddArtistAlert() called");
//    uint32_t channelNumber = static_cast<uint32_t>(_parameterList[0].toInt());
    const char* artistName = _parameterList[0].toStdString().c_str();
    emit eventRequestAddArtistAlert(artistName);
}

/*!
 * \brief SxmCmd::requestRemoveSongAlert
 * \param _parameterList
 */
void SxmCmd::requestRemoveSongAlert(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestRemoveSongAlert() called");
    const char* songTitle = _parameterList[0].toStdString().c_str();
    emit eventRequestRemoveSongAlert(songTitle);
}

/*!
 * \brief SxmCmd::requestRemoveArtistAlert
 * \param _parameterList
 */
void SxmCmd::requestRemoveArtistAlert(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestRemoveArtistAlert() called");
    const char* artistName = _parameterList[0].toStdString().c_str();
    emit eventRequestRemoveArtistAlert(artistName);
}

/*!
 * \brief SxmCmd::requestRewind
 * \param _parameterList
 */
void SxmCmd::requestRewind(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestRewind() called");
    uint32_t step = static_cast<uint32_t>(_parameterList[0].toInt());
    emit eventRequestRewind(step);
}

/*!
 * \brief SxmCmd::requestFastForward
 * \param _parameterList
 */
void SxmCmd::requestFastForward(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestFastForward() called");
    uint32_t step = static_cast<uint32_t>(_parameterList[0].toInt());
    emit eventRequestFastForward(step);
}

/*!
 * \brief SxmCmd::requestJumpPoint
 * \param _parameterList
 */
void SxmCmd::requestJumpPoint(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestJumpPoint() called");
    uint32_t point = static_cast<uint32_t>(_parameterList[0].toInt());
    emit eventRequestJumpPoint(point);
}

/*!
 * \brief SxmCmd::requestRecommendation
 */
void SxmCmd::requestRecommendation()
{
    LOGI().writeFormatted("SxmCmd::requestRecommendation() called");
    emit eventRequestRecommendation();
}

/*!
 * \brief SxmCmd::requestListeningHistory
 */
void SxmCmd::requestListeningHistory()
{
    LOGI().writeFormatted("SxmCmd::requestListeningHistory() called");
    emit eventRequestListeningHistory();
}

/*!
 * \brief SxmCmd::requestLastChannelInfo
 */
void SxmCmd::requestLastChannelInfo()
{
    LOGI().writeFormatted("SxmCmd::requestLastChannelInfo() called");
    emit eventRequestLastChannelInfo();
}

/*!
 * \brief SxmCmd::requestGetChannelList
 */
void SxmCmd::requestGetChannelList(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestGetChannelList() called");
    int count = _parameterList[0].toInt();
    emit eventRequestGetChannelList(count);
}

/*!
 * \brief SxmCmd::requestToGoApplication
 */
void SxmCmd::requestToGoApplication(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestToGoApplication() called");
    int _requestId = -1;
    const char* _strAppBinaryName;
    const char* _strAppRole;
    const char* _strIntent;
    E_SHOW_OPT _eShowOpt;

    if (QString::compare(_parameterList[1], "sourceselector", Qt::CaseInsensitive) == 0)
    {
        _requestId = _parameterList[0].toInt();
        _strAppBinaryName = HMI_APP_NAME_SOURCESELECTOR;
        _strAppRole = HMI_ROLE_SOURCESELECTOR;
        _strIntent = "SXM";
        _eShowOpt = static_cast<E_SHOW_OPT>(_parameterList[2].toInt());
    }
    else if (QString::compare(_parameterList[1], "songartistlist", Qt::CaseInsensitive) == 0)
    {
        LOGI().writeFormatted("SxmCmd::requestToGoApplication() songartistlist");

        _requestId = E_HMI_APP_ID_RADIO_SXM360L;
        _strAppBinaryName = HMI_APP_NAME_SETTINGS;
        _strAppRole = HMI_ROLE_SETTINGS;
        _strIntent = "siriusxm=songartistlist";
        _eShowOpt = E_SHOW_OPT_ADD_OVERLAY;
    }
    else if (QString::compare(_parameterList[1], "sportslist", Qt::CaseInsensitive) == 0)
    {
        LOGI().writeFormatted("SxmCmd::requestToGoApplication() sportslist");

        _requestId = E_HMI_APP_ID_RADIO_SXM360L;
        _strAppBinaryName = HMI_APP_NAME_SETTINGS;
        _strAppRole = HMI_ROLE_SETTINGS;
        _strIntent = "siriusxm=sportslist";
        _eShowOpt = E_SHOW_OPT_ADD_OVERLAY;
    }
    else {
        LOGI().writeFormatted("SxmCmd::requestToGoApplication() Nothing");
    }

    emit eventRequestToGoApplication(_requestId, _strAppBinaryName, _strAppRole, _strIntent, _eShowOpt);
}

/*!
 * \brief SxmCmd::requestToShowSystemComponent
 * \param _parameter
 */
void SxmCmd::requestToShowSystemComponent(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestToShowSystemComponent() called");
    int _requestId = _parameterList[0].toInt();
    E_SYSTEM_COMPONENT _eSystemComponent = static_cast<E_SYSTEM_COMPONENT>(_parameterList[1].toInt());
    const char* _strData = _parameterList[2].toStdString().c_str();
    LOGI().writeFormatted("SxmCmd::requestToShowSystemComponent() requestId %d, _eSystemComponent %d, data %s",
                          _requestId, _eSystemComponent, _strData);
    emit eventRequestToShowSystemComponent(_requestId, _eSystemComponent, _strData);
}

/*!
 * \brief SxmCmd::requestToHideSystemComponent
 */
void SxmCmd::requestToHideSystemComponent(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestToHideSystemComponent() called");
    int _requestId = _parameterList[0].toInt();
    E_SYSTEM_COMPONENT _eSystemComponent = static_cast<E_SYSTEM_COMPONENT>(_parameterList[1].toInt());
    const char* _strData = _parameterList[2].toStdString().c_str();
    LOGI().writeFormatted("SxmCmd::requestToHideSystemComponent() requestId %d, _eSystemComponent %d, data %s",
                          _requestId, _eSystemComponent, _strData);
    emit eventRequestToHideSystemComponent(_requestId, _eSystemComponent, _strData);
}

/*!
 * \brief SxmCmd::requestTestLossSignal
 */
void SxmCmd::requestTestLossSignal()
{
    LOGI().writeFormatted("SxmCmd::requestTestLossSignal() called");
    emit eventRequestTestLossSignal();
}

/*!
 * \brief SxmCmd::requestResumingSatelliteOnCompleted
 */
void SxmCmd::requestResumingSatelliteOnCompleted()
{
    LOGI().writeFormatted("SxmCmd::requestResumingSatelliteOnCompleted() called");
    emit eventRequestResumingSatelliteOnCompleted();
}

/*!
 * \brief SxmCmd::requestGetActiveProfiles
 */
void SxmCmd::requestGetActiveProfiles()
{
    LOGI().writeFormatted("SxmCmd::requestGetActiveProfiles() called");
    emit eventRequestGetActiveProfiles();
}

/*!
 * \brief SxmCmd::requestCreateProfile
 * \param _parameterList
 */
void SxmCmd::requestCreateProfile(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestCreateProfile() called");
    const char* name = _parameterList[0].toStdString().c_str();
    emit eventRequestCreateProfile(name);
}

/*!
 * \brief SxmCmd::requestSetDefaultProfile
 */
void SxmCmd::requestSetDefaultProfile()
{
    LOGI().writeFormatted("SxmCmd::requestSetDefaultProfile() called");
    emit eventRequestSetDefaultProfile();
}

/*!
 * \brief SxmCmd::requestSwitchProfile
 * \param _parameterList
 */
void SxmCmd::requestSwitchProfile(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestSwitchProfile() called");
    const char* name = _parameterList[0].toStdString().c_str();
    emit eventRequestSwitchProfile(name);
}

/*!
 * \brief SxmCmd::requestDeleteProfile
 */
void SxmCmd::requestDeleteProfile()
{
    LOGI().writeFormatted("SxmCmd::requestDeleteProfile() called");
    emit eventRequestDeleteProfile();
}

/*!
 * \brief SxmCmd::requestModifyProfileName
 * \param _parameterList
 */
void SxmCmd::requestModifyProfileName(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestModifyProfileName() called");
    const char* name = _parameterList[0].toStdString().c_str();
    emit eventRequestModifyProfileName(name);
}

/*!
 * \brief SxmCmd::requestModifyProfileAvatar
 * \param _parameterList
 */
void SxmCmd::requestModifyProfileAvatar(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestModifyProfileAvatar() called");
    const char* name = _parameterList[0].toStdString().c_str();
    emit eventRequestModifyProfileAvatar(name);
}

/*!
 * \brief SxmCmd::requestGetSettingNotification
 */
void SxmCmd::requestGetSettingNotification()
{
    LOGI().writeFormatted("SxmCmd::requestGetSettingNotification() called");
    emit eventRequestGetSettingNotification();
}

/*!
 * \brief SxmCmd::requestSetSettingNotification
 * \param _parameterList
 */
void SxmCmd::requestSetSettingNotification(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestSetSettingNotification() called");
    SETTING_NOTIFICATION_STATE state;
    state.EnableNotification = static_cast<bool>(_parameterList[0].toInt());
    state.ArtistAndSong = static_cast<bool>(_parameterList[1].toInt());
    state.Sports = static_cast<bool>(_parameterList[2].toInt());
    state.ContinueListening = static_cast<bool>(_parameterList[3].toInt());

    LOGI().writeFormatted("SxmCmd::requestSetSettingNotification() EnableNotification %d", state.EnableNotification);
    LOGI().writeFormatted("SxmCmd::requestSetSettingNotification() ArtistAndSong %d", state.ArtistAndSong);
    LOGI().writeFormatted("SxmCmd::requestSetSettingNotification() Sports %d", state.Sports);
    LOGI().writeFormatted("SxmCmd::requestSetSettingNotification() ContinueListening %d", state.ContinueListening);

    emit eventRequestSetSettingNotification(state);
}

//make color
void SxmCmd::requestRelatedList()
{
    LOGI().writeFormatted("SxmCmd::requestRelatedList() called");
    emit eventRequestRelatedList();
}
//make color

/*!
 * \brief SxmCmd::eventRequestAddFavoriteTeam
 * \param _parameterList
 */
void SxmCmd::requestAddFavoriteTeam(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestAddFavoriteTeam() called");
    SPORTS_TEAM_TYPE type = static_cast<SPORTS_TEAM_TYPE>(_parameterList[0].toInt());

    emit eventRequestAddFavoriteTeam(type);
}

/*!
 * \brief SxmCmd::eventRequestRemoveFavoriteTeam
 * \param _parameterList
 */
void SxmCmd::requestRemoveFavoriteTeam(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::eventRequestRemoveFavoriteTeam() called");
    uint8_t teamId = static_cast<uint8_t>(_parameterList[0].toInt());

    emit eventRequestRemoveFavoriteTeam(teamId);
}

/*!
 * \brief SxmCmd::requestGetTeams
 * \param _parameterList
 */
void SxmCmd::requestGetTeams(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestGetTeams() called");
//    uint8_t leagueId = static_cast<uint8_t>(_parameterList[0].toInt());
    //TODO: will be update
    int leagueId;
    if (_parameterList[0].size() > 1)
        leagueId = DataController::instance()->lookupLeagueId(_parameterList[0]);
    else
        leagueId = static_cast<int>(_parameterList[0].toInt());
    LOGI().writeFormatted("SxmCmd::requestGetTeams() called LeagueID: %d", leagueId);
    if (leagueId >= 0){
        emit eventRequestGetTeams(leagueId);
    }
}

/*!
 * \brief SxmCmd::requestGetLeague
 */
void SxmCmd::requestGetLeagues()
{
    LOGI().writeFormatted("SxmCmd::requestGetLeagues() called");

    emit eventRequestGetLeagues();
}

/*!
 * \brief SxmCmd::requestAddTeamAlerts
 * \param _parameterList
 */
void SxmCmd::requestAddTeamAlerts(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestAddTeamAlerts() called");
    uint8_t teamId = static_cast<uint8_t>(_parameterList[0].toInt());

    emit eventRequestAddTeamAlerts(teamId);
}

/*!
 * \brief SxmCmd::requestRemoveTeamAlerts
 * \param _parameterList
 */
void SxmCmd::requestRemoveTeamAlerts(QStringList _parameterList)
{
    LOGI().writeFormatted("SxmCmd::requestRemoveTeamAlerts() called");
    uint8_t teamId = static_cast<uint8_t>(_parameterList[0].toInt());

    emit eventRequestRemoveTeamAlerts(teamId);
}

/*!
 * \brief SxmCmd::requestGetTeamAlerts
 */
void SxmCmd::requestGetTeamAlerts()
{
    LOGI().writeFormatted("SxmCmd::requestGetTeamAlerts() called");

    emit eventRequestGetTeamAlerts();
}

void SxmCmd::requestGetFavoriteTeams()
{
    LOGI().writeFormatted("SxmCmd::requestGetFavoriteTeams() called");

    emit eventRequestGetFavoriteTeams();
}

void SxmCmd::requestSatSubscriptionState()
{
    LOGI().writeFormatted("[SxmCmd::requestSatSubscriptionState]");
    emit eventRequestSatSubscriptionState();
}

void SxmCmd::requestGetAntennaState()
{
    LOGI().writeFormatted("[SxmCmd::requestSatSubscriptionState]");
    emit eventRequestGetAntennaState();
}

void SxmCmd::requestGetCurrentIndexLinearTune()
{
    LOGI().writeFormatted("[SxmCmd::requestGetCurrentIndexLinearTune]");
    DataController::instance()->eventGetCurrenIndexLinearTune();
}

void SxmCmd::requestSpeechModePttLongPress()
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModePttLongPress]");
    emit eventRequestSpeechModePttLongPress();
}

void SxmCmd::requestSpeechModeSelect(QStringList parameterList)
{
//    LOGI().writeFormatted("[SxmCmd::requestSpeechModeSelect]::channel %d is chosen",parameterList[1].toInt());
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeSelect] called");
//    QString param = parameterList[0];
    emit eventRequestSpeechModeSelect(parameterList);
}

void SxmCmd::requestSpeechModeTpSelect(QStringList parameterList)
{
    QString param = parameterList[0];
    bool    bConvert = false;
    int     num = param.toInt(&bConvert, 10);
    if (!bConvert) {
        num = -1;
    }
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeTpSelect] called, select at %d",num);
    emit eventRequestSpeechModeTpSelect(num);
}

void SxmCmd::requestSpeechModeScrollStart(QStringList parameterList)
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeScrollStart] called at channel %d",parameterList[0].toInt());
    emit eventRequestSpeechModeScrollStart();
}

void SxmCmd::requestSpeechModeScrollStop(QStringList parameterList)
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeScrollStop] called at channel %d",parameterList[0].toInt());
    emit eventRequestSpeechModeScrollStop();
}

void SxmCmd::requestSpeechModeResponseListPage(QStringList parameterList)
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeResponseListPage]");
    bool result = static_cast<bool>(parameterList[0].toInt());
    emit eventRequestSpeechModeResponseListPage(result);
}

void SxmCmd::requestSpeechModeResponseLineNumAbsoluteIdx(QStringList parameterList)
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeResponseLineNumAbsoluteIdx]");
    int absoluteIdx = static_cast<int>(parameterList[0].toInt());
    emit eventRequestSpeechModeResponseLineNumAbsoluteIdx(absoluteIdx);
}

void SxmCmd::requestSpeechModeResponseListFocusSet(QStringList parameterList)
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeResponseListFocusSet]");
    bool result = static_cast<bool>(parameterList[0].toInt());
    emit eventRequestSpeechModeResponseListFocusSet(result);
}

void SxmCmd::requestSpeechModeSdarsTeamData()
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeSdarsTeamData]");
    emit eventRequestSpeechModeSdarsTeamData();
}

void SxmCmd::requestSpeechModeSdarsDataChannel()
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeSdarsDataChannel]");
    emit eventRequestSpeechModeSdarsDataChannel();
}

void SxmCmd::requestSpeechModeSdarsCategorySatList()
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeSdarsCategorySatList]");
    emit eventRequestSpeechModeSdarsCategorySatList();
}

void SxmCmd::requestSpeechModeSdarsCategoryChannel(QStringList parameterList)
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeSdarsCategoryChannel]");
    QString category = parameterList[0];
    emit eventRequestSpeechModeSdarsCategoryChannel(category);
}

void SxmCmd::requestSpeechModeListCurrentIndexChanged(QStringList parameterList)
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeListCurrentIndexChanged]");
    int currentIndex = static_cast<int>(parameterList[0].toInt());
    DataController::instance()->currentIndexListSpeechModeChanged(currentIndex);
}

void SxmCmd::requestSpeechModeVoicetagsFavorite(QStringList parameterList)
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeVoicetagsFavorite]");
    uint32_t channelNumber = static_cast<int>(parameterList[0].toUInt());

    emit eventRequestSpeechModeVoicetagFavorite(channelNumber);

}

void SxmCmd::requestSpeechModeVoicetagsChannel(QStringList parameterList)
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeVoicetagsChannel]");
//    uint32_t channelNumber = static_cast<int>parameterList[0].toUInt();
    emit eventRequestSpeechModeVoicetagChannel(parameterList[0]);
}

void SxmCmd::requestSpeechModeVoicetagsChannelInput(QStringList parameterList)
{
    LOGI().writeFormatted("[SxmCmd::requestSpeechModeVoicetagsChannelInput]");
//    uint32_t channelNumber = static_cast<int>parameterList[0].toUInt();
    emit eventRequestSpeechModeVoicetagChannelInput(parameterList[0]);
}

//*!
// * \brief SxmCmd::requestGetLiveSports
// *
//void SxmCmd::requestGetLiveSports()
//{
//    LOGI().writeFormatted("SxmCmd::requestGetLiveSports() called");

//    emit eventRequestGetLiveSports();
//}

//*!
// * \brief SxmCmd::requestTuneLiveSports
// * \param _parameterList
// *
//void SxmCmd::requestTuneLiveSports(QStringList _parameterList)
//{
//    LOGI().writeFormatted("SxmCmd::requestTuneLiveSports() called");
//    uint8_t leagueId = static_cast<uint8_t>(_parameterList[0].toInt());

//    emit eventRequestTuneLiveSports(leagueId);
//}

void SxmCmd::requestShowKeyboard(QStringList _parameter)
{
    LOGI().writeFormatted("SxmCmd::requestShowKeyboard() called");
    uint32_t _clientSessionId = static_cast<uint32_t>(_parameter[0].toInt());
    E_KEYBOARD_TYPE _eKeyboardType = static_cast<E_KEYBOARD_TYPE>(_parameter[1].toInt());
//    QString _preFilledText = _parameter[2];
//    QString _defaultText = _parameter[3];
    const char* _preFilledText = _parameter[2].toStdString().c_str();
    const char* _defaultText = _parameter[3].toStdString().c_str();

    uint32_t _maxLength = static_cast<uint32_t>(_parameter[4].toInt());
    emit eventRequestShowKeyboard(_clientSessionId, _eKeyboardType, _preFilledText,
                                  _defaultText, _maxLength);
}

void SxmCmd::requestHideKeyboard(QStringList _parameter)
{
    LOGI().writeFormatted("SxmCmd::requestShowKeyboard() called");
    uint32_t _clientSessionId = static_cast<uint32_t>(_parameter[0].toInt());
    emit eventRequestHideKeyboard(_clientSessionId);
}

void SxmCmd::responseCandidateInfo(QStringList _parameter)
{
    LOGI().writeFormatted("SxmCmd::requestShowKeyboard() called");
    uint32_t _clientSessionId = static_cast<uint32_t>(_parameter[0].toInt());
    uint32_t userInputID = static_cast<uint32_t>(_parameter[1].toInt());
//    uint32_t candidateSessionID = static_cast<uint32_t>(_parameter[2].toInt());
//    uint32_t suggestionCount = static_cast<uint32_t>(_parameter[3].toInt());
//    const char* userInputText = _parameter[4].toStdString().c_str();
    const char* suggestionResultContext = _parameter[2].toStdString().c_str();

    emit eventResponseCandidateInfo(_clientSessionId, userInputID, suggestionResultContext);
}

void SxmCmd::responseCandidateList(QStringList _parameter)
{
    LOGI().writeFormatted("SxmCmd::requestShowKeyboard() called");
    uint32_t _clientSessionId = static_cast<uint32_t>(_parameter[0].toInt());
    uint32_t candidateSessionID = static_cast<uint32_t>(_parameter[1].toInt());
    const char* userInputText = _parameter[2].toStdString().c_str();
    uint32_t startIndex = static_cast<uint32_t>(_parameter[3].toInt());
    uint32_t endIndex = static_cast<uint32_t>(_parameter[4].toInt());

//    QString _preFilledText = _parameter[2];
//    QString _defaultText = _parameter[3];
//    const char* candidateListContext = _parameter[5].toStdString().c_str();

    emit eventResponseCandidateList(_clientSessionId, candidateSessionID, userInputText, startIndex, endIndex);
}


void SxmCmd::requestShowPopup(QStringList _parameter)
{
    LOGI().writeFormatted("SxmCmd::requestShowPopup() called");
    uint32_t _clientSession = static_cast<uint32_t>(_parameter[0].toInt());
    PopupJsonContextHandler *handler = new PopupJsonContextHandler();
    handler->startJSONContext();
    handler->addJSONPopupTitle("");
    handler->addJSONPopupImage("/ivibcast/sxm360l/sxe_baselines/F_pix_A0000V000.jpg");
    handler->addJSONPopupContent("Maximum favorites reached \n \n You have reached the maximum number of favorites");

//    handler.addJSONPopupCheckBox("Don't show me again", true);
//    handler.addJSONPopupImage("");
//    handler.addJSONPopupTimer(1000);
    handler->addJSONPopupButton("Manage");
    handler->finishJSONContext();
    std::string popupContext = handler->getPopupContext();
    emit eventRequestShowPopup(_clientSession, E_POPUP_TYPE_POPUP, E_POPUP_SIDE_TYPE_ONEBUTTON,
                               E_POPUP_SIZE_SMALL, popupContext.c_str(), 1);
}

void SxmCmd::requestHidePopup(QStringList _parameter)
{
    LOGI().writeFormatted("SxmCmd::requestResumingSatelliteOnCompleted() called");
    uint32_t _clientSession = static_cast<uint32_t>(_parameter[0].toInt());
    uint32_t _handle = static_cast<uint32_t>(_parameter[1].toInt());
    emit eventRequestHidePopup(_clientSession, _handle);
}

void SxmCmd::requestUpdatePopup(QStringList _parameter)
{
    LOGI().writeFormatted("SxmCmd::requestResumingSatelliteOnCompleted() called");
    uint32_t _clientSession = static_cast<uint32_t>(_parameter[0].toInt());
    uint32_t _handle = static_cast<uint32_t>(_parameter[1].toInt());
    PopupJsonContextHandler handler;
    handler.startJSONContext();
    handler.addJSONPopupTitle("SXM Popup Title");
    handler.addJSONPopupContent("Van Bom Update");
    handler.addJSONPopupCheckBox("Don't show me again", true);
    handler.addJSONPopupButton("OK");
    handler.addJSONPopupButton("CANCEL");
    handler.addJSONPopupTimer(30);
    handler.finishJSONContext();
    std::string _popupContext = handler.getPopupContext();

    emit eventRequestUpdatePopup(_clientSession, _handle, _popupContext.c_str());
}

void SxmCmd::requestShowScpecialPopup(QStringList _parameter)
{
    LOGI().writeFormatted("SxmCmd::requestResumingSatelliteOnCompleted() called");
    uint32_t _clientSession = static_cast<uint32_t>(_parameter[0].toInt());
    uint32_t _handle = static_cast<uint32_t>(_parameter[1].toInt());
    PopupJsonContextHandler handler;
    handler.startJSONContext();
    handler.addJSONPopupTitle("SXM Popup Title");
    handler.addJSONPopupContent("Van Bom Special");
    handler.addJSONPopupCheckBox("Don't show me again", true);
    handler.addJSONPopupButton("OK");
    handler.addJSONPopupButton("CANCEL");
    handler.finishJSONContext();
    std::string _popupContext = handler.getPopupContext();
    emit eventRequestShowScpecialPopup(_clientSession, E_SPECIAL_POPUP_TYPE_ANNOUNCEMENT, _popupContext.c_str(), 1000);
}
