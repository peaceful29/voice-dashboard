#ifndef SXMKEYPADHANDLER_H
#define SXMKEYPADHANDLER_H

#include <QString>
#include <QObject>
#include <QMap>
#include "Common/Utils.h"
#include "Common/SingletonHmi.h"
#include "sxm360l/Sxm360lMsgDef.h"

typedef struct {
    QString strName;
    QString strLogo;
} SUGGESTIONS;

class SXMKeyPadHandler : public QObject, public SingletonHmi<SXMKeyPadHandler>
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
    friend class SingletonHmi<SXMKeyPadHandler>;
public:
    static SXMKeyPadHandler *instance();
    void getSXMValidNumber(int currentNumber, QString& validkey, bool& isValid);
    void createValidNumberMapping();
    QString getValidMapValue(int currentNumber);
    QString appendValidNumber(QString currentVal, QString newVal);
    QString getSeekChannel(QString currentChannel, QString seekType);
    QList<SUGGESTIONS> getLstSuggestion(QString currentChar);
signals:
    void doneGetSXMValidNumber(QString validkey, bool isValid);
private:
    SXMKeyPadHandler();
    QList<int> m_channelList;
    QList<QString> m_channelNameLst;
    QMap<int, QString> m_validMap;
};

#endif // SXMKEYPADHANDLER_H
