#ifndef DATANOTIFIER_H
#define DATANOTIFIER_H

#include <QObject>
#include <QHash>
#include <QVector>

#include "DataIdentifier.h"

class DataNotifier: public QObject
{
    Q_OBJECT
public:
    DataNotifier(const QVector<DataIdentifier::E_EVENT_NOTIFIER> notifiedEvent,QObject *parent=nullptr);

    int notifiedEvent() const;
    bool addNotifiedEvent(DataIdentifier::E_EVENT_NOTIFIER eventId);
    bool removeNotifiedEvent(DataIdentifier::E_EVENT_NOTIFIER eventId);
    bool existNotifiedEvent(DataIdentifier::E_EVENT_NOTIFIER eventId);
    void notifyEvent(DataIdentifier::E_EVENT_NOTIFIER eventId);

signals:
    void eventScreenUpdate(DataIdentifier::E_EVENT_NOTIFIER eventId);
private:
    QHash<DataIdentifier::E_EVENT_NOTIFIER, int> m_notifiedEvent;
};

#endif // DATANOTIFIER_H
