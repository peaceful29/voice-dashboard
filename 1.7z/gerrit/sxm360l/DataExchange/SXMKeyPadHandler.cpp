#include "SXMKeyPadHandler.h"
#include <QDebug>
#include "DataController.h"

SXMKeyPadHandler::SXMKeyPadHandler()
{
}


/*!
 * \brief SXMKeyPadHandler::instance
 * \return
 */
SXMKeyPadHandler *SXMKeyPadHandler::instance()
{
    return SingletonHmi::getInstance();
}

/*!
 * \brief SXMKeyPadHandler::getSXMValidNumber
 * \param currentNumber
 */
void SXMKeyPadHandler::getSXMValidNumber(int currentNumber, QString &validkey, bool &isValid)
{
//    emit doneGetSXMValidNumber(m_validMap.value(currentNumber, ""), m_channelList.contains(currentNumber));
    validkey = m_validMap.value(currentNumber, "");
    isValid = m_channelList.contains(currentNumber);
}

/*!
 * \brief SXMKeyPadHandler::createValidNumberMapping
 */
void SXMKeyPadHandler::createValidNumberMapping()
{
    m_channelList.clear();
    m_validMap.clear();
    m_channelList = DataController::instance()->getListChannel();
    for (int i = 0; i < m_channelList.length(); i++){
        int _first = m_channelList.at(i)/10000;
        m_validMap[_first] = appendValidNumber(getValidMapValue(_first), QString::number(m_channelList.at(i)/1000));
        int _second = m_channelList.at(i)/1000;
        m_validMap[_second]  = appendValidNumber(getValidMapValue(_second),  QString::number((m_channelList.at(i)%1000)/100));
        int _third = m_channelList.at(i)/100;
        m_validMap[_third]  = appendValidNumber(getValidMapValue(_third),  QString::number((m_channelList.at(i)%100/10)));
        int _fourth = m_channelList.at(i)/10;
        m_validMap[_fourth]  = appendValidNumber(getValidMapValue(_fourth),  QString::number(m_channelList.at(i)%10));
    }
    LOGI().writeFormatted("[SXMKeyPadHandler::createValidNumberMapping]NumberChannel[%d]ValidMap[%d]", m_channelList.size(), m_validMap.size());
}

/*!
 * \brief SXMKeyPadHandler::getValidMapValue
 * \param currentNumber
 * \return
 */
QString SXMKeyPadHandler::getValidMapValue(int currentNumber)
{
    return m_validMap.value(currentNumber, "");
}

/*!
 * \brief SXMKeyPadHandler::appendValidNumber
 * \param currentVal
 * \param newVal
 * \return
 */
QString SXMKeyPadHandler::appendValidNumber(QString currentVal, QString newVal)
{
    if (currentVal.contains(newVal))
        return currentVal;
    return currentVal + newVal;
}

QString SXMKeyPadHandler::getSeekChannel(QString currentChannel, QString seekType)
{
    QString ret = "";
    int currentIdx = m_channelList.indexOf(currentChannel.toInt());
    if (currentIdx == -1)
        return ret;
    if (seekType == "Next") {
        ret = QString::number(m_channelList.at(currentIdx + 1));
    } else {
        ret = QString::number(m_channelList.at(currentIdx - 1));
    }
    return ret;
}

QList<SUGGESTIONS> SXMKeyPadHandler::getLstSuggestion(QString currentChar)
{
    m_channelList.clear();
    m_channelNameLst.clear();
    m_channelList = DataController::instance()->getListChannel();
    m_channelNameLst = DataController::instance()->getLstChannelName();
    QList<CHANNEL_INFORMATION_T> lstChannels = DataController::instance()->getAllChannelInformation();
    QList<SUGGESTIONS> lstSuggest;
    SUGGESTIONS suggestion;
//    QStringList lstSuggest;
    QRegExp re("\\d*");
    if (re.exactMatch(currentChar)) {
        for (int i = 0; i < m_channelList.length(); i++){
            if (QString::number(m_channelList.at(i)).startsWith(currentChar.trimmed()) && m_channelList.at(i) != currentChar.toInt()){
//                lstSuggest.append(QString::number(m_channelList.at(i)));
                suggestion.strName = QString::number(m_channelList.at(i));
                suggestion.strLogo = lstChannels[i].logoUrl;
                lstSuggest.append(suggestion);
            }
        }
    } else {
        for (int i = 0; i < m_channelNameLst.length(); i++){
//            qDebug() << "m_channelNameLst: " << m_channelNameLst.at(i).toStdString().c_str();
            if (m_channelNameLst.at(i).toLower().startsWith(currentChar.trimmed().toLower())){
//                lstSuggest.append(m_channelNameLst.at(i));
                suggestion.strName = m_channelNameLst.at(i);
                suggestion.strLogo = lstChannels[i].logoUrl;
                lstSuggest.append(suggestion);
            }
        }
    }
    return lstSuggest;
}
