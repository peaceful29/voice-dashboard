#include "base/interface/IBaseListener.h"
#include "base/interface/OnBaseListener.h"
#include "SxmSpeechServiceInterface.h"
#include "DataController.h"
#include "ScreenList.h"

#ifndef EXCLUDE_SPEECH
#include "SpeechService.h"
#endif

#define SPEECH_COMMAND_TUNER_CATEGORY_SAT   "SYSTEM_CMD_system_picklist_list_item"
#define SPEECH_COMMAND_TUNER_STATION_SAT   "SYSTEM_CMD_system_picklist_list_item"
#define SPEECH_COMMAND_TUNER_CHANNEL_LIST   "SYSTEM_CMD_tuner_sdars_channel_number_subdialog"
#define SPEECH_COMMAND_TUNER_CATEGORY_SAT_LIST "SYSTEM_CMD_tuner_category_subdialog_SAT"
#define SPEECH_COMMAND_TUNER_CATEGORY_STATION_LIST_SAT "SYSTEM_CMD_tuner_station_name_subdialog"
#define SPEECH_COMMAND_TUNER_SDARS_TEAM "SYSTEM_CMD_tuner_sdars_add_to_memory_team_input"
#define SPEECH_COMMAND_TUNER_STATION_LIST_SAT "SYSTEM_CMD_tuner_station_name_subdialog"

SxmSpeechServiceInterface::SxmSpeechServiceInterface(QObject *parent)
    : SxmAbstractInterface(parent)
{
#ifndef EXCLUDE_SPEECH
    m_speechService = new SpeechService(this);
#endif
}

SxmSpeechServiceInterface::~SxmSpeechServiceInterface()
{
#ifndef EXCLUDE_SPEECH
    SafeDelete<SpeechService>(m_speechService);
#endif
}

IBaseListener *SxmSpeechServiceInterface::ilistener()
{
#ifndef EXCLUDE_SPEECH
    return m_speechService;
#else
    return nullptr;
#endif
}

void SxmSpeechServiceInterface::initialize(OnBaseListener *engine)
{
#ifndef EXCLUDE_SPEECH
    m_speechService->initialize(engine);
#else
    Q_UNUSED(engine);
#endif
}

void SxmSpeechServiceInterface::registerListener(OnBaseListener *engine)
{
#ifndef EXCLUDE_SPEECH
    engine->registerListener(m_speechService);
#else
    Q_UNUSED(engine);
#endif
}

void SxmSpeechServiceInterface::onSpeechMode()
{

}

void SxmSpeechServiceInterface::onScfaListPage(const E_VIDEO_TUNER_PAGE_NAVIGATION pageNavigation)
{
#ifndef EXCLUDE_SPEECH
    DataController::instance()->eventScfaListPage(pageNavigation);
#else
    Q_UNUSED(pageNavigation);
#endif
}

void SxmSpeechServiceInterface::onScfaListDataGet(const int32_t nLineNumber)
{
#ifndef EXCLUDE_SPEECH
    DataController::instance()->eventScfaListDataGet(nLineNumber);
#else
    Q_UNUSED(nLineNumber);
#endif
}

void SxmSpeechServiceInterface::onScfaListFocusSet(const int32_t absoluteIdx)
{
#ifndef EXCLUDE_SPEECH
    DataController::instance()->eventScfaListFocusSet(absoluteIdx);
#else
    Q_UNUSED(absoluteIdx);
#endif
}

void SxmSpeechServiceInterface::onSpeechSdarsTeamData()
{
#ifndef EXCLUDE_SPEECH
    DataController::instance()->eventSpeechSdarsTeamData();
#endif
}

void SxmSpeechServiceInterface::onSpeechSdarsCategoryChannels(QString category)
{
#ifndef EXCLUDE_SPEECH
    DataController::instance()->eventSpeechSdarsCategoryChannel(category);
#endif
}

void SxmSpeechServiceInterface::onSpeechSdarsDataChannel()
{
#ifndef EXCLUDE_SPEECH
    DataController::instance()->eventSpeechSdarsDataChannel();
#endif
}

void SxmSpeechServiceInterface::onSpeechSdarsCategorySatList()
{
#ifndef EXCLUDE_SPEECH
    DataController::instance()->eventSpeechSdarsCategorySatList();
#endif
}

void SxmSpeechServiceInterface::requestLaunchingBaseFeature()
{
#ifndef EXCLUDE_SPEECH
    emit eventLaunchingBaseFeature();
#endif
}

void SxmSpeechServiceInterface::onEventRequestPttLongPress()
{
#ifndef EXCLUDE_SPEECH
    if (m_speechService != nullptr){
        m_speechService->requestPttLongPress();
    }
#endif
}

void SxmSpeechServiceInterface::onEventRequestSpeechModeSelect(QStringList param)
{
#ifndef EXCLUDE_SPEECH
    uint32_t    currentScreenId = ScreenListInstance()->getCurrentScreenID();
    QString     commandCmd = "";
    switch (currentScreenId) {
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_SAT:
        commandCmd = SPEECH_COMMAND_TUNER_CATEGORY_SAT;
        if (m_speechService != nullptr){
            LOGI().writeFormatted("[SxmSpeechServiceInterface::onEventRequestSpeechModeSelect]Command[%s]", commandCmd.toStdString().c_str());
            m_speechService->requestSelect(param[0], commandCmd);
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_STATION_SAT:
        commandCmd = SPEECH_COMMAND_TUNER_STATION_SAT;
        if (m_speechService != nullptr){
            LOGI().writeFormatted("[SxmSpeechServiceInterface::onEventRequestSpeechModeSelect]Command[%s]", commandCmd.toStdString().c_str());
            m_speechService->requestSelect(param[0], commandCmd);
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CHANNELLIST:
        commandCmd = SPEECH_COMMAND_TUNER_CHANNEL_LIST;
        if (m_speechService != nullptr){
            LOGI().writeFormatted("[SxmSpeechServiceInterface::onEventRequestSpeechModeSelect]Command[%s]", commandCmd.toStdString().c_str());
            m_speechService->requestSelect(param[0], commandCmd);
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_SAT_LIST:
        commandCmd = SPEECH_COMMAND_TUNER_CATEGORY_SAT_LIST;
        if (m_speechService != nullptr){
            LOGI().writeFormatted("[SxmSpeechServiceInterface::onEventRequestSpeechModeSelect]Command[%s]", commandCmd.toStdString().c_str());
            m_speechService->requestSelect(param[0], param[1], commandCmd);
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_STATION_LIST_SAT:
        commandCmd = SPEECH_COMMAND_TUNER_CATEGORY_STATION_LIST_SAT;
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_SDARS_TEAM:
        commandCmd = SPEECH_COMMAND_TUNER_SDARS_TEAM;
        if (m_speechService != nullptr){
            LOGI().writeFormatted("[SxmSpeechServiceInterface::onEventRequestSpeechModeSelect]Command[%s]", commandCmd.toStdString().c_str());
            m_speechService->requestSelect(param[0], param[1], commandCmd);
        }
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_LIST_SAT:
        commandCmd = SPEECH_COMMAND_TUNER_STATION_LIST_SAT;
        if (m_speechService != nullptr){
            LOGI().writeFormatted("[SxmSpeechServiceInterface::onEventRequestSpeechModeSelect]Command[%s]", commandCmd.toStdString().c_str());
            m_speechService->requestSelect(param[0],param[1], commandCmd);
        }
        break;
    default:
        LOGI().writeFormatted("[SxmSpeechServiceInterface::onEventRequestSpeechModeSelect]Can't detect command[%s]");
        break;
    }

#endif
}

void SxmSpeechServiceInterface::onEventRequestSpeechModeTpSelect(int num)
{
#ifndef EXCLUDE_SPEECH
    LOGI().writeFormatted("[SxmSpeechServiceInterface::onEventRequestSpeechModeTpSelect] at [%d]", num);
    if (m_speechService != nullptr){
        m_speechService->requestTpSelect(num);
    }

#endif
}

void SxmSpeechServiceInterface::onEventRequestSpeechModeScrollStart()
{
#ifndef EXCLUDE_SPEECH
    LOGI().writeFormatted("[SxmSpeechServiceInterface::onEventRequestSpeechModeScrollStart]");
    if (m_speechService != nullptr){
        m_speechService->requestScrollStart();
    }
#endif
}

void SxmSpeechServiceInterface::onEventRequestSpeechModeScrollStop()
{
#ifndef EXCLUDE_SPEECH
    LOGI().writeFormatted("[SxmSpeechServiceInterface::onEventRequestSpeechModeScrollStop]");
    if (m_speechService != nullptr){
        m_speechService->requestScrollStop();
    }
#endif
}

void SxmSpeechServiceInterface::onEventResponseListPage(bool result)
{
#ifndef EXCLUDE_SPEECH
    if (m_speechService != nullptr){
        m_speechService->responseListPage(result);
    }
#else
    Q_UNUSED(result);
#endif
}

void SxmSpeechServiceInterface::onEventRequestSpeechModeResponseLineNumAbsoluteIdx(int absoluteIdx)
{
#ifndef EXCLUDE_SPEECH
    if (m_speechService != nullptr){
        m_speechService->responseLineNumAbsoluteIdx(absoluteIdx);
    }
#else
    Q_UNUSED(absoluteIdx);
#endif
}

void SxmSpeechServiceInterface::onEventRequestSpeechModeResponseListFocusSet(bool result)
{
#ifndef EXCLUDE_SPEECH
    if (m_speechService != nullptr){
        m_speechService->responseListFocusSet(result);
    }
#else
    Q_UNUSED(absoluteIdx);
#endif
}

void SxmSpeechServiceInterface::onEventRequestSpeechModeSdarsTeamData()
{
#ifndef EXCLUDE_SPEECH
    if (m_speechService != nullptr){
        m_speechService->requestSdarsTeamData();
    }
#endif
}

void SxmSpeechServiceInterface::onEventRequestSpeechModeSdarsDataChannel()
{
#ifndef EXCLUDE_SPEECH
    if (m_speechService != nullptr){
        m_speechService->requestSdarsDataChannel();
    }
#endif
}

void SxmSpeechServiceInterface::onEventRequestSpeechModeSdarsCategorySatList()
{
#ifndef EXCLUDE_SPEECH
    if (m_speechService != nullptr){
        m_speechService->requestSdarsCategorySatList();
    }
#endif
}

void SxmSpeechServiceInterface::onEventRequestSpeechModeSdarsCategoryChannel(QString category)
{
#ifndef EXCLUDE_SPEECH
    if (m_speechService != nullptr){
        m_speechService->requestSdarsCategoryChannel(category);
    }
#endif
}

void SxmSpeechServiceInterface::onEventResponseScfaScreenShow(int requestId, int eResult)
{
#ifndef EXCLUDE_SPEECH
    if (m_speechService != nullptr){
        m_speechService->responseScfaScreenShow(requestId, eResult);
    }
#else
    Q_UNUSED(requestId);
    Q_UNUSED(eResult);
#endif
}
