#ifndef SXMAPPSERVICEINTERFACE_H
#define SXMAPPSERVICEINTERFACE_H

#include "SxmAbstractInterface.h"
#include "Common/Utils.h"
#include "appservice/AppMsgDef.h"
#include "sxm360l/Sxm360lMsgDef.h"

class QQuickView;
class SxmAppService;
class AudioService;

class SxmAppServiceInterface: public SxmAbstractInterface
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    explicit SxmAppServiceInterface(QObject* parent= nullptr);
    virtual ~SxmAppServiceInterface();

    IBaseListener *ilistener();
    void initialize(OnBaseListener* engine);
    void registerListener(OnBaseListener* engine);

    void registerWindowTarget(QQuickView* _windowTarget);
//    void show();
    void registerApplication();
    void onCmdCreateAppWindow();
    void onCmdDestroyAppWindow();

    Q_INVOKABLE void goBack();
    void showApplication(QString strAppRole, QString strIntent);
    void cmdShowAppWindow(QString strAppRole, QString strIntent);
    void responseScfaScreenShow(const int &requestID, const E_REQ_RESULT_MSG &eResult);
signals:
    void cmdCreateAppWindow();
    void cmdDestroyAppWindow();
    void cmdShowApplication(QString appRole, QString intent);
    void eventCmdShowAppWindow(QString strAppRole, QString strIntent);
    void eventResponseScfaScreenShow(int requestId, int eResult);

public slots:
    void onEventRequestToShowSystemComponent(const int& requestId,
                                             const E_SYSTEM_COMPONENT& eSystemComponent,
                                             const char* strData=STRING_DATA_NONE);
    void onEventRequestToHideSystemComponent(const int& requestId,
                                             const E_SYSTEM_COMPONENT& eSystemComponent,
                                             const char* strData=STRING_DATA_NONE);
    void onEventRequestToGoApplication(const int& requestID,
                                       const char* strAppBinaryName,
                                       const char* strAppRole,
                                       const char* strIntent,
                                       const E_SHOW_OPT& eShowOpt=E_SHOW_OPT_CLEAR_AND_ADD);
    void onEventRequestSpeechModeLaunchingBaseFeature();
    // speech move voicetag favorite
    void onEventRequestSpeechModeVoicetagFavorite(const uint32_t& number);
    void onEventRequestSpeechModeVoicetagChannel(QString& number);
    void onEventRequestSpeechModeVoicetagChannelInput(QString& number);
private:
    void requestVoiceChannelInfo(CHANNEL_INFORMATION_T &channelInfo, QString menu);
    QList<QQuickView*> m_windowTargets;
    bool m_firstBlood;

    SxmAppService* m_appService;
    AudioService *m_audioService;

};

#endif // SXMAPPSERVICEINTERFACE_H
