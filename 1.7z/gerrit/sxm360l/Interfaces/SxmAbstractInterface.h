#ifndef SXMABSTRACTINTERFACE_H
#define SXMABSTRACTINTERFACE_H

#include <QObject>

class IBaseListener;
class OnBaseListener;

class SxmAbstractInterface: public QObject
{
    Q_OBJECT
public:
    SxmAbstractInterface(QObject* parent=nullptr) {
        Q_UNUSED(parent)
    }

    virtual IBaseListener* ilistener() = 0;
    virtual void initialize(OnBaseListener* _engine) = 0;
    virtual void registerListener(OnBaseListener* _engine) = 0;
};

#endif // SXMABSTRACTINTERFACE_H
