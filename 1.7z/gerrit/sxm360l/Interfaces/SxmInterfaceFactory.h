#ifndef SXMINTERFACEFACTORY_H
#define SXMINTERFACEFACTORY_H

#include <QObject>
#include "SxmAbstractInterface.h"

class OnBaseListener;

class SxmInterfaceFactory : public QObject
{
    Q_OBJECT
public:
    virtual ~SxmInterfaceFactory();
    static SxmInterfaceFactory* instance();

    template<class T>
    inline T* interface() {
        static T* instance = nullptr;
        if (!instance) {
            instance = new T();
        }
        return instance;
    }
    bool append(SxmAbstractInterface* _iface);
//    bool start();
    bool newStart(SxmAbstractInterface* _iface);

protected:
    explicit SxmInterfaceFactory(QObject *parent = nullptr);

private:
    static SxmInterfaceFactory *m_instance;
    QList<SxmAbstractInterface*> m_ifaces;
    OnBaseListener *m_baseListener;
    QString m_mqPath;
};

#endif // SXMINTERFACEFACTORY_H
