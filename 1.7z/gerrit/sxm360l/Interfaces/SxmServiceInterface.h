#ifndef SXMSERVICEINTERFACE_H
#define SXMSERVICEINTERFACE_H

#include "SxmAbstractInterface.h"
#include "Common/Utils.h"
#include "sxm360l/Sxm360lMsgDef.h"

class SxmService;

class SxmServiceInterface: public SxmAbstractInterface
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    explicit SxmServiceInterface(QObject* parent = nullptr);
    virtual ~SxmServiceInterface();

    IBaseListener *ilistener();
    void initialize(OnBaseListener* engine);
    void registerListener(OnBaseListener *engine);
    void onEventSatSubscriptionState(const int state);
signals:
    void eventSatSubscriptionState(const int state);
public slots:
    void onEventSATDiagnostics();
    void onEventRequestInitSet(const int& id, const bool& bFlag, const char* msg);
    void onEventRequestInitState();
    void onEventRequestSuperCategories();
    void onEventRequestAllCategories();
    void onEventRequestCategories(const char* superCategory);
    void onEventRequestChannels(const char* category);
    void onEventRequestChannels();
    void onEventRequestChannelInformation(const uint32_t channelNumber);
    void onEventRequestFavorites();
    void onEventRequestAddFavorite(const uint32_t channelNumber);
    void onEventRequestRemoveFavorite(const uint32_t channelNumber);
    void onEventRequestTuneFavorite(const uint32_t channelNumber);
    void onEventRequestSmartFavorites();
    void onEventRequestMoveFavorite(const uint32_t index, const uint32_t new_index);
    void onEventRequestPlayback(const PLAY_STATE state);
    void onEventRequestTune(const uint32_t channelNumber);
    void onEventRequestTuneLastChannel();
    void onEventRequestSeekChannel(const SEEK_ACTION action);
    void onEventRequestSongAlerts();
    void onEventRequestArtistAlerts();
    void onEventRequestArtistAndSongAlerts();
    void onEventRequestAddSongAlert(const char* songTitle);
    void onEventRequestAddArtistAlert(const char* artistName);
    void onEventRequestRemoveSongAlert(const char* songTitle);
    void onEventRequestRemoveArtistAlert(const char* artistName);
    void onEventRequestRewind(const uint32_t step);
    void onEventRequestFastForward(const uint32_t step);
    void onEventRequestJumpPoint(const uint32_t point);
    void onEventRequestRecommendation();
    void onEventRequestListeningHistory();
    void onEventRequestLastChannelInfo();

    void onEventRequestGetChannelList(int count);
    //Test loss signal
    void onEventTestLossSignal();
    // PlayerResumingSatelliteBroadcastChannel.qml onCompleted
    void onEventRequestResumingSatelliteOnCompleted();
    //Profile
    void onEventRequestGetActiveProfiles();
    void onEventRequestCreateProfile(const char* name);
    void onEventRequestSetDefaultProfile();
    void onEventRequestSwitchProfile(const char* name);
    void onEventRequestDeleteProfile();
    void onEventRequestModifyProfileName(const char* name);
    void onEventRequestModifyProfileAvatar(const char* logoUrl);
    //Setting Notification
    void onEventRequestGetSettingNotification();
    void onEventRequestSetSettingNotification(const SETTING_NOTIFICATION_STATE state);
    //make color
    void onEventRequestRelatedList();
    //make color

    // Sport Team
    void onEventRequestAddFavoriteTeam(const SPORTS_TEAM_TYPE type);
    void onEventRequestRemoveFavoriteTeam(const int teamId);
    void onEventRequestGetTeams(const int leagueId);
    void onEventRequestGetLeagues();
    void onEventRequestAddTeamAlerts(const int teamId);
    void onEventRequestRemoveTeamAlerts(const int teamId);
    void onEventRequestGetTeamAlerts();
    void onEventRequestGetFavoriteTeams();
//    void onEventRequestGetLiveSports();
//    void onEventRequestTuneLiveSports(const int leagueId);
    void onEventRequestSatSubscriptionState();
    void onEventRequestGetAntennaState();

private:
    SxmService* m_sxmService;
};

#endif // SXMSERVICEINTERFACE_H
