#include <QGuiApplication>
#include "sxm360l/Sxm360lMsgDef.h"
#include "base/interface/IBaseListener.h"
#include "base/interface/OnBaseListener.h"
#include "SxmInterfaceFactory.h"
#include "Common/Utils.h"

SxmInterfaceFactory* SxmInterfaceFactory::m_instance = nullptr;

SxmInterfaceFactory::SxmInterfaceFactory(QObject *parent)
    : QObject(parent)
    , m_mqPath(MQ_HMI_SXM360L_RADIO_PATH)
{
    m_baseListener = new OnBaseListener(m_mqPath.toStdString().c_str());
}

SxmInterfaceFactory::~SxmInterfaceFactory()
{
    SafeDelete<OnBaseListener>(m_baseListener);
    qDeleteAll(m_ifaces);
}

SxmInterfaceFactory* SxmInterfaceFactory::instance()
{
    if (!m_instance) {
        m_instance = new SxmInterfaceFactory();
        m_instance->setParent(qApp);
    }
    return m_instance;
}

bool SxmInterfaceFactory::append(SxmAbstractInterface *_iface)
{
    bool result = !m_ifaces.contains(_iface);
    if (result) {
        m_ifaces.append(_iface);
    }
    return result;
}

//bool SxmInterfaceFactory::start()
//{
//    bool result = (m_baseListener == nullptr) && (m_ifaces.count() > 0);
//    if (result) {
//        m_baseListener = new OnBaseListener(m_mqPath.toStdString().c_str());
//        foreach (SxmAbstractInterface* iface, m_ifaces) {
//            iface->initialize(m_baseListener);
//            iface->registerListener(m_baseListener);
//        }
//    }
//    return result;
//}

bool SxmInterfaceFactory::newStart(SxmAbstractInterface *_iface)
{
    _iface->initialize(m_baseListener);
    _iface->registerListener(m_baseListener);
    return true;
}
