#ifndef SXMSPEECHSERVICEINTERFACE_H
#define SXMSPEECHSERVICEINTERFACE_H

#include "SxmAbstractInterface.h"
#include "Common/Utils.h"
#include "SXMDefine.h"

#ifndef EXCLUDE_SPEECH
class SpeechService;
#endif

class SxmSpeechServiceInterface : public SxmAbstractInterface
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SxmSpeechServiceInterface(QObject *parent = nullptr);
    virtual ~SxmSpeechServiceInterface();

    IBaseListener *ilistener();
    void initialize(OnBaseListener* engine);
    void registerListener(OnBaseListener* engine);

    void onSpeechMode();
    void onScfaListPage(const E_VIDEO_TUNER_PAGE_NAVIGATION pageNavigation);
    void onScfaListDataGet(const int32_t nLineNumber);
    void onScfaListFocusSet(const int32_t absoluteIdx);
    void onSpeechSdarsTeamData();
    void onSpeechSdarsDataChannel();
    void onSpeechSdarsCategorySatList();
    void onSpeechSdarsCategoryChannels(QString category);
    void requestLaunchingBaseFeature();

signals:
    void eventLaunchingBaseFeature();
public slots:
    void onEventRequestPttLongPress();
    void onEventRequestSpeechModeSelect(QStringList param);
    void onEventRequestSpeechModeTpSelect(int num);
    void onEventRequestSpeechModeScrollStart();
    void onEventRequestSpeechModeScrollStop();
    void onEventResponseListPage(bool result);
    void onEventRequestSpeechModeResponseLineNumAbsoluteIdx(int absoluteIdx);
    void onEventRequestSpeechModeResponseListFocusSet(bool result);
    void onEventRequestSpeechModeSdarsTeamData();
    void onEventRequestSpeechModeSdarsDataChannel();
    void onEventRequestSpeechModeSdarsCategorySatList();
    void onEventRequestSpeechModeSdarsCategoryChannel(QString category);
    void onEventResponseScfaScreenShow(int requestId, int eResult);
private:
#ifndef EXCLUDE_SPEECH
    SpeechService *m_speechService;
#endif
};

#endif // SXMSPEECHSERVICEINTERFACE_H
