#include "base/interface/OnBaseListener.h"
#include "base/interface/IBaseListener.h"
#include "SxmPopupServiceInterface.h"
#include "SxmPopupService.h"

SxmPopupServiceInterface::SxmPopupServiceInterface(QObject *parent)
{
    LOGI().writeFormatted("SxmPopupServiceInterface::SxmPopupServiceInterface() called");
    m_popupService = new SxmPopupService(this);
}

SxmPopupServiceInterface::~SxmPopupServiceInterface()
{
    SafeDelete<SxmPopupService>(m_popupService);
}

IBaseListener *SxmPopupServiceInterface::ilistener()
{
    return m_popupService;
}

void SxmPopupServiceInterface::initialize(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmPopupServiceInterface::initialize() called");
    m_popupService->initialize(engine);
}

void SxmPopupServiceInterface::registerListener(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmPopupServiceInterface::registerListener() called");
//    engine->registerListener(m_popupService);
}

void SxmPopupServiceInterface::onEventRequestShowPopup(const uint32_t &clientSessionID, const E_POPUP_TYPE &ePopupType, const E_POPUP_SIDE_TYPE &ePopupSideType, const E_POPUP_SIZE &ePopupSize, const char *popupContext, const uint32_t &priority)
{
    LOGI().writeFormatted("SxmPopupServiceInterface::requestShowPopup() called");
    if (m_popupService)
        m_popupService->requestShowPopup(clientSessionID, ePopupType, ePopupSideType, ePopupSize, popupContext, priority);
    else
        LOGI().writeFormatted("SxmPopupServiceInterface::requestShowPopup() called failed");
}

void SxmPopupServiceInterface::onEventRequestHidePopup(const uint32_t &clientSessionID, const uint32_t &handle)
{
    LOGI().writeFormatted("SxmPopupServiceInterface::requestHidePopup() called");
    if (m_popupService)
        m_popupService->requestHidePopup(clientSessionID, handle);
    else
        LOGI().writeFormatted("SxmPopupServiceInterface::requestShowPopup() called failed");
}

void SxmPopupServiceInterface::onEventRequestUpdatePopup(const uint32_t &clientSessionID, const uint32_t &handle, const char *popupContext)
{
    LOGI().writeFormatted("SxmPopupServiceInterface::requestUpdatePopup() called");
    if (m_popupService)
        m_popupService->requestUpdatePopup(clientSessionID, handle, popupContext);
    else
        LOGI().writeFormatted("SxmPopupServiceInterface::requestShowPopup() called failed");
}

void SxmPopupServiceInterface::onEventRequestShowSpecialPopup(const uint32_t &clientSessionID, const E_SPECIAL_POPUP_TYPE &eSpecialPopupType, const char *popupContext, const uint32_t &priority)
{
    LOGI().writeFormatted("SxmPopupServiceInterface::requestShowSpecialPopup() called");
    if (m_popupService)
        m_popupService->requestShowSpecialPopup(clientSessionID, eSpecialPopupType, popupContext, priority);
    else
        LOGI().writeFormatted("SxmPopupServiceInterface::requestShowPopup() called failed");
}
