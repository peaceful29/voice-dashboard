#ifndef SXMKEYBOARDINTERFACE_H
#define SXMKEYBOARDINTERFACE_H

#include "keyboardservice/KeyboardMsgDef.h"
#include "Utils.h"
#include "SxmAbstractInterface.h"
#include "DataExchange/SXMKeyPadHandler.h"

class SxmKeyboardService;

class SxmKeyboardInterface: public SxmAbstractInterface
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SxmKeyboardInterface(QObject *parent = nullptr);
    virtual ~SxmKeyboardInterface();

    IBaseListener *ilistener();
    void initialize(OnBaseListener* engine = nullptr);
    void registerListener(OnBaseListener* engine);

signals:

public slots:
    void onEventRequestShowKeyboard(const uint32_t& clientSessionID, const E_KEYBOARD_TYPE& eKeyboardType, const char* preFilledText, const char* defaultText, const uint32_t& maxLength);
    void onEventRequestHideKeyboard(const uint32_t& clientSessionID);
//    void onEventResponseCandidateInfo(const uint32_t& clientSessionID, const uint32_t& userInputID, const uint32_t& candidateSessionID, const uint32_t& suggestionCount, const char* userInputText, const char* suggestionResultContext);
    void onEventResponseCandidateInfo(const uint32_t &clientSessionID, const uint32_t &userInputID, const char *userInputText);
//    void onEventResponseCandidateList(const uint32_t& clientSessionID, const uint32_t& candidateSessionID, const char* userInputText, const uint32_t& startIndex, const uint32_t& endIndex);
    void onEventResponseCandidateList(const uint32_t &clientSessionID, const uint32_t &candidateSessionID, const char *userInputText, const uint32_t &startIndex, const uint32_t &endIndex);



private:
    SxmKeyboardService* m_keyboardService;
   QList<SUGGESTIONS> m_lstSuggestion;
};

#endif // SXMKEYBOARDINTERFACE_H
