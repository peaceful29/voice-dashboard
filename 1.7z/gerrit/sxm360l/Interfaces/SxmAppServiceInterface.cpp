#include <QQuickView>
#include <QJsonObject>
#include <QJsonDocument>
#include "base/interface/OnBaseListener.h"
#include "base/interface/IBaseListener.h"
#include "hmi/AppRoleDef.h"
//#include "hmi/AppNameDef.h"
//#include "hmi/WindowNameDef.h"
#include "Services/SxmAppService.h"
#include "Services/AudioService.h"
#include "sxm360l/Sxm360lMsgDef.h"
#include "DataController.h"
#include "UIBridge.h"

#include "SxmAppServiceInterface.h"
#include "Common/Utils.h"

SxmAppServiceInterface::SxmAppServiceInterface(QObject* parent)
    : SxmAbstractInterface(parent)
    , m_firstBlood(true)
{
    LOGI().writeFormatted("SxmAppServiceInterface::SxmAppServiceInterface() called");
    m_appService = new SxmAppService(this);
    m_audioService = new AudioService(this);
}

SxmAppServiceInterface::~SxmAppServiceInterface()
{
    SafeDelete<SxmAppService>(m_appService);
    SafeDelete<AudioService>(m_audioService);
}

IBaseListener *SxmAppServiceInterface::ilistener()
{
    return m_appService;
}

void SxmAppServiceInterface::initialize(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmAppServiceInterface::initialize() called");
    m_appService->initialize(engine);
    m_audioService->initialize(engine);
}

void SxmAppServiceInterface::registerListener(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmAppServiceInterface::registerListener() called");
    engine->registerListener(m_appService);
    engine->registerListener(m_audioService);
}

void SxmAppServiceInterface::registerWindowTarget(QQuickView *_windowTarget)
{
    LOGI().writeFormatted("SxmAppServiceInterface::registerWindowTarget() called");
    m_windowTargets.append(_windowTarget);
}

void SxmAppServiceInterface::registerApplication()
{
    if (m_appService != nullptr){
        m_appService->registerApplication();
    }
}

void SxmAppServiceInterface::goBack()
{
    LOGI().writeFormatted("SxmAppServiceInterface::goBack() called");
    if (m_appService) {
        m_appService->requestToGoBack();
    }
}

void SxmAppServiceInterface::showApplication(QString strAppRole, QString strIntent)
{
    LOGI().writeFormatted("SxmAppServiceInterface::showApplication()");
    if (m_audioService != nullptr){
        m_audioService->requestCmdPlay();
    }
    emit cmdShowApplication(strAppRole, strIntent);
}

void SxmAppServiceInterface::cmdShowAppWindow(QString strAppRole, QString strIntent)
{
    LOGI().writeFormatted("SxmAppServiceInterface::foregroundApplication()");
    if (m_audioService != nullptr){
        m_audioService->requestCmdPlay();
    }
    emit eventCmdShowAppWindow(strAppRole, strIntent);
}

void SxmAppServiceInterface::responseScfaScreenShow(const int &requestID, const E_REQ_RESULT_MSG &eResult)
{
    emit eventResponseScfaScreenShow(requestID, static_cast<int>(eResult));
}

void SxmAppServiceInterface::onEventRequestToShowSystemComponent(const int &requestId, const E_SYSTEM_COMPONENT &eSystemComponent, const char *strData)
{
    LOGI().writeFormatted("SxmAppServiceInterface::onEventRequestToShowSystemComponent() called requestId %d, systemComponent %d, data %s",
                          requestId, eSystemComponent, strData);
    if (m_appService) {
        m_appService->requestToShowSystemComponent(requestId, eSystemComponent, strData);
    }
}

void SxmAppServiceInterface::onEventRequestToHideSystemComponent(const int &requestId, const E_SYSTEM_COMPONENT &eSystemComponent, const char *strData)
{
    LOGI().writeFormatted("SxmAppServiceInterface::onEventRequestToHideSystemComponent() called requestId %d, systemComponent %d, data %s",
                          requestId, eSystemComponent, strData);
    if (m_appService) {
        m_appService->requestToHideSystemComponent(requestId, eSystemComponent, strData);
    }
}

void SxmAppServiceInterface::onEventRequestToGoApplication(const int &requestID, const char *strAppBinaryName, const char *strAppRole, const char *strIntent, const E_SHOW_OPT &eShowOpt)
{
    LOGI().writeFormatted("SxmAppServiceInterface::onEventRequestToGoApplication() "
                          "called requestId %d, strAppBinaryName %d, strAppRole %s strIntent %s eShowOpt %d",
                          requestID, strAppBinaryName, strAppRole, strIntent, eShowOpt);
    if (m_appService) {
        m_appService->requestToGoApplication(requestID, strAppBinaryName, strAppRole, strIntent, eShowOpt);
    }
}

void SxmAppServiceInterface::onEventRequestSpeechModeLaunchingBaseFeature()
{
    if (m_appService != nullptr){
        m_appService->requestSpeechModeLaunchingBaseFeature();
    }
}

void SxmAppServiceInterface::onEventRequestSpeechModeVoicetagFavorite(const uint32_t &number)
{
    FAVORITE_T  channelInform;
    int         dwGetInfor = 0;
    QString     intent;
    QJsonObject jsonData;

    dwGetInfor = DataController::instance()->getFavoriteInformation(channelInform, number);
    if (dwGetInfor == -1) {
        // cann't get favorite channel information
        LOGE().writeFormatted("[SxmAppServiceInterface::onEventRequestSpeechModeVoicetagFavorite]Can't get favorite information channel(%d)", number);
        return;
    }
    requestVoiceChannelInfo(channelInform.channelInfo, QString("SXM_favorites"));
}

void SxmAppServiceInterface::onEventRequestSpeechModeVoicetagChannel(QString &number)
{
    CHANNEL_INFORMATION_T channelInfo;
    int dwGetInfor = DataController::instance()->getChannelInformation(channelInfo, number.toUInt());
    if (dwGetInfor == -1) {
        // cann't get channel information
        LOGE().writeFormatted("[SxmAppServiceInterface::onEventRequestSpeechModeVoicetagChannel]Can't get channel information channel(%d)", number);
        return;
    }
    requestVoiceChannelInfo(channelInfo, QString("SXM_channel"));
}

void SxmAppServiceInterface::onEventRequestSpeechModeVoicetagChannelInput(QString &number)
{
    CHANNEL_INFORMATION_T channelInfo;
    int dwGetInfor = DataController::instance()->getChannelInformation(channelInfo, number.toUInt());
    if (dwGetInfor == -1) {
        // cann't get channel information
        LOGE().writeFormatted("[SxmAppServiceInterface::onEventRequestSpeechModeVoicetagChannelInput]Can't get channel information channel(%d)", number);
        return;
    }
    requestVoiceChannelInfo(channelInfo, QString("SXM_channel_Input"));
}

void SxmAppServiceInterface::requestVoiceChannelInfo(CHANNEL_INFORMATION_T &channelInfo, QString menu)
{
    QString     intent;
    QJsonObject jsonData;

    jsonData.insert("source", QJsonValue::fromVariant(HMI_APP_NAME_SXM360L));
    jsonData.insert("menu", menu.toStdString().c_str());
    jsonData.insert("band","");
    jsonData.insert("frequency", "");
    jsonData.insert("PI", "");
    jsonData.insert("sid", QJsonValue::fromVariant(channelInfo.sid));
    jsonData.insert("channel", QJsonValue::fromVariant(channelInfo.number));
    jsonData.insert("name", QJsonValue::fromVariant(channelInfo.name));
    jsonData.insert("imageType", QJsonValue::fromVariant("url"));
    jsonData.insert("imageSource", QJsonValue::fromVariant(channelInfo.logoUrl));

    QJsonDocument doc(jsonData);
    intent = doc.toJson(QJsonDocument::Compact);

    // request goto app
    int     requestId = E_HMI_APP_ID_RADIO_SXM360L;
    QString strAppBinaryName = HMI_APP_NAME_SPEECH;
    QString strAppRole = HMI_ROLE_SPEECH;

    m_appService->requestToGoApplication(requestId,
                                         strAppBinaryName.toStdString().c_str(),
                                         strAppRole.toStdString().c_str(),
                                         intent.toStdString().c_str(),
                                         E_SHOW_OPT_ADD
                                         );
}

void SxmAppServiceInterface::onCmdCreateAppWindow()
{

    emit cmdCreateAppWindow();
}

void SxmAppServiceInterface::onCmdDestroyAppWindow()
{
    emit cmdDestroyAppWindow();
}
