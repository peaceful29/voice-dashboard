#include "base/interface/IBaseListener.h"
#include "base/interface/OnBaseListener.h"
#include "SxmServiceInterface.h"
#include "Services/SxmService.h"

SxmServiceInterface::SxmServiceInterface(QObject *parent)
    : SxmAbstractInterface(parent)
{
    LOGI().writeFormatted("SxmServiceInterface::SxmServiceInterface() called");
    m_sxmService = new SxmService(this);
}

SxmServiceInterface::~SxmServiceInterface()
{
    SafeDelete<SxmService>(m_sxmService);
}

IBaseListener *SxmServiceInterface::ilistener()
{
    LOGI().writeFormatted("SxmServiceInterface::ilistener() called");
    return m_sxmService;
}

void SxmServiceInterface::initialize(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmServiceInterface::initialize() called");
    m_sxmService->initialize(engine);
}

void SxmServiceInterface::registerListener(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmServiceInterface::registerListener() called");
    engine->registerListener(m_sxmService);
}

void SxmServiceInterface::onEventSatSubscriptionState(const int state)
{
    emit eventSatSubscriptionState(state);
}

void SxmServiceInterface::onEventSATDiagnostics()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventSATDiagnostics() called");
    m_sxmService->requestSATDiagnostics();
}

void SxmServiceInterface::onEventRequestInitSet(const int &id, const bool &bFlag, const char *msg)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestInitSet() called");
    m_sxmService->requestInitSet(id, bFlag, msg);
}

void SxmServiceInterface::onEventRequestInitState()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestInitState() called");
    m_sxmService->requestInitState();
}


void SxmServiceInterface::onEventRequestSuperCategories()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestSuperCategories() called");
    m_sxmService->requestSuperCategories();
}

void SxmServiceInterface::onEventRequestAllCategories()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestAllCategories() called");
    m_sxmService->requestAllCategories();
}

void SxmServiceInterface::onEventRequestCategories(const char *superCategory)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestCategories() called");
    m_sxmService->requestCategories(superCategory);
}

void SxmServiceInterface::onEventRequestChannels(const char *category)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestChannels() called");
    m_sxmService->requestChannels(category);
}

void SxmServiceInterface::onEventRequestChannels()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestChannels() called");
    m_sxmService->requestChannels();
}

void SxmServiceInterface::onEventRequestChannelInformation(const uint32_t channelNumber)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestChannelInformation() called");
    m_sxmService->requestChannelInformation(channelNumber);
}

void SxmServiceInterface::onEventRequestFavorites()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestFavorites() called");
    m_sxmService->requestFavorites();
}

void SxmServiceInterface::onEventRequestAddFavorite(const uint32_t channelNumber)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestAddFavorite() called");
    m_sxmService->requestAddFavorite(channelNumber);
}

void SxmServiceInterface::onEventRequestRemoveFavorite(const uint32_t channelNumber)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestRemoveFavorite() called");
    m_sxmService->requestRemoveFavorite(channelNumber);
}

void SxmServiceInterface::onEventRequestTuneFavorite(const uint32_t channelNumber)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestTuneFavorite() called");
    m_sxmService->requestTuneFavorite(channelNumber);
}

void SxmServiceInterface::onEventRequestSmartFavorites()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestSmartFavorites() called");
    m_sxmService->requestSmartFavorites();
}

void SxmServiceInterface::onEventRequestMoveFavorite(const uint32_t index, const uint32_t new_index)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestMoveFavorite() called");
    m_sxmService->requestMoveFavorite(index, new_index);
}

void SxmServiceInterface::onEventRequestPlayback(const PLAY_STATE state)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestPlayback() called");
    m_sxmService->requestPlayback(state);
}

void SxmServiceInterface::onEventRequestTune(const uint32_t channelNumber)
{
    LOGI().writeFormatted("SxmServiceInterface::SxmServiceInterface() called");
    m_sxmService->requestTuneChannel(channelNumber);
}

void SxmServiceInterface::onEventRequestTuneLastChannel()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestTuneLastChannel() called");
    m_sxmService->requestTuneLastChannel();
}

//void SxmServiceInterface::onEventRequestTune(const uint32_t channelNumber)
//{
//    LOGI().writeFormatted("SxmServiceInterface::onEventRequestTune() called");
//    m_sxmService->requestTuneChannel(channelNumber);
//}

void SxmServiceInterface::onEventRequestSeekChannel(const SEEK_ACTION action)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestSeekChannel() called");
    m_sxmService->requestSeekChannel(action);
}

void SxmServiceInterface::onEventRequestSongAlerts()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestSongAlerts() called");
    m_sxmService->requestSongAlerts();
}

void SxmServiceInterface::onEventRequestArtistAlerts()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestArtistAlerts() called");
    m_sxmService->requestArtistAlerts();
}

void SxmServiceInterface::onEventRequestArtistAndSongAlerts()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestArtistAndSongAlerts() called");
    m_sxmService->requestArtistAndSongAlerts();
}

void SxmServiceInterface::onEventRequestAddSongAlert(const char* songTitle)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestAddSongAlert() called");
    m_sxmService->requestAddSongAlert(songTitle);
}

void SxmServiceInterface::onEventRequestAddArtistAlert(const char* artistName)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestAddArtistAlert() called");
    m_sxmService->requestAddArtistAlert(artistName);
}

void SxmServiceInterface::onEventRequestRemoveSongAlert(const char *songTitle)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestRemoveSongAlert() called");
    m_sxmService->requestRemoveSongAlert(songTitle);
}

void SxmServiceInterface::onEventRequestRemoveArtistAlert(const char *artistName)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestRemoveArtistAlert() called");
    m_sxmService->requestRemoveArtistAlert(artistName);
}

void SxmServiceInterface::onEventRequestRewind(const uint32_t step)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestRewind() called");
    m_sxmService->requestRewind(step);
}

void SxmServiceInterface::onEventRequestFastForward(const uint32_t step)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestFastForward() called");
    m_sxmService->requestFastForward(step);
}

void SxmServiceInterface::onEventRequestJumpPoint(const uint32_t point)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestJumpPoint() called");
    m_sxmService->requestJumpPoint(point);
}

void SxmServiceInterface::onEventRequestRecommendation()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestRecommendation() called");
    m_sxmService->requestRecommendation();
}

void SxmServiceInterface::onEventRequestListeningHistory()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestListeningHistory() called");
    m_sxmService->requestListeningHistory();
}

void SxmServiceInterface::onEventRequestLastChannelInfo()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestLastChannelInfo() called");
    m_sxmService->requestLastChannelInfo();
}

void SxmServiceInterface::onEventRequestGetChannelList(int count)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestGetChannelList() called");
    m_sxmService->requestGetChannelList(count);
}

void SxmServiceInterface::onEventTestLossSignal()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventTestLossSignal() called");
    m_sxmService->requestTestLossSignal();
}

void SxmServiceInterface::onEventRequestResumingSatelliteOnCompleted()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestResumingSatelliteOnCompleted() called");
    m_sxmService->requestResumingSatelliteOnCompleted();
}

void SxmServiceInterface::onEventRequestGetActiveProfiles()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestGetActiveProfiles() called");
    m_sxmService->requestGetActiveProfiles();
}

void SxmServiceInterface::onEventRequestCreateProfile(const char *name)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestCreateProfile() called");
    m_sxmService->requestCreateProfile(name);
}

void SxmServiceInterface::onEventRequestSetDefaultProfile()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestSetDefaultProfile() called");
    m_sxmService->requestSetDefaultProfile();
}

void SxmServiceInterface::onEventRequestSwitchProfile(const char *name)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventequestSwitchProfile() called");
    m_sxmService->requestSwitchProfile(name);
}

void SxmServiceInterface::onEventRequestDeleteProfile()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventequestDeleteProfile() called");
    m_sxmService->requestDeleteProfile();
}

void SxmServiceInterface::onEventRequestModifyProfileName(const char *name)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventequestModifyProfileName() called");
    m_sxmService->requestModifyProfileName(name);
}

//make color
void SxmServiceInterface::onEventRequestRelatedList()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventequestModifyProfileName() called");
    m_sxmService->requestRelatedList();
}
//make color

void SxmServiceInterface::onEventRequestModifyProfileAvatar(const char *logoUrl)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventequestModifyProfileAvatar() called");
    m_sxmService->requestModifyProfileAvatar(logoUrl);
}

void SxmServiceInterface::onEventRequestGetSettingNotification()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventrequestGetSettingNotification() called");
    m_sxmService->requestGetSettingNotification();
}

void SxmServiceInterface::onEventRequestSetSettingNotification(const SETTING_NOTIFICATION_STATE state)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventrequestSetSettingNotification() called");
    m_sxmService->requestSetSettingNotification(state);
}

void SxmServiceInterface::onEventRequestAddFavoriteTeam(const SPORTS_TEAM_TYPE type)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestAddFavoriteTeam() called");
    m_sxmService->requestAddFavoriteTeam(type);
}

void SxmServiceInterface::onEventRequestRemoveFavoriteTeam(const int teamId)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestRemoveFavoriteTeam() called");
    m_sxmService->requestRemoveFavoriteTeam(teamId);
}

void SxmServiceInterface::onEventRequestGetTeams(const int leagueId)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestGetTeams() called");
    m_sxmService->requestGetTeams(leagueId);
}

void SxmServiceInterface::onEventRequestGetLeagues()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestGetLeagues() called");
    m_sxmService->requestGetLeagues();
}

void SxmServiceInterface::onEventRequestAddTeamAlerts(const int teamId)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestAddTeamAlerts() called");
    m_sxmService->requestAddTeamAlerts(teamId);
}

void SxmServiceInterface::onEventRequestRemoveTeamAlerts(const int teamId)
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestRemoveTeamAlerts() called");
    m_sxmService->requestRemoveTeamAlerts(teamId);
}

void SxmServiceInterface::onEventRequestGetTeamAlerts()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestGetTeamAlerts() called");
    m_sxmService->requestGetTeamAlerts();
}

void SxmServiceInterface::onEventRequestGetFavoriteTeams()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestGetFavoriteTeams() called");
    m_sxmService->requestGetFavoriteTeams();
}

void SxmServiceInterface::onEventRequestSatSubscriptionState()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestSatSubscriptionState() called");
    m_sxmService->requestSatSubscriptionState();
}

void SxmServiceInterface::onEventRequestGetAntennaState()
{
    LOGI().writeFormatted("SxmServiceInterface::onEventRequestGetAntennaState() called");
    m_sxmService->requestGetAntennaState();
}

//void SxmServiceInterface::onEventRequestGetLiveSports()
//{
//    LOGI().writeFormatted("SxmServiceInterface::onEventRequestGetLiveSports() called");
//    m_sxmService->requestGetLiveSports();
//}

//void SxmServiceInterface::onEventRequestTuneLiveSports(const int leagueId)
//{
//    LOGI().writeFormatted("SxmServiceInterface::onEventRequestTuneLiveSports() called");
//    m_sxmService->requestTuneLiveSports(leagueId);
//}
