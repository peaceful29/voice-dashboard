#ifndef SXMPOPUPSERVICEINTERFACE_H
#define SXMPOPUPSERVICEINTERFACE_H

#include "popupservice/PopupMsgDef.h"
#include "Utils.h"
#include "SxmAbstractInterface.h"

class SxmPopupService;

class SxmPopupServiceInterface : public SxmAbstractInterface
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
public:
    SxmPopupServiceInterface(QObject *parent = nullptr);
    virtual ~SxmPopupServiceInterface();

    IBaseListener *ilistener();
    void initialize(OnBaseListener* engine = nullptr);
    void registerListener(OnBaseListener* engine);

signals:

public slots:
    void onEventRequestShowPopup(const uint32_t& clientSessionID, const E_POPUP_TYPE& ePopupType, const E_POPUP_SIDE_TYPE& ePopupSideType, const E_POPUP_SIZE& ePopupSize, const char* popupContext, const uint32_t& priority);
    void onEventRequestHidePopup(const uint32_t& clientSessionID, const uint32_t& handle);
    void onEventRequestUpdatePopup(const uint32_t& clientSessionID, const uint32_t& handle, const char* popupContext);
    void onEventRequestShowSpecialPopup(const uint32_t& clientSessionID, const E_SPECIAL_POPUP_TYPE& eSpecialPopupType, const char* popupContext, const uint32_t& priority);

private:
    SxmPopupService* m_popupService;
};

#endif // SXMPOPUPSERVICEINTERFACE_H
