#include "SxmKeyboardInterface.h"
#include "base/interface/OnBaseListener.h"
#include "base/interface/IBaseListener.h"
#include "SxmKeyboardService.h"
#include "keyboardservice/KeyboardJsonContextHandler.h"

SxmKeyboardInterface::SxmKeyboardInterface(QObject *parent)
{
    LOGI().writeFormatted("SxmKeyboardInterface::SxmKeyboardInterface() called");
    m_keyboardService = new SxmKeyboardService(this);
}

SxmKeyboardInterface::~SxmKeyboardInterface()
{
    SafeDelete<SxmKeyboardService>(m_keyboardService);
}

IBaseListener *SxmKeyboardInterface::ilistener()
{
    return m_keyboardService;
}

void SxmKeyboardInterface::initialize(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmKeyboardInterface::SxmKeyboardInterface() called");
    m_keyboardService->initialize(engine);
}

void SxmKeyboardInterface::registerListener(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmKeyboardInterface::registerListener() called");
    engine->registerListener(m_keyboardService);
}

void SxmKeyboardInterface::onEventRequestShowKeyboard(const uint32_t &clientSessionID, const E_KEYBOARD_TYPE &eKeyboardType, const char *preFilledText, const char *defaultText, const uint32_t &maxLength)
{
    LOGI().writeFormatted("SxmKeyboardInterface::onEventRequestShowKeyboard() called");
    if (m_keyboardService)
        m_keyboardService->requestShowKeyboard(clientSessionID, eKeyboardType, "", "", maxLength);
}

void SxmKeyboardInterface::onEventRequestHideKeyboard(const uint32_t &clientSessionID)
{
    LOGI().writeFormatted("SxmKeyboardInterface::onEventRequestHideKeyboard() called");
    if (m_keyboardService)
        m_keyboardService->requestHideKeyboard(clientSessionID);
}

//void SxmKeyboardInterface::onEventResponseCandidateInfo(const uint32_t &clientSessionID, const uint32_t &userInputID, const uint32_t &candidateSessionID, const uint32_t &suggestionCount, const char *userInputText, const char *suggestionResultContext)
void SxmKeyboardInterface::onEventResponseCandidateInfo(const uint32_t &clientSessionID, const uint32_t &userInputID, const char *userInputText)
{
    LOGI().writeFormatted("SxmKeyboardInterface::onEventResponseCandidateInfo() called");
    const uint32_t candidateSessionID = 1;
    KeyboardJsonContextHandler handler;
    handler.startJSONContext();
    handler.addJSONKeyboardCandidateDataType(E_KEYBOARD_CANDIDATE_DATA_TYPE_ICON_TEXT);
    handler.startJSONKeyboardArrayForamt();
    m_lstSuggestion.clear();
    m_lstSuggestion = SXMKeyPadHandler::instance()->getLstSuggestion(QString(userInputText));

    if (m_lstSuggestion.count() != 0){
        handler.addJSONKeyboardCandidateData(m_lstSuggestion[0].strLogo.toStdString().c_str(),
                                             m_lstSuggestion[0].strName.toStdString().c_str());
//        handler.addJSONKeyboardCandidateData("/opt/bin/res/Landrover/Luxury/png/general/day/icon_side_search.svg",
//                                             m_lstSuggestion[0].toStdString().c_str());
    }

    handler.endJSONKeyboardArrayForamt();
    handler.finishJSONContext();
    const uint32_t suggestionCount = m_lstSuggestion.count();
    const char* suggestionResultContext = handler.getKeyboardContext();

    if (m_keyboardService)
        m_keyboardService->responseCandidateInfo(clientSessionID, userInputID, candidateSessionID, suggestionCount, userInputText, suggestionResultContext);
}

void SxmKeyboardInterface::onEventResponseCandidateList(const uint32_t &clientSessionID, const uint32_t &candidateSessionID, const char *userInputText, const uint32_t &startIndex, const uint32_t &endIndex)
{
    LOGI().writeFormatted("SxmKeyboardInterface::onEventResponseCandidateList() called");
    KeyboardJsonContextHandler handler;
    handler.startJSONContext();
    handler.addJSONKeyboardCandidateDataType(E_KEYBOARD_CANDIDATE_DATA_TYPE_ICON_TEXT);
    handler.startJSONKeyboardArrayForamt();

    //Check start index and stop index is valid
    bool isIndexValid = (startIndex <= endIndex) ? true : false;
    isIndexValid = isIndexValid && ((endIndex < m_lstSuggestion.count()) ? true : false);
    if (isIndexValid == true){
        LOGI().writeFormatted("[SxmKeyboardInterface::onEventResponseCandidateList]Index[%d][%d][%d]", startIndex, endIndex, m_lstSuggestion.count());
        for (int i = startIndex; i <= endIndex; ++i) {
            handler.addJSONKeyboardCandidateData(m_lstSuggestion[i].strLogo.toStdString().c_str(),
                                m_lstSuggestion[i].strName.toStdString().c_str());
        }
    }
    handler.endJSONKeyboardArrayForamt();
    handler.finishJSONContext();
    const char* suggestionResultContext = handler.getKeyboardContext();
    if (m_keyboardService)
        m_keyboardService->responseCandidateList(clientSessionID, candidateSessionID, userInputText, startIndex, endIndex, suggestionResultContext);
}
