#include "ScreenList.h"
#include "ScreenIdentifier.h"
#include <QDebug>

ScreenList* ScreenList::m_screenListInstance = NULL;
ScreenList::ScreenList()
{
    m_screenIndentifier = new ScreenIdentifier();
    createScreenMapping();
    m_currentScreenID = m_previousScreenID = 0;
}

void ScreenList::createScreenMapping()
{
    //Mapping between screen path and screen ID
    //Player Screen
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER, "qrc:/resources/qmls/pages/SXM/SXMPlayerProgressBar.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER, "qrc:/resources/qmls/pages/SXM/Player/SXMPlayerTextInfo.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER,"qrc:/resources/qmls/pages/SXM/Player/SXMPlayerLiveSports.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER_TUNING, "qrc:/resources/qmls/pages/SXM/Player/SXMPlayerTuning.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER_AUDIO_TIMEOUT, "qrc:/resources/qmls/pages/SXM/Player/PlayerAudioTimeout.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER_RESUMING_SATELLITE, "qrc:/resources/qmls/pages/SXM/Player/PlayerResumingSatelliteBroadcastChannel.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER_RELATED_CONTENT, "qrc:/resources/qmls/pages/SXM/Player/SXMPlayerRelatedContentScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER_AVAILABLE_SHOWS, "qrc:/resources/qmls/pages/SXM/BlankPage.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_LINER_TUNER, "qrc:/resources/qmls/pages/SXM/Player/SXMLinerTunerScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER_DIRECT_TUNE, "qrc:/resources/qmls/pages/SXM/Player/SXMKeyPadScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_CHECK_ANTENNA, "qrc:/resources/qmls/pages/SXM/Player/CheckAntenna.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SATELLITE_SIGNAL_LOST, "qrc:/resources/qmls/pages/SXM/Player/SatSignalLoss.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SATELLITE_SIGNAL_RECONNECT, "qrc:/resources/qmls/pages/SXM/Player/SatSignalLossSwitch.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_IP_SIGNAL_LOST, "qrc:/resources/qmls/pages/SXM/Player/IpSignalLoss.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_IP_SIGNAL_RECONNECT, "qrc:/resources/qmls/pages/SXM/Player/IpSignalLossSwitch.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPORTS_PLAY_SIGNAL_LOST, "qrc:/resources/qmls/pages/SXM/Player/SportsPlaySignalLoss.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPORTS_PLAY_RECONNECT, "qrc:/resources/qmls/pages/SXM/Player/SportsPlaySignalLossSwitch.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_ON_DEMAND_SIGNAL_LOST, "qrc:/resources/qmls/pages/SXM/Player/DemandEpisodeSignalLoss.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_ON_DEMAND_SIGNAL_RECONNECT, "");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER_LIVE_CHANNEL, "qrc:/resources/qmls/pages/analog/AnalogStationsCategory.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER_ON_DEMANDED, "qrc:/resources/qmls/pages/SXM/BlankPage.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER_LIVE_SPORTS, "qrc:/resources/qmls/pages/analog/AnalogStationAll.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER, "qrc:/resources/qmls/pages/SXM/SXMPlayerProgressBar.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_PLAYER_PLAY_BY_PLAY,"qrc:/resources/qmls/pages/SXM/Player/SXMPlayerPlayByPlay.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPORTS_PLAY_BY_PLAY_SCHEDULED,"qrc:/resources/qmls/pages/SXM/Player/SXMSportsPByPSchedule.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPORTS_PLAY_BY_PLAY_RESCHEDULED,"qrc:/resources/qmls/pages/SXM/Player/SXMSportsPByPRescheduled.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPORTS_NOUPCOMING,"qrc:/resources/qmls/pages/SXM/Player/SXMSportsPByPNoUpComing.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPORTS_POST_GAME,"qrc:/resources/qmls/pages/SXM/Player/SXMSportsPostGame.qml");


    //Favorite Screen
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_FAVORITES, "qrc:/resources/qmls/pages/SXM/Favorites/SXMFavoriteShortBox.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_FAVORITES, "qrc:/resources/qmls/pages/SXM/Favorites/FavoriteListViewScreen.qml");
    //Browse Screen
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BROWSE_CATEGORIES, "qrc:/resources/qmls/pages/SXM/Browse/SXMBrowserCategoryScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BROWSE_SUPER_CATEGORIES, "qrc:/resources/qmls/pages/SXM/Browse/SXMBrowserCategoryScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BROWSE_SPORTS_PLAY_BY_PLAY, "qrc:/resources/qmls/pages/SXM/Browse/SXMBrowseSportPlayByPlayScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BROWSE_LIVE_CHANNEL, "qrc:/resources/qmls/pages/SXM/Browse/SXMBrowserLiveChannelScreen.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BROWSE, "qrc:/resources/qmls/pages/analog/AnalogFavourites.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BROWSE_MUSIC, "qrc:/resources/qmls/pages/analog/AnalogStationsCategoryItems.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BROWSE_SPORTS, "qrc:/resources/qmls/pages/analog/AnalogStationsCategoryItems.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BROWSE_NEWS, "qrc:/resources/qmls/pages/analog/AnalogPlayerSeek.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BROWSE_TALK, "qrc:/resources/qmls/pages/analog/AnalogPlayerSeek.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BROWSE_ON_DEMAND_SERIES, "qrc:/resources/qmls/pages/dab/DabPlayer.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SEARCH, "qrc:/resources/qmls/pages/dab/DabFavourites.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_TERMS_CONFIRM_PURCHASE, "qrc:/resources/qmls/pages/dab/DabCategories.qml");
//    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_TERMS_DETAIL_CHARGES, "qrc:/resources/qmls/pages/dab/DabStationAll.qml");
    //ForYou Screens
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_RECOMMENDATION,"qrc:/resources/qmls/pages/SXM/ForYou/SXMForYouRecommendationsScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_RECENT_HISTORY, "qrc:/resources/qmls/pages/SXM/ForYou/SXMForYouHistoryListenScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_FIRST_TIME, "qrc:/resources/qmls/pages/SXM/ForYou/SXMForYouFirstTimeScreen.qml");

    //Searching Screen
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SEARCH_LISTENING, "qrc:/resources/qmls/pages/SXM/Search/SearchListeningScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SEARCH, "qrc:/resources/qmls/pages/SXM/Search/SearchScreen.qml");


    //Setting Screens
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_ADD_ARTIST_SONG, "qrc:/resources/qmls/pages/SXM/Popup/SXMAddArtistSongNotification.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_ADD_ARTIST, "qrc:/resources/qmls/pages/SXM/Popup/SXMAddArtistNotification.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_ADD_SONG, "qrc:/resources/qmls/pages/SXM/Popup/SXMAddSongNotification.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_CANNOT_ADD_NOTIFICATION, "qrc:/resources/qmls/pages/SXM/Popup/SXMCannotSetNotification.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_MAXIMUM_ADD_NOTIFICATION, "qrc:/resources/qmls/pages/SXM/Popup/SXMSetMaximumNotification.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SETTINGS_SELECT_LISTENER_PROFILE, "qrc:/resources/qmls/pages/SXM/SXMSettingAddListener.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SETTINGS_ARTIST_SONG_NOTIFICATIONS, "qrc:/resources/qmls/pages/SXM/Popup/SXMArtistSongNotifications.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_BLANK,"qrc:/resources/qmls/pages/SXM/BlankPage.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SETTINGS_ADD_TEAM_NOTIFICATIONS, "qrc:/resources/qmls/pages/SXM/Popup/SXMAddTeamNotification.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SETTINGS_MANAGE_TEAM_NOTIFICATIONS, "qrc:/resources/qmls/pages/SXM/Popup/SXMManageTeamNotificationsScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SETTINGS_CHOOSE_LEAGUE, "qrc:/resources/qmls/pages/SXM/Popup/SXMChooseLeagueScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SETTINGS_CHOOSE_TEAM, "qrc:/resources/qmls/pages/SXM/Popup/SXMChooseTeamScreen.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SETTINGS_TEAM_FAVORITE, "qrc:/resources/qmls/pages/SXM/Popup/SXMAddFavouriteTeam.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_FIRST_EXPERIENCE, "qrc:/resources/qmls/pages/SXM/Popup/SXMFirstExperience.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_UP_SELL, "qrc:/resources/qmls/pages/SXM/Popup/SXMUpSellFeatureOverlayPopup.qml");

    //Speech Screen
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_LIST_SAT, "qrc:/resources/qmls/pages/SXM/Speech/VideoTunerStationList.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPEECH_MODE_CHANNELLIST, "qrc:/resources/qmls/pages/SXM/Speech/VideoTunerChannelList.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_SAT_LIST, "qrc:/resources/qmls/pages/SXM/Speech/VideoTunerCategorySatList.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_SAT, "qrc:/resources/qmls/pages/SXM/Speech/VideoTunerCategorySat.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_STATION_SAT, "qrc:/resources/qmls/pages/SXM/Speech/VideoTunerCategorySat.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_STATION_LIST_SAT, "qrc:/resources/qmls/pages/SXM/Speech/VideoTunerCategoryStationListSat.qml");
    m_mapScreenPathId.insert(m_screenIndentifier->E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_SDARS_TEAM, "qrc:/resources/qmls/pages/SXM/Speech/VideoTunerSdarsTeam.qml");
}

QString ScreenList::getScreenPathbyId(uint32_t screenId)
{
    return m_mapScreenPathId.value(screenId, "");
}

uint32_t ScreenList::getScreenIdbyPath(QString screenPath)
{
    return m_mapScreenPathId.key(screenPath, 0);
}

ScreenList *ScreenList::getInstance()
{
    if (!m_screenListInstance) {
        m_screenListInstance = new ScreenList();
    }
    return m_screenListInstance;
}

void ScreenList::setCurrentScreenID(const uint32_t id)
{
    m_currentScreenID = id;
}

void ScreenList::setPreviousScreenID(const uint32_t id)
{
    m_previousScreenID = id;
}

void ScreenList::setScreenID(const uint32_t previous, const uint32_t current)
{
    m_currentScreenID = current;
    m_previousScreenID = previous;
}

uint32_t ScreenList::getCurrentScreenID() const
{
    return m_currentScreenID;
}

uint32_t ScreenList::getPreviousScreenID() const
{
    return m_previousScreenID;
}

bool ScreenList::isCurrentScreen(const uint32_t id) const
{
    bool ret = false;
    if (id == m_currentScreenID){
        ret = true;
    }
    return ret;
}

bool ScreenList::isPreviousScreen(const uint32_t id) const
{
    bool ret = false;
    if (id == m_previousScreenID){
        ret = true;
    }
    return ret;
}
