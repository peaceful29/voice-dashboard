#include "RecommendedListModel.h"
#include "Common/SXMDefine.h"
#include "RecommendedElement.h"

RecommendedListModel::RecommendedListModel(QObject *parent)
    : BaseListModel(parent)
{
}

RecommendedListModel::~RecommendedListModel()
{

}

QVariant RecommendedListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    RecommendedElementPtr element = std::dynamic_pointer_cast<RecommendedElement>(m_elements[index.row()]);
    switch (role) {
    case E_RECOMMENDED_MEDIUM_TITLE:
        return element->mediumTitle();
    case E_RECOMMENDED_LONG_TITLE:
        return element->longTitle();
    case E_RECOMMENDED_SHORT_DESCRIPTION:
        return element->shortDes();
    case E_RECOMMENDED_SHOW_GUID:
        return element->showGui();
    case E_RECOMMENDED_PROGRAM_TYPE:
        return element->programType();
    case E_RECOMMENDED_AUDIO_EPISODE_COUNT:
        return element->audioEpisode();
    case E_RECOMMENDED_VIDEO_EPISODE_COUNT:
        return element->videoEpisode();
    case E_RECOMMENDED_NEW_EPISODE_COUNT:
        return element->newEpisodeCount();
    case E_RECOMMENDED_EPISODE_COUNT:
        return element->episodeCount();
    case E_RECOMMENDED_CONTEXTUAL:
        return element->contextual();
    case E_RECOMMENDED_IS_MATURE:
        return element->isMature();
    case E_RECOMMENDED_CATEGORY:
        return element->category();
    case E_RECOMMENDED_LOGO:
        return element->logo();
    case E_RECOMMENDED_NUMBER:
        return element->number();
    case E_RECOMMENDED_NAME:
        return element->name();
    case E_RECOMMENDED_FAVORITE:
        return element->isFavorite();
    case E_RECOMMENDED_NOWPLAYING:
        return element->isNowPlaying();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> RecommendedListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_RECOMMENDED_MEDIUM_TITLE] = "mediumTitle";
    roles[E_RECOMMENDED_LONG_TITLE] = "longTitle";
    roles[E_RECOMMENDED_SHORT_DESCRIPTION] = "shortDes";
    roles[E_RECOMMENDED_SHOW_GUID] = "showGuid";
    roles[E_RECOMMENDED_PROGRAM_TYPE] = "programType";
    roles[E_RECOMMENDED_AUDIO_EPISODE_COUNT] = "audioEpCount";
    roles[E_RECOMMENDED_VIDEO_EPISODE_COUNT] = "videoEpCount";
    roles[E_RECOMMENDED_NEW_EPISODE_COUNT] = "newEpCount";
    roles[E_RECOMMENDED_EPISODE_COUNT] = "epCount";
    roles[E_RECOMMENDED_CONTEXTUAL] = "contextual";
    roles[E_RECOMMENDED_IS_MATURE] = "isMature";
    roles[E_RECOMMENDED_CATEGORY] = "category";
    roles[E_RECOMMENDED_LOGO] = "logoUrl";
    roles[E_RECOMMENDED_NUMBER] = "number";
    roles[E_RECOMMENDED_NAME] = "name";
    roles[E_RECOMMENDED_FAVORITE] = "isFavorite";
    roles[E_RECOMMENDED_NOWPLAYING] = "isNowPlaying";

    return roles;
}

bool RecommendedListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if(index.isValid() && (index.row() < m_elements.size())) {
        RecommendedElementPtr element = std::dynamic_pointer_cast<RecommendedElement>(m_elements[index.row()]);
        switch (role) {
        case E_RECOMMENDED_MEDIUM_TITLE:
            element->setMediumTitle(value.toString());
            break;
        case E_RECOMMENDED_LONG_TITLE:
            element->setLongTitle(value.toString());
            break;
        case E_RECOMMENDED_SHORT_DESCRIPTION:
            element->setShortDes(value.toString());
            break;
        case E_RECOMMENDED_SHOW_GUID:
            element->setShowGui(value.toString());
            break;
        case E_RECOMMENDED_PROGRAM_TYPE:
            element->setProgramType(static_cast<PROGRAM_TYPE>(value.toInt()));
            break;
        case E_RECOMMENDED_AUDIO_EPISODE_COUNT:
            element->setAudioEpisode(value.toInt());
            break;
        case E_RECOMMENDED_VIDEO_EPISODE_COUNT:
            element->setVideoEpisode(value.toInt());
            break;
        case E_RECOMMENDED_NEW_EPISODE_COUNT:
            element->setNewEpisodeCount(value.toInt());
            break;
        case E_RECOMMENDED_EPISODE_COUNT:
            element->setEpisodeCount(value.toInt());
            break;
        case E_RECOMMENDED_CONTEXTUAL:
            element->setContextual(value.toString());
            break;
        case E_RECOMMENDED_IS_MATURE:
            element->setIsMature(value.toBool());
            break;
        case E_RECOMMENDED_CATEGORY:
            element->setCategory(value.toString());
            break;
        case E_RECOMMENDED_NUMBER:
            element->setNumber(value.toInt());
            break;
        case E_RECOMMENDED_LOGO:
            element->setLogo(value.toString());
            break;
        case E_RECOMMENDED_NAME:
            element->setName(value.toString());
            break;
        case E_RECOMMENDED_FAVORITE:
            element->setIsFavorite(value.toBool());
            break;
        case E_RECOMMENDED_NOWPLAYING:
            element->setIsNowPlaying(value.toBool());
            break;
        default:
            ret = false;
            break;
        }
    }
    return ret;
}
