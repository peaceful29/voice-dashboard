#ifndef TEAMELEMENT_H
#define TEAMELEMENT_H

#include "BaseElement.h"

class TeamElement: public BaseElement
{
    Q_OBJECT
    Q_PROPERTY(QString name READ name)
    Q_PROPERTY(QString logoUrl READ logoUrl)
public:
    TeamElement();
    ~TeamElement();

    QString name() const;
    void setName(const QString &teamName);
    QString logoUrl() const;
    void setlogoUrl(const QString &url);

    int id() const;
    void setId(int id);

private:
    int m_id;
    QString m_name;
    QString m_logoUrl;
};

typedef std::shared_ptr<TeamElement> TeamPtr;

#endif // TEAMELEMENT_H
