#include "NumberedListModel.h"

NumberedListModel::NumberedListModel()
{

}

NumberedListModel::NumberedListModel(const QString &str, const QString &imgsrc, const int &indx)
{
    s=str;
    imgSrc=imgsrc;
    index = indx;
}

NumberedListModel::NumberedListModel(const NumberedListModel &Obj)
{
    this->s = Obj.s;
    this->imgSrc = Obj.imgSrc;
    this->index = Obj.index;
}

QString NumberedListModel::getName() const
{
    return s;
}

QString NumberedListModel::getImageSrc() const
{
    return imgSrc;
}

int NumberedListModel::getIndx() const
{
    return index;
}


