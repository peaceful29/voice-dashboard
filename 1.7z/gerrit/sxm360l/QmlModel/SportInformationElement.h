#ifndef SPORTINFORMATIONELEMENT_H
#define SPORTINFORMATIONELEMENT_H
#include "ChannelElements.h"
#include "sxm360l/Sxm360lMsgDef.h"

class SportInformationElement : public ChannelElements
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
    Q_OBJECT
    Q_PROPERTY(QString title READ title WRITE setTitle NOTIFY sportInfomationsChanged)
    Q_PROPERTY(long long divisionDuration READ divisionDuration WRITE setDivisionDuration NOTIFY sportInfomationsChanged)
//    Q_PROPERTY(E_EventState::SportsEventState state READ state WRITE setState NOTIFY sportInfomationsChanged)
    Q_PROPERTY(long long startTime READ startTime WRITE setStartTime NOTIFY sportInfomationsChanged)
    Q_PROPERTY(uint32_t homeTeamScore READ homeTeamScore WRITE setHomeTeamScore NOTIFY sportInfomationsChanged)
    Q_PROPERTY(uint32_t awayTeamScore READ awayTeamScore WRITE setAwayTeamScore NOTIFY sportInfomationsChanged)
    Q_PROPERTY(long long currentDivisionProgress READ currentDivisionProgress WRITE setCurrentDivisionProgress NOTIFY sportInfomationsChanged)
    Q_PROPERTY(QString currentDivision READ currentDivision WRITE setCurrentDivision NOTIFY sportInfomationsChanged)
    Q_PROPERTY(E_EventPossession::SportsEventPossession possesion READ possesion WRITE setPossesion NOTIFY sportInfomationsChanged)
    Q_PROPERTY(int leagueId READ leagueId WRITE setLeagueId NOTIFY sportInfomationsChanged)
    Q_PROPERTY(QString homeTeamName READ homeTeamName WRITE setHomeTeamName NOTIFY sportInfomationsChanged)
    Q_PROPERTY(QString awayTeamName READ awayTeamName WRITE setAwayTeamName NOTIFY sportInfomationsChanged)
    Q_PROPERTY(uint32_t number READ number WRITE setNumber NOTIFY sportInfomationsChanged)

    Q_PROPERTY(QString homeTeamLogoUrl READ homeTeamLogoUrl WRITE setHomeTeamLogoUrl NOTIFY sportInfomationsChanged)
    Q_PROPERTY(QString awayTeamLogoUrl READ awayTeamLogoUrl WRITE setAwayTeamLogoUrl NOTIFY sportInfomationsChanged)
//    Q_PROPERTY(uint32_t leagueName READ leagueName WRITE setLeagueName NOTIFY sportInfomationsChanged)


public:
    SportInformationElement();

    QString title() const;
    void setTitle(const QString &title);

    long long divisionDuration() const;
    void setDivisionDuration(long long divisionDuration);

//    E_EventState::SportsEventState state() const;
//    void setState(const E_EventState::SportsEventState &state);

    long long startTime() const;
    void setStartTime(long long startTime);

    uint32_t homeTeamScore() const;
    void setHomeTeamScore(const uint32_t &homeTeamScore);

    uint32_t awayTeamScore() const;
    void setAwayTeamScore(const uint32_t &awayTeamScore);

    long long currentDivisionProgress() const;
    void setCurrentDivisionProgress(long long currentDivisionProgress);

    QString currentDivision() const;
    void setCurrentDivision(const QString &currentDivision);

    E_EventPossession::SportsEventPossession possesion() const;
    void setPossesion(const E_EventPossession::SportsEventPossession &possesion);

    int leagueId() const;
    void setLeagueId(int leagueId);

    QString homeTeamName() const;
    void setHomeTeamName(const QString &homeTeamName);

    QString awayTeamName() const;
    void setAwayTeamName(const QString &awayTeamName);

//    uint32_t number() const;
//    void setNumber(const uint32_t &number);

    void setValue(QString name,
                   QString shortDescription,
                   unsigned int number,
                   bool isAvailable,
                   bool isNowPlaying,
                   uint32_t homeTeamScore,
                   uint32_t awayTeamScore,
//                   E_EventState::SportsEventState state,
                   QString logo);
    void setValue(CHANNEL_INFORMATION_T& stSportChannelInfomation);

//    QString leagueName() const;
//    void setLeagueName(const QString &leagueName);

    QString homeTeamLogoUrl() const;
    void setHomeTeamLogoUrl(const QString &homeTeamLogoUrl);

    QString awayTeamLogoUrl() const;
    void setAwayTeamLogoUrl(const QString &awayTeamLogoUrl);

private:
    QString m_title;
    long long m_divisionDuration;
    //    E_EventState::SportsEventState m_state;
    long long m_startTime;
    uint32_t m_homeTeamScore;
    uint32_t m_awayTeamScore;
    QString m_currentDivision;
    long long m_currentDivisionProgress;
    E_EventPossession::SportsEventPossession m_possesion;
    int m_leagueId;
    QString m_homeTeamName;
    QString m_awayTeamName;
    QString m_homeTeamLogoUrl;
    QString m_awayTeamLogoUrl;
//    QString m_leagueName;
//    uint32_t m_number;
signals:
    void sportInfomationsChanged();
};
typedef std::shared_ptr<SportInformationElement> SportInformationElementPtr;

#endif // SPORTINFORMATIONELEMENT_H
