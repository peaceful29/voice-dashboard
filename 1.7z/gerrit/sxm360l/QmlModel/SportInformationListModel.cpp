#include "SportInformationListModel.h"
#include "Common/SXMDefine.h"

SportInformationListModel::SportInformationListModel()
{

}

SportInformationListModel::~SportInformationListModel()
{

}

QVariant SportInformationListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    SportInformationElementPtr element = std::dynamic_pointer_cast<SportInformationElement>(m_elements[index.row()]);
    switch (role) {
    case E_SPORT_INFOMATION_ROLES_TITLE:
        return element->title();
    case E_SPORT_INFOMATION_ROLES_STATE:
        return element->sportState();
    case E_SPORT_INFOMATION_ROLES_START_TIME:
        return element->startTime();
    case E_SPORT_INFOMATION_ROLES_HOME_TEAM_SCORE:
        return element->homeTeamScore();
    case E_SPORT_INFOMATION_ROLES_AWAY_TEAM_SCORE:
        return element->awayTeamScore();
    case E_SPORT_INFOMATION_ROLES_POSSESION:
        return element->possesion();
    case E_SPORT_INFOMATION_ROLES_LEAGUEID:
        return element->leagueId();
    case E_SPORT_INFOMATION_ROLES_HOME_TEAM_NAME:
        return element->homeTeamName();
    case E_SPORT_INFOMATION_ROLES_AWAY_TEAM_NAME:
        return element->awayTeamName();
    case E_SPORT_INFOMATION_ROLES_CHANNEL_NUMBER:
        return element->number();
    case E_SPORT_INFOMATION_ROLES_CURRENT_DIVISION:
        return element->currentDivision();
    case E_SPORT_INFOMATION_ROLES_DIVISION_DURATION:
        return element->divisionDuration();
    case E_SPORT_INFOMATION_ROLES_CURRENT_DIVISION_PROGRESS:
        return element->currentDivisionProgress();
    case E_SPORT_INFOMATION_ROLES_CHANNEL_SHORT_DESCRIPTION:
        return element->shortDescription();
    case E_SPORT_INFOMATION_ROLES_CHANNEL_IS_AVAILABLE:
        return element->isAvailable();
    case E_SPORT_INFOMATION_ROLES_CHANNEL_LOGO:
        return element->logo();
//    case E_SPORT_INFOMATION_ROLES_LEAGUE_NAME:
//        return element->leagueName();
    case E_SPORT_INFOMATION_ROLES_HOME_TEAM_LOGO:
        return element->homeTeamLogoUrl();
    case E_SPORT_INFOMATION_ROLES_AWAY_TEAM_LOGO:
        return element->awayTeamLogoUrl();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> SportInformationListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_SPORT_INFOMATION_ROLES_TITLE] = "title";
    roles[E_SPORT_INFOMATION_ROLES_STATE] = "eventSportState";
    roles[E_SPORT_INFOMATION_ROLES_START_TIME] = "startTime";
    roles[E_SPORT_INFOMATION_ROLES_HOME_TEAM_SCORE] = "homeTeamScore";
    roles[E_SPORT_INFOMATION_ROLES_AWAY_TEAM_SCORE] = "awayTeamScore";
    roles[E_SPORT_INFOMATION_ROLES_POSSESION] = "possesion";
    roles[E_SPORT_INFOMATION_ROLES_LEAGUEID] = "leagueId";
    roles[E_SPORT_INFOMATION_ROLES_HOME_TEAM_NAME] = "homeTeamName";
    roles[E_SPORT_INFOMATION_ROLES_AWAY_TEAM_NAME] = "awayTeamName";
    roles[E_SPORT_INFOMATION_ROLES_CHANNEL_NUMBER] = "number";
    roles[E_SPORT_INFOMATION_ROLES_CURRENT_DIVISION] = "currentDivision";
    roles[E_SPORT_INFOMATION_ROLES_DIVISION_DURATION] = "divisionDuration";
    roles[E_SPORT_INFOMATION_ROLES_CURRENT_DIVISION_PROGRESS] = "currentDivisionProgress";
    roles[E_SPORT_INFOMATION_ROLES_CHANNEL_SHORT_DESCRIPTION] = "shortDescription";
    roles[E_SPORT_INFOMATION_ROLES_CHANNEL_IS_AVAILABLE] = "isAvailable";
    roles[E_SPORT_INFOMATION_ROLES_CHANNEL_LOGO] = "logoUrl";
    roles[E_SPORT_INFOMATION_ROLES_HOME_TEAM_LOGO] = "homeTeamUrl";
    roles[E_SPORT_INFOMATION_ROLES_AWAY_TEAM_LOGO] = "awayTeamUrl";
//    roles[E_SPORT_INFOMATION_ROLES_LEAGUE_NAME] = "leagueName";

    return roles;
}

bool SportInformationListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if (index.isValid() && (index.row() < m_elements.size())) {
        SportInformationElementPtr element = std::dynamic_pointer_cast<SportInformationElement>(m_elements[index.row()]);
        switch (role) {
        case E_SPORT_INFOMATION_ROLES_TITLE:
            element->setTitle(value.toString());
            break;
//        case E_SPORT_INFOMATION_ROLES_STATE:
//            element->setState(static_cast<E_EventState::SportsEventState>(value.toInt()));
//            break;
        case E_SPORT_INFOMATION_ROLES_START_TIME:
            element->setStartTime(value.toInt());
            break;
        case E_SPORT_INFOMATION_ROLES_HOME_TEAM_SCORE:
            element->setHomeTeamScore(value.toInt());
            break;
        case E_SPORT_INFOMATION_ROLES_AWAY_TEAM_SCORE:
            element->setAwayTeamScore(value.toInt());
            break;
        case E_SPORT_INFOMATION_ROLES_POSSESION:
            element->setPossesion(static_cast<E_EventPossession::SportsEventPossession>(value.toInt()));
            break;
        case E_SPORT_INFOMATION_ROLES_LEAGUEID:
            element->setLeagueId(value.toInt());
            break;
        case E_SPORT_INFOMATION_ROLES_HOME_TEAM_NAME:
            element->setHomeTeamName(value.toString());
            break;
        case E_SPORT_INFOMATION_ROLES_AWAY_TEAM_NAME:
            element->setAwayTeamName(value.toString());
            break;
        case E_SPORT_INFOMATION_ROLES_CHANNEL_NUMBER:
            element->setNumber(value.toInt());
            break;
        case E_SPORT_INFOMATION_ROLES_CURRENT_DIVISION:
            element->setCurrentDivision(value.toString());
            break;
        case E_SPORT_INFOMATION_ROLES_DIVISION_DURATION:
            element->setDivisionDuration(value.toInt());
            break;
        case E_SPORT_INFOMATION_ROLES_CURRENT_DIVISION_PROGRESS:
            element->setCurrentDivisionProgress(value.toInt());
            break;
        case E_SPORT_INFOMATION_ROLES_CHANNEL_SHORT_DESCRIPTION:
            element->setShortDescription(value.toString());
            break;
        case E_SPORT_INFOMATION_ROLES_CHANNEL_IS_AVAILABLE:
            element->setIsAvailable(value.toBool());
            break;
        case E_SPORT_INFOMATION_ROLES_CHANNEL_LOGO:
            element->setLogo(value.toString());
            break;
        case E_SPORT_INFOMATION_ROLES_HOME_TEAM_LOGO:
            element->setHomeTeamLogoUrl(value.toString());
            break;
        case E_SPORT_INFOMATION_ROLES_AWAY_TEAM_LOGO:
            element->setAwayTeamLogoUrl(value.toString());
            break;
//        case E_SPORT_INFOMATION_ROLES_LEAGUE_NAME:
//            element->setLeagueName(value.toString());
//            break;
        default:
            ret = false;
            break;
        }
    }
    return ret;
}
