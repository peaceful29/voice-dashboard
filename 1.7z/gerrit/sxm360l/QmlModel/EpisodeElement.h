#ifndef EPISODEELEMENT_H
#define EPISODEELEMENT_H

#include "BaseElement.h"

class EpisodeElement: public BaseElement
{
public:
    EpisodeElement();
    virtual ~EpisodeElement();
    QString tittle() const;
    void setTittle(const QString &tittle);

    QString shortDes() const;
    void setShortDes(const QString &shortDes);

    QString episodeGuid() const;
    void setEpisodeGuid(const QString &episodeGuid);

    QString contextual() const;
    void setContextual(const QString &contextual);

    bool isLive() const;
    void setIsLive(bool isLive);

    bool isHighlighted() const;
    void setIsHighlighted(bool isHighlighted);

    bool isHot() const;
    void setIsHot(bool isHot);

    bool isSpecial() const;
    void setIsSpecial(bool isSpecial);

    uint32_t percentConsumed() const;
    void setPercentConsumed(const uint32_t &percentConsumed);

    bool isValuable() const;
    void setIsValuable(bool isValuable);

private:
    QString m_tittle;
    QString m_shortDes;
    QString m_episodeGuid;
    QString m_contextual;
    bool    m_isLive;
    bool    m_isHighlighted;
    bool    m_isHot;
    bool    m_isValuable;
    bool    m_isSpecial;
    uint32_t m_percentConsumed;
};

typedef std::shared_ptr<EpisodeElement> EpisodeElementPtr;

#endif // EPISODEELEMENT_H
