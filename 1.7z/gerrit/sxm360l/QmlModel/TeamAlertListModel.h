#ifndef TEAMALERTLISTMODEL_H
#define TEAMALERTLISTMODEL_H

#include <QObject>
#include "BaseListModel.h"
class TeamAlertListModel : public BaseListModel
{
    Q_OBJECT
public:
    explicit TeamAlertListModel(QObject* parent = nullptr);
    ~TeamAlertListModel();

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    virtual QHash<int, QByteArray> roleNames() const;
    Q_INVOKABLE void remove(int idx);

protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // TEAMALERTLISTMODEL_H
