#ifndef TEAM_H
#define TEAM_H

#include <QObject>
//#include "BaseListModel.h"
#include "PagingBaseListModel.h"
#include "TeamElement.h"

class TeamListModel : public PagingBaseListModel
{
    Q_OBJECT
public:
    explicit TeamListModel(QObject* parent = nullptr);
    ~TeamListModel();

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    virtual QHash<int, QByteArray> roleNames() const;

protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // TEAM_H
