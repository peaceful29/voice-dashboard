#ifndef NUMBEREDLISTMODEL_H
#define NUMBEREDLISTMODEL_H



#include <QString>

class NumberedListModel
{
public:
    NumberedListModel();
    NumberedListModel(const QString &str, const QString &imgsrc, const int &indx);
    NumberedListModel(const NumberedListModel &Obj);
    QString getName() const;
    QString getImageSrc() const;
    int getIndx() const;
private:
    QString s;
    QString imgSrc;
    int index;
};


#endif // NUMBEREDLISTMODEL_H
