#ifndef CHANNELLISTMODEL_H
#define CHANNELLISTMODEL_H

#include <QObject>
#include "BaseListModel.h"
#include "ChannelElements.h"
#include "Common/SXMDefine.h"

class ChannelListModel : public BaseListModel
{
    Q_OBJECT
public:
    explicit ChannelListModel(QObject* parent = nullptr);
    ~ChannelListModel();

    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;
    virtual QHash<int,QByteArray> roleNames() const;
    Q_INVOKABLE void move(int src, int dst);
    Q_INVOKABLE void remove(int idx);

protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // CHANNELLISTMODEL_H
