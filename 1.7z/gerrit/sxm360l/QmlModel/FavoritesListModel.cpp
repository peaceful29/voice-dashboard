#include "FavoritesListModel.h"

FavoritesListModel::FavoritesListModel(QObject *parent):BaseListModel(parent)
{

}

FavoritesListModel::~FavoritesListModel()
{

}

QVariant FavoritesListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    FavoritesListElementsPtr element = std::dynamic_pointer_cast<FavoritesListElements>(m_elements[index.row()]);
    if (element == nullptr)
        return QVariant();
    switch (role) {
    case E_FAVORITES_TYPE:
        return element->favType();
    case E_FAVORITES_NAME:
        return element->favName();
    case E_FAVORITES_ID:
        return element->favId();
    case E_FAVORITES_CONTEXTUAL_BANNER:
        return element->favBanner();
    case E_FAVORITES_CHANNELS_NAME:
        return element->name();
    case E_FAVORITES_CHANNELS_SHORT_DESCRIPTION:
        return element->shortDescription();
    case E_FAVORITES_CHANNELS_CATEGORY:
        return element->category();
    case E_FAVORITES_CHANNELS_ID:
        return element->id();
    case E_FAVORITES_CHANNELS_LOGO:
        return element->logo();
    case E_FAVORITES_CHANNELS_ARTIST_NAME:
        return element->artistName();
    case E_FAVORITES_CHANNELS_ART_URL:
        return element->artUrl();
    case E_FAVORITES_CHANNELS_MEDIUM_TITLE:
        return element->mediumTitle();
//    case E_FAVORITES_CHANNELS_LIVE_CHANNEL_ID:
//        return element->liveChannelId();
    case E_FAVORITES_CHANNELS_CONTEXTUAL_BANNER:
        return element->contextualBanner();
    case E_FAVORITES_CHANNELS_DELIVERY_STATE:
        return element->deliveryState();
    case E_FAVORITES_CHANNELS_NUMBER:
        return element->number();
    case E_FAVORITES_CHANNELS_SID:
        return element->sid();
    case E_FAVORITES_CHANNELS_IS_AVAILABLE:
        return element->isAvailable();
    case E_FAVORITES_CHANNELS_IS_FAVORITE:
        return element->isFavorite();
    case E_FAVORITES_CHANNELS_IS_PLAYBYPLAY:
        return element->isPlayByPlay();
    case E_FAVORITES_CHANNELS_IS_SATONLY:
        return element->isSatOnly();
    case E_FAVORITES_CHANNELS_IS_FREETOAIR:
        return element->isFreeToAir();
    case E_FAVORITES_CHANNELS_IS_SUBSCRIBED:
        return element->isSubscribed();
    case E_FAVORITES_CHANNELS_IS_NOWPLAYING:
        return element->isNowPlaying();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> FavoritesListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_FAVORITES_TYPE] = "type";
    roles[E_FAVORITES_NAME] = "favName";
    roles[E_FAVORITES_ID] = "favId";
    roles[E_FAVORITES_CONTEXTUAL_BANNER] = "favBanner";
    roles[E_FAVORITES_CHANNELS_NAME] = "chnName";
    roles[E_FAVORITES_CHANNELS_SHORT_DESCRIPTION] = "chnShortDes";
    roles[E_FAVORITES_CHANNELS_CATEGORY] = "chnCategory";
    roles[E_FAVORITES_CHANNELS_ID] = "chnId";
    roles[E_FAVORITES_CHANNELS_LOGO] = "chnLogo";
    roles[E_FAVORITES_CHANNELS_ARTIST_NAME] = "chnArtistName";
    roles[E_FAVORITES_CHANNELS_ART_URL] = "chnArtUrl";
    roles[E_FAVORITES_CHANNELS_MEDIUM_TITLE] = "chnMedTittle";
//    roles[E_FAVORITES_CHANNELS_LIVE_CHANNEL_ID] = "chnLiveId";
    roles[E_FAVORITES_CHANNELS_CONTEXTUAL_BANNER] = "chnBanner";
    roles[E_FAVORITES_CHANNELS_DELIVERY_STATE] = "chnDeliveryState";
    roles[E_FAVORITES_CHANNELS_NUMBER] = "chnNum";
    roles[E_FAVORITES_CHANNELS_SID] = "chnSid";
    roles[E_FAVORITES_CHANNELS_IS_AVAILABLE] = "chnIsAvalid";
    roles[E_FAVORITES_CHANNELS_IS_FAVORITE] = "chnIsFav";
    roles[E_FAVORITES_CHANNELS_IS_PLAYBYPLAY] = "chnByPlay";
    roles[E_FAVORITES_CHANNELS_IS_SATONLY] = "chnIsSatonly";
    roles[E_FAVORITES_CHANNELS_IS_FREETOAIR] = "chnIsFreeToAir";
    roles[E_FAVORITES_CHANNELS_IS_SUBSCRIBED] = "chnIsSub";
    roles[E_FAVORITES_CHANNELS_IS_NOWPLAYING] = "chnIsNowPlaying";
    return roles;
}

void FavoritesListModel::move(int src, int dst)
{
    if (0 <= src && src < m_elements.size() && 0 <= dst && dst < m_elements.size() && src != dst) {
        if(dst > src) {
            beginMoveRows(QModelIndex(), src, src, QModelIndex(), dst + 1);
        } else {
            beginMoveRows(QModelIndex(), src, src, QModelIndex(), dst);
        }
        m_elements.move(src, dst);
        endMoveRows();
    }
}

void FavoritesListModel::remove(int idx)
{
    if (idx < m_elements.size()) {
        beginRemoveRows(QModelIndex(), idx, idx);
        BaseElementPtr element = m_elements.takeAt(idx);
        Q_UNUSED(element)
        endRemoveRows();
    }
}

//int FavoritesListModel::rowCount(const QModelIndex &parent) const
//{
//    Q_UNUSED(parent);
//    return m_elements.size();
//}

bool FavoritesListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if(index.isValid() && (index.row() < m_elements.size())) {
        FavoritesListElementsPtr element = std::dynamic_pointer_cast<FavoritesListElements>(m_elements[index.row()]);
        if (element == nullptr)
            return false;
        switch (role) {
        case E_FAVORITES_TYPE:
            element->setFavType(value.toInt());
            break;
        case E_FAVORITES_NAME:
            element->setFavName(value.toString());
            break;
        case E_FAVORITES_ID:
            element->setFavId(value.toString());
            break;
        case E_FAVORITES_CONTEXTUAL_BANNER:
            element->setFavBanner(value.toString());
            break;
        case E_FAVORITES_CHANNELS_NAME:
            element->setName(value.toString());
            break;
        case E_FAVORITES_CHANNELS_SHORT_DESCRIPTION:
            element->setShortDescription(value.toString());
            break;
        case E_FAVORITES_CHANNELS_CATEGORY:
            element->setCategory(value.toString());
            break;
        case E_FAVORITES_CHANNELS_ID:
            element->setId(value.toString());
            break;
        case E_FAVORITES_CHANNELS_LOGO:
            element->setLogo(value.toString());
            break;
        case E_FAVORITES_CHANNELS_ARTIST_NAME:
            element->setArtistName(value.toString());
            break;
        case E_FAVORITES_CHANNELS_ART_URL:
            element->setArtUrl(value.toString());
            break;
        case E_FAVORITES_CHANNELS_MEDIUM_TITLE:
            element->setMediumTitle(value.toString());
            break;
//        case E_FAVORITES_CHANNELS_LIVE_CHANNEL_ID:
//            element->setLiveChannelId(value.toString());
//            break;
        case E_FAVORITES_CHANNELS_CONTEXTUAL_BANNER:
            element->setContextualBanner(value.toString());
            break;
        case E_FAVORITES_CHANNELS_DELIVERY_STATE:
            element->setDeliveryState(value.toUInt());
            break;
        case E_FAVORITES_CHANNELS_NUMBER:
            element->setNumber(value.toUInt());
            break;
        case E_FAVORITES_CHANNELS_SID:
            element->setSid(value.toUInt());
            break;
        case E_FAVORITES_CHANNELS_IS_AVAILABLE:
            element->setIsAvailable(value.toBool());
            break;
        case E_FAVORITES_CHANNELS_IS_FAVORITE:
            element->setIsFavorite(value.toBool());
            break;
        case E_FAVORITES_CHANNELS_IS_PLAYBYPLAY:
            element->setIsPlayByPlay(value.toBool());
            break;
        case E_FAVORITES_CHANNELS_IS_SATONLY:
            element->setIsSatOnly(value.toBool());
            break;
        case E_FAVORITES_CHANNELS_IS_FREETOAIR:
            element->setIsFreeToAir(value.toBool());
            break;
        case E_FAVORITES_CHANNELS_IS_SUBSCRIBED:
            element->setIsSubscribed(value.toBool());
            break;
        case E_FAVORITES_CHANNELS_IS_NOWPLAYING:
            element->setIsNowPlaying(value.toBool());
            break;
        default:
            ret = false;
            break;
        }
    }
    return ret;
}
