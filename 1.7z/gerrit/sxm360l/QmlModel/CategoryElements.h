#ifndef CATEGORYELEMENTS_H
#define CATEGORYELEMENTS_H
#include "BaseElement.h"


class CategoryElements : public BaseElement
{
public:
    CategoryElements();
    virtual ~CategoryElements();

    QString categoryName() const;
    void setCategoryName(const QString &categoryName);

    QString categoryLogo() const;
    void setCategoryLogo(const QString &categoryLogo);

    int32_t categoryId() const;
    void setCategoryId(const int32_t &categoryId);

private:
    QString m_categoryName;
    QString m_categoryLogo;
    int32_t m_Id;
};

typedef std::shared_ptr<CategoryElements> CategoryElementsPtr;

#endif // CATEGORYELEMENTS_H
