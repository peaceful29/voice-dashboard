#include "SportsLeagueElements.h"

SportsLeagueElements::SportsLeagueElements()
{

}

SportsLeagueElements::~SportsLeagueElements()
{

}

int SportsLeagueElements::leagueId() const
{
    return m_leagueId;
}

void SportsLeagueElements::setLeagueId(int leagueId)
{
    m_leagueId = leagueId;
}

QString SportsLeagueElements::leagueName() const
{
    return m_leagueName;
}

void SportsLeagueElements::setLeagueName(const QString &leagueName)
{
    m_leagueName = leagueName;
}

QString SportsLeagueElements::leagueLogo() const
{
    return m_leagueLogo;
}

void SportsLeagueElements::setLeagueLogo(const QString &leagueLogo)
{
    m_leagueLogo = leagueLogo;
}
