#ifndef SPORTSLEAGUELISTMODEL_H
#define SPORTSLEAGUELISTMODEL_H

#include <QObject>
#include "BaseListModel.h"

class SportsLeagueListModel : public BaseListModel
{
    Q_OBJECT
public:
    explicit SportsLeagueListModel(QObject* parent = nullptr);
    ~SportsLeagueListModel();

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    virtual QHash<int, QByteArray> roleNames() const;
    Q_INVOKABLE void remove(int idx);

protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // SPORTSLEAGUELISTMODEL_H
