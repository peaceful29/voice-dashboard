#include "SportInformationElement.h"

SportInformationElement::SportInformationElement()
{

}

QString SportInformationElement::title() const
{
    return m_title;
}

void SportInformationElement::setTitle(const QString &title)
{
    m_title = title;
    emit sportInfomationsChanged();
}

long long SportInformationElement::divisionDuration() const
{
    return m_divisionDuration;
}

void SportInformationElement::setDivisionDuration(long long divisionDuration)
{
    m_divisionDuration = divisionDuration;
    emit sportInfomationsChanged();
}

//E_EventState::SportsEventState SportInformationElement::state() const
//{
//    return m_state;
//}

//void SportInformationElement::setState(const E_EventState::SportsEventState &state)
//{
//    m_state = state;
//    emit sportInfomationsChanged();
//}

long long SportInformationElement::startTime() const
{
    return m_startTime;
}

void SportInformationElement::setStartTime(long long startTime)
{
    m_startTime = startTime;
    emit sportInfomationsChanged();
}

uint32_t SportInformationElement::homeTeamScore() const
{
    return m_homeTeamScore;
}

void SportInformationElement::setHomeTeamScore(const uint32_t &homeTeamScore)
{
    m_homeTeamScore = homeTeamScore;
    emit sportInfomationsChanged();
}

uint32_t SportInformationElement::awayTeamScore() const
{
    return m_awayTeamScore;
}

void SportInformationElement::setAwayTeamScore(const uint32_t &awayTeamScore)
{
    m_awayTeamScore = awayTeamScore;
    emit sportInfomationsChanged();
}

long long SportInformationElement::currentDivisionProgress() const
{
    return m_currentDivisionProgress;
}

void SportInformationElement::setCurrentDivisionProgress(long long currentDivisionProgress)
{
    m_currentDivisionProgress = currentDivisionProgress;
    emit sportInfomationsChanged();
}

QString SportInformationElement::currentDivision() const
{
    return m_currentDivision;
}

void SportInformationElement::setCurrentDivision(const QString &currentDivision)
{
    m_currentDivision = currentDivision;
    emit sportInfomationsChanged();
}

E_EventPossession::SportsEventPossession SportInformationElement::possesion() const
{
    return m_possesion;
}

void SportInformationElement::setPossesion(const E_EventPossession::SportsEventPossession &possesion)
{
    m_possesion = possesion;
    emit sportInfomationsChanged();
}

int SportInformationElement::leagueId() const
{
    return m_leagueId;
}

void SportInformationElement::setLeagueId(int leagueId)
{
    m_leagueId = leagueId;
    emit sportInfomationsChanged();
}

QString SportInformationElement::homeTeamName() const
{
    return m_homeTeamName;
}

void SportInformationElement::setHomeTeamName(const QString &homeTeamName)
{
    m_homeTeamName = homeTeamName;
    emit sportInfomationsChanged();
}

QString SportInformationElement::awayTeamName() const
{
    return m_awayTeamName;
}

void SportInformationElement::setAwayTeamName(const QString &awayTeamName)
{
    m_awayTeamName = awayTeamName;
    emit sportInfomationsChanged();
}

//uint32_t SportInformationElement::number() const
//{
//    return m_number;
//}

//void SportInformationElement::setNumber(const uint32_t &number)
//{
//    m_number = number;
//    emit sportInfomationsChanged();
//}
void SportInformationElement::setValue(QString name,
                               QString shortDescription,
                               unsigned int number,
                               bool isAvailable,
                               bool isNowPlaying,
                               uint32_t homeTeamScore,
                               uint32_t awayTeamScore,
                               QString logo)
{
//    setName(name);
//    setShortDescription(shortDescription);
//    setNumber(number);
//    setIsAvailable(isAvailable);
//    setIsNowPlaying(isNowPlaying);
//    setLogo(logo);
//    m_homeTeamScore = homeTeamScore;
//    m_awayTeamScore = awayTeamScore;
//    m_state = state;
}

void SportInformationElement::setValue(CHANNEL_INFORMATION_T& stSportChannelInfomation)
{
//    setValue(QString(stSportChannelInfomation.name),
//             QString(stSportChannelInfomation.shortDescription),
//             stSportChannelInfomation.number,
//             stSportChannelInfomation.isAvailable,
//             stSportChannelInfomation.isNowPlaying,
//             stSportChannelInfomation.sports.homeTeamScore,
//             stSportChannelInfomation.sports.awayTeamScore,
////             stChannelInfomation.sports.state,
//             QString(stSportChannelInfomation.logoUrl));
    LOGI().writeFormatted("[SportInformationElement::setValue]: CALLED");
    setName(stSportChannelInfomation.name);
    setNumber(stSportChannelInfomation.number);
    setArtistName(stSportChannelInfomation.album.artistName);
    setLogo(stSportChannelInfomation.logoUrl);
    setShortDescription(stSportChannelInfomation.shortDescription);
    setNumber(stSportChannelInfomation.number);
    setIsAvailable(stSportChannelInfomation.isAvailable);
    setIsNowPlaying(stSportChannelInfomation.isNowPlaying);
    m_homeTeamScore = stSportChannelInfomation.sports.homeTeamScore;
    m_awayTeamScore = stSportChannelInfomation.sports.awayTeamScore;
    m_homeTeamName = stSportChannelInfomation.sports.homeTeamName;
    m_awayTeamName = stSportChannelInfomation.sports.awayTeamName;
    m_homeTeamLogoUrl = stSportChannelInfomation.sports.homeTeamLogoUrl;
    m_awayTeamLogoUrl = stSportChannelInfomation.sports.awayTeamLogoUrl;
    m_currentDivision = stSportChannelInfomation.sports.currentDivision;
    m_possesion = stSportChannelInfomation.sports.possesion;
    m_leagueId = stSportChannelInfomation.sports.leagueId;
}

QString SportInformationElement::homeTeamLogoUrl() const
{
    return m_homeTeamLogoUrl;
}

void SportInformationElement::setHomeTeamLogoUrl(const QString &homeTeamLogoUrl)
{
    m_homeTeamLogoUrl = homeTeamLogoUrl;
    emit sportInfomationsChanged();
}

QString SportInformationElement::awayTeamLogoUrl() const
{
    return m_awayTeamLogoUrl;
}

void SportInformationElement::setAwayTeamLogoUrl(const QString &awayTeamLogoUrl)
{
    m_awayTeamLogoUrl = awayTeamLogoUrl;
    emit sportInfomationsChanged();
}
