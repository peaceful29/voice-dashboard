#include "ChannelElements.h"
#include <QDebug>

ChannelElements::ChannelElements()
    : m_name(""),
      m_shortDescription(""),
      m_category(""),
      m_id(""),
      m_logo(""),
      m_artistName(""),
      m_songName(""),
      m_artUrl(""),
      m_mediumTitle(""),
      m_deliveryState(0),
      m_number(0),
      m_sid(0),
      m_isAvailable(false),
      m_isFavorite(false),
      m_isPlayByPlay(false),
      m_isSatOnly(false),
      m_isFreeToAir(false),
      m_isSubscribed(false),
      m_isNowPlaying(false),
      m_sportState(UIBridge::E_HMI_EVENT_SPORTS_UNKNOWN),
      m_channelType(UIBridge::E_HMI_EVENT_NONE)
{

}
ChannelElements::~ChannelElements()
{

}

QString ChannelElements::name() const
{
    return m_name;
}

void ChannelElements::setName(const QString &name)
{
    if(m_name == name){
        return;
    }
    m_name = name;
    emit channelInfomationsChanged();
}

QString ChannelElements::shortDescription() const
{
    return m_shortDescription;
}

void ChannelElements::setShortDescription(const QString &shortDescription)
{
    if(m_shortDescription == shortDescription){
        return;
    }
    m_shortDescription = shortDescription;
    emit channelInfomationsChanged();
}

QString ChannelElements::category() const
{
    return m_category;
}

void ChannelElements::setCategory(const QString &category)
{
    if(m_category == category){
        return;
    }
    m_category = category;
    emit channelInfomationsChanged();
}

QString ChannelElements::id() const
{
    return m_id;
}

void ChannelElements::setId(const QString &id)
{
    if(m_id == id){
        return;
    }
    m_id = id;
    emit channelInfomationsChanged();
}

QString ChannelElements::logo() const
{
    return m_logo;
}

void ChannelElements::setLogo(const QString &logo)
{
    if(m_logo == logo){
        return;
    }
    m_logo = logo;
    emit channelInfomationsChanged();
}

QString ChannelElements::artistName() const
{
    return m_artistName;
}

void ChannelElements::setArtistName(const QString &artistName)
{
    if(m_artistName == artistName){
        return;
    }
    m_artistName = artistName;
    emit channelInfomationsChanged();
}

QString ChannelElements::songName() const
{
    return m_songName;
}

void ChannelElements::setSongName(const QString &songName)
{
    if(m_songName == songName){
        return;
    }
    m_songName = songName;
    emit channelInfomationsChanged();
}

QString ChannelElements::artUrl() const
{
    return m_artUrl;
}

void ChannelElements::setArtUrl(const QString &artUrl)
{
    if(m_artUrl == artUrl){
        return;
    }
    m_artUrl = artUrl;
    emit channelInfomationsChanged();
}

QString ChannelElements::mediumTitle() const
{
    return m_mediumTitle;
}

void ChannelElements::setMediumTitle(const QString &mediumTitle)
{
    if(m_mediumTitle == mediumTitle){
        return;
    }
    m_mediumTitle = mediumTitle;
    emit channelInfomationsChanged();
}

//QString ChannelElements::liveChannelId() const
//{
//    return m_liveChannelId;
//}

//void ChannelElements::setLiveChannelId(const QString &liveChannelId)
//{
//    if(m_liveChannelId == liveChannelId){
//        return;
//    }
//    m_liveChannelId = liveChannelId;
//    emit channelInfomationsChanged();
//}
QString ChannelElements::contextualBanner() const
{
    return m_contextualBanner;
}

void ChannelElements::setContextualBanner(const QString &contextualBanner)
{
    if(m_contextualBanner == contextualBanner){
        return;
    }
    m_contextualBanner = contextualBanner;
    emit channelInfomationsChanged();
}

unsigned int ChannelElements::deliveryState() const
{
    return m_deliveryState;
}

void ChannelElements::setDeliveryState(const unsigned int &deliveryState)
{
    if(m_deliveryState == deliveryState){
        return;
    }
    m_deliveryState = deliveryState;
    emit channelInfomationsChanged();
}
int ChannelElements::number() const
{
    return m_number;
}

void ChannelElements::setNumber(const int &number)
{
    if(m_number == number){
        return;
    }
    m_number = number;
    emit channelInfomationsChanged();
}
unsigned int ChannelElements::sid() const
{
    return m_sid;
}

void ChannelElements::setSid(const unsigned int &sid)
{
    if(m_sid == sid){
        return;
    }
    m_sid = sid;
    emit channelInfomationsChanged();
}
bool ChannelElements::isAvailable() const
{
    return m_isAvailable;
}

void ChannelElements::setIsAvailable(const bool &isAvailable)
{
    if(m_isAvailable == isAvailable){
        return;
    }
    m_isAvailable = isAvailable;
    emit channelInfomationsChanged();
}
bool ChannelElements::isFavorite() const
{
    return m_isFavorite;
}

void ChannelElements::setIsFavorite(const bool &isFavorite)
{
    if(m_isFavorite == isFavorite){
        return;
    }
    m_isFavorite = isFavorite;
    emit channelInfomationsChanged();
}
bool ChannelElements::isPlayByPlay() const
{
    return m_isPlayByPlay;
}

void ChannelElements::setIsPlayByPlay(const bool &isPlayByPlay)
{
    if(m_isPlayByPlay == isPlayByPlay){
        return;
    }
    m_isPlayByPlay = isPlayByPlay;
    emit channelInfomationsChanged();
}
bool ChannelElements::isSatOnly() const
{
    return m_isSatOnly;
}

void ChannelElements::setIsSatOnly(const bool &isSatOnly)
{
    if(m_isSatOnly == isSatOnly){
        return;
    }
    m_isSatOnly = isSatOnly;
    emit channelInfomationsChanged();
}
bool ChannelElements::isFreeToAir() const
{
    return m_isFreeToAir;
}

void ChannelElements::setIsFreeToAir(const bool &isFreeToAir)
{
    if(m_isFreeToAir == isFreeToAir){
        return;
    }
    m_isFreeToAir = isFreeToAir;
    emit channelInfomationsChanged();
}
bool ChannelElements::isSubscribed() const
{
    return m_isSubscribed;
}

void ChannelElements::setIsSubscribed(const bool &isSubscribed)
{
    if(m_isSubscribed == isSubscribed){
        return;
    }
    m_isSubscribed = isSubscribed;
    emit channelInfomationsChanged();
}
bool ChannelElements::isNowPlaying() const
{
    return m_isNowPlaying;
}

void ChannelElements::setIsNowPlaying(const bool &isNowPlaying)
{
    if(m_isNowPlaying == isNowPlaying){
        return;
    }
    m_isNowPlaying = isNowPlaying;
    emit channelInfomationsChanged();
}

UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE ChannelElements::sportState() const
{
    return m_sportState;
}

void ChannelElements::setSportState(const UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE sportState)
{
    if(m_sportState == sportState){
        return;
    }
    m_sportState = sportState;
    emit channelInfomationsChanged();
}

QString ChannelElements::categoryLogoUrl() const
{
    return m_categoryLogoUrl;
}

void ChannelElements::setCategoryLogoUrl(const QString &categoryLogoUrl)
{
    if(m_categoryLogoUrl == categoryLogoUrl){
        return;
    }
    m_categoryLogoUrl = categoryLogoUrl;
    emit channelInfomationsChanged();
}

//void ChannelElements::setValue(QString name,
//                               QString shortDescription,
//                               unsigned int number,
//                               unsigned int sid,
//                               bool isAvailable,
//                               bool isFavorite,
//                               bool isPlayByPlay,
//                               bool isSatOnly,
//                               bool isFreeToAir,
//                               bool isSubscribed,
//                               bool isNowPlaying,
//                               QString category,
//                               QString id,
//                               QString logo,
//                               QString artistName,
//                               QString songName,
//                               QString artUrl,
//                               QString mediumTitle,
//                               QString contextualBanner,
//                               UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE state,
//                               UIBridge::E_HMI_EVENT_CHANNEL_TYPE channelType,
//                               QString categoryUrl)
//{
//    m_name = name;
//    m_shortDescription = shortDescription;
//    m_id = id;
//    m_number = number;
//    m_sid = sid;
//    m_isAvailable = isAvailable;
//    m_isFavorite = isFavorite;
//    m_isPlayByPlay = isPlayByPlay;
//    m_isSatOnly = isSatOnly;
//    m_isFreeToAir = isFreeToAir;
//    m_isSubscribed = isSubscribed;
//    m_isNowPlaying = isNowPlaying;
//    m_category = category;
//    m_logo = logo;
//    m_artistName = artistName;
//    m_songName = songName;
//    m_artUrl = artUrl;
//    m_mediumTitle = mediumTitle;
//    m_sportState = state;
//    m_contextualBanner = contextualBanner;
//    m_categoryLogoUrl = categoryUrl;
//    m_channelType = channelType;
//}

void ChannelElements::setValue(CHANNEL_INFORMATION_T& stChannelInfomation)
{
    m_name = stChannelInfomation.name;
    m_shortDescription = stChannelInfomation.shortDescription;
    m_id = stChannelInfomation.id;
    m_number = stChannelInfomation.number;
    m_sid = stChannelInfomation.sid;
    m_isAvailable = stChannelInfomation.isAvailable;
    m_isFavorite = stChannelInfomation.isFavorite;
    m_isPlayByPlay = stChannelInfomation.isPlayByPlay;
    m_isSatOnly = stChannelInfomation.isSatOnly;
    m_isFreeToAir = stChannelInfomation.isFreeToAir;
    m_isSubscribed = stChannelInfomation.isSubscribed;
    m_isNowPlaying = stChannelInfomation.isNowPlaying;
    m_category = stChannelInfomation.category;
    m_logo = stChannelInfomation.logoUrl;
    m_artistName = stChannelInfomation.album.artistName;
    m_songName = stChannelInfomation.album.songName;
    m_artUrl = stChannelInfomation.album.artUrl;
    m_mediumTitle = stChannelInfomation.show.mediumTitle;
    m_sportState = static_cast<UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE>(stChannelInfomation.sports.state);
    m_contextualBanner = stChannelInfomation.show.contextualBanner;
    m_categoryLogoUrl = stChannelInfomation.album.categoryLogoUrl;
    m_channelType = static_cast<UIBridge::E_HMI_EVENT_CHANNEL_TYPE>(stChannelInfomation.type);
    m_isFavoriteArtist = stChannelInfomation.album.isFavoriteArtist;
    m_isFavoriteSong= stChannelInfomation.album.isFavoriteSong;
}

bool ChannelElements::isFavoriteSong() const
{
    return m_isFavoriteSong;
}

void ChannelElements::setIsFavoriteSong(bool isFavoriteSong)
{
    if(m_isFavoriteSong == isFavoriteSong){
        return;
    }
    m_isFavoriteSong = isFavoriteSong;
    emit channelInfomationsChanged();
}

bool ChannelElements::isFavoriteArtist() const
{
    return m_isFavoriteArtist;
}

void ChannelElements::setIsFavoriteArtist(bool isFavoriteArtist)
{
    if(m_isFavoriteArtist == isFavoriteArtist){
        return;
    }
    m_isFavoriteArtist = isFavoriteArtist;
    emit channelInfomationsChanged();
}

UIBridge::E_HMI_EVENT_CHANNEL_TYPE ChannelElements::channelType() const
{
    return m_channelType;
}

void ChannelElements::setChannelType(const UIBridge::E_HMI_EVENT_CHANNEL_TYPE &channelType)
{
    if(m_channelType == channelType){
        return;
    }
    m_channelType = channelType;
    emit channelInfomationsChanged();
}
