#include "SongArtistAlertElement.h"

SongArtistAlertElement::SongArtistAlertElement()
{

}

SongArtistAlertElement::~SongArtistAlertElement()
{

}

QString SongArtistAlertElement::alertName() const
{
    return m_alertName;
}

void SongArtistAlertElement::setAlertName(const QString &alertName)
{
    m_alertName = alertName;
}

int SongArtistAlertElement::alertType() const
{
    return static_cast<int>(m_alertType);
}

void SongArtistAlertElement::setAlertType(const uint8_t &alertType)
{
    m_alertType = alertType;
}
