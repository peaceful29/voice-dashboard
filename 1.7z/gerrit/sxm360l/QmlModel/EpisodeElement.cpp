#include "EpisodeElement.h"


EpisodeElement::EpisodeElement()
{

}

EpisodeElement::~EpisodeElement()
{

}

QString EpisodeElement::tittle() const
{
    return m_tittle;
}

void EpisodeElement::setTittle(const QString &tittle)
{
    m_tittle = tittle;
}

QString EpisodeElement::shortDes() const
{
    return m_shortDes;
}

void EpisodeElement::setShortDes(const QString &shortDes)
{
    m_shortDes = shortDes;
}

QString EpisodeElement::episodeGuid() const
{
    return m_episodeGuid;
}

void EpisodeElement::setEpisodeGuid(const QString &episodeGuid)
{
    m_episodeGuid = episodeGuid;
}

QString EpisodeElement::contextual() const
{
    return m_contextual;
}

void EpisodeElement::setContextual(const QString &contextual)
{
    m_contextual = contextual;
}

bool EpisodeElement::isLive() const
{
    return m_isLive;
}

void EpisodeElement::setIsLive(bool isLive)
{
    m_isLive = isLive;
}

bool EpisodeElement::isHighlighted() const
{
    return m_isHighlighted;
}

void EpisodeElement::setIsHighlighted(bool isHighlighted)
{
    m_isHighlighted = isHighlighted;
}

bool EpisodeElement::isHot() const
{
    return m_isHot;
}

void EpisodeElement::setIsHot(bool isHot)
{
    m_isHot = isHot;
}

bool EpisodeElement::isSpecial() const
{
    return m_isSpecial;
}

void EpisodeElement::setIsSpecial(bool isSpecial)
{
    m_isSpecial = isSpecial;
}

uint32_t EpisodeElement::percentConsumed() const
{
    return m_percentConsumed;
}

void EpisodeElement::setPercentConsumed(const uint32_t &percentConsumed)
{
    m_percentConsumed = percentConsumed;
}

bool EpisodeElement::isValuable() const
{
    return m_isValuable;
}

void EpisodeElement::setIsValuable(bool isValuable)
{
    m_isValuable = isValuable;
}
