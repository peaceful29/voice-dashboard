#include "PagingBaseListModel.h"

PagingBaseListModel::PagingBaseListModel(QObject *parent)
    : BaseListModel(parent)
    , m_numItemOnPage(0)
    , m_currentIndex(0)
{

}

PagingBaseListModel::~PagingBaseListModel()
{

}

void PagingBaseListModel::configurePaging(int numItemOnPage)
{
    m_numItemOnPage = numItemOnPage;
}

int PagingBaseListModel::getNumItemOnPage() const
{
    return m_numItemOnPage;
}


int PagingBaseListModel::nextPage()
{
    int numElements = m_elements.count();
    int nextPos = m_currentIndex + m_numItemOnPage;
    if (nextPos > numElements){
        return -1;
    }
    int remainElements = numElements - nextPos;
    if (remainElements < m_numItemOnPage)
        nextPos = numElements - m_numItemOnPage;
    m_currentIndex = nextPos;
    return nextPos;

}

int PagingBaseListModel::previousPage()
{
    int numElements = m_elements.count();
    int previousPos = m_currentIndex - m_numItemOnPage;
    if (previousPos < 0)
        previousPos = 0;
    m_currentIndex = previousPos;
    return previousPos;
}

int PagingBaseListModel::pageNavigation(const E_VIDEO_TUNER_PAGE_NAVIGATION direction)
{
    int result = -1;
    switch (direction) {
    case E_VIDEO_TUNER_PAGE_NAVIGATION_UP:
        result = previousPage();
        break;
    case E_VIDEO_TUNER_PAGE_NAVIGATION_DOWN:
        result = nextPage();
        break;
    default:
        result = -1;
        break;
    }
    return result;
}

int PagingBaseListModel::requestToHighLight(const int32_t lineNum)
{
   if (lineNum == 0){
       return -1;
   }

   int absoluteIdx = m_currentIndex + lineNum - 1;
   if (absoluteIdx >= m_elements.count())
       absoluteIdx = -1;
   return absoluteIdx;
}

int PagingBaseListModel::highLightItem(const int32_t absoluteIdx)
{
    return absoluteIdx;
}

int PagingBaseListModel::getLineNumber(const int absoluteIdx)
{
    int lineNum = absoluteIdx + 1 - m_currentIndex;
    return lineNum;
}

void PagingBaseListModel::setCurrentIndex(const int currentInd)
{
    m_currentIndex = currentInd;
}

void PagingBaseListModel::reset()
{
    m_currentIndex = 0;
    BaseListModel::reset();
}


