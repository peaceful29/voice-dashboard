#ifndef ALERTLISTMODEL_H
#define ALERTLISTMODEL_H

#include <QObject>
#include "BaseListModel.h"
#include "SongArtistAlertElement.h"
#include "SXMDefine.h"

class AlertListModel: public BaseListModel
{
    Q_OBJECT
public:
    explicit AlertListModel(QObject* parent = nullptr);
    ~AlertListModel();

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    virtual QHash<int, QByteArray> roleNames() const;
    Q_INVOKABLE void remove(int idx);

protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // ALERTLISTMODEL_H
