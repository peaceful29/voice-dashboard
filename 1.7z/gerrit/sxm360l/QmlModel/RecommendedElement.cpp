#include "RecommendedElement.h"

RecommendedElement::RecommendedElement()
{
}

RecommendedElement::~RecommendedElement()
{
}

QString RecommendedElement::mediumTitle() const
{
    return m_mediumTitle;
}

void RecommendedElement::setMediumTitle(const QString &mediumTitle)
{
    m_mediumTitle = mediumTitle;
}

QString RecommendedElement::longTitle() const
{
    return m_longTitle;
}

void RecommendedElement::setLongTitle(const QString &longTitle)
{
    m_longTitle = longTitle;
}

QString RecommendedElement::shortDes() const
{
    return m_shortDes;
}

void RecommendedElement::setShortDes(const QString &shortDes)
{
    m_shortDes = shortDes;
}

QString RecommendedElement::showGui() const
{
    return m_showGui;
}

void RecommendedElement::setShowGui(const QString &showGui)
{
    m_showGui = showGui;
}

PROGRAM_TYPE RecommendedElement::programType() const
{
    return m_programType;
}

void RecommendedElement::setProgramType(const PROGRAM_TYPE &programType)
{
    m_programType = programType;
}

uint32_t RecommendedElement::audioEpisode() const
{
    return m_audioEpisode;
}

void RecommendedElement::setAudioEpisode(const uint32_t &audioEpisode)
{
    m_audioEpisode = audioEpisode;
}

uint32_t RecommendedElement::videoEpisode() const
{
    return m_videoEpisode;
}

void RecommendedElement::setVideoEpisode(const uint32_t &videoEpisode)
{
    m_videoEpisode = videoEpisode;
}

uint32_t RecommendedElement::newEpisodeCount() const
{
    return m_newEpisodeCount;
}

void RecommendedElement::setNewEpisodeCount(const uint32_t &newEpisodeCount)
{
    m_newEpisodeCount = newEpisodeCount;
}

QString RecommendedElement::contextual() const
{
    return m_contextual;
}

void RecommendedElement::setContextual(const QString &contextual)
{
    m_contextual = contextual;
}

bool RecommendedElement::isMature() const
{
    return m_isMature;
}

void RecommendedElement::setIsMature(bool isMature)
{
    m_isMature = isMature;
}

uint32_t RecommendedElement::episodeCount() const
{
    return m_episodeCount;
}

void RecommendedElement::setEpisodeCount(const uint32_t &episodeCount)
{
    m_episodeCount = episodeCount;
}
