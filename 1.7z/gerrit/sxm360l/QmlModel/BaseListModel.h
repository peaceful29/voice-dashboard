#ifndef BASELISTMODEL_H
#define BASELISTMODEL_H

#include <QObject>
#include <QModelIndex>
#include <QAbstractListModel>
#include "ModelDefine.h"
#include "ResourceManager.h"
#include "DataController.h"

class BaseListModel : public QAbstractListModel
{
    Q_OBJECT
public:
    explicit BaseListModel(QObject *parent = nullptr);
    virtual ~BaseListModel();

    //Append data to the end of list
    void appendData(BaseElementPtr element);

    //Data is ready for Qml update
    virtual void onDataReady();

    //Number of elements
    int rowCount(const QModelIndex & parent = QModelIndex()) const override;

    //Clear list and Qml update
    virtual void reset();

    //Get element at index position
    BaseElement* getElement(const int index);

    //Update property of element with specific role
    void updateData(int idx, int role, QVariant value);

    //Update property of element with roles
    void updateData(int idx, QMap<int, QVariant> &roleValues);

    //Insert Data in idx position
    void insertData(BaseElementPtr element, int idx);

    //Remove element in idx position
    void removeData(int idx);

    //Mode element from src position to dst position
    void moveData(int src, int dst);

    //Get elements
    QList<BaseElementPtr>& getElements();

    //Get new elements
    QList<BaseElementPtr>& getNewElements();

    void dataUpdated();

protected:
    QList<BaseElementPtr> m_elements;
    QList<BaseElementPtr> m_newElements;
};

#endif // BASELISTMODEL_H
