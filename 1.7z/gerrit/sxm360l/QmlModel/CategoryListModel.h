#ifndef CATEGORYLISTMODEL_H
#define CATEGORYLISTMODEL_H

#include <QObject>
#include "BaseListModel.h"

class CategoryListModel : public BaseListModel
{
    Q_OBJECT
public:
    explicit CategoryListModel(QObject* parent = nullptr);
    ~CategoryListModel();

    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;
    virtual QHash<int,QByteArray> roleNames() const;
protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // CATEGORYLISTMODEL_H
