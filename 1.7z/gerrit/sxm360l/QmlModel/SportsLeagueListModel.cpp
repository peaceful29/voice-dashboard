#include "SportsLeagueListModel.h"
#include "SportsLeagueElements.h"
#include "SXMDefine.h"

SportsLeagueListModel::SportsLeagueListModel(QObject *parent): BaseListModel(parent)
{

}

SportsLeagueListModel::~SportsLeagueListModel()
{

}

QVariant SportsLeagueListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    SportsLeagueElementsPtr element = std::dynamic_pointer_cast<SportsLeagueElements>(m_elements[index.row()]);
    if (element == nullptr)
        return QVariant();
    switch (role) {
    case E_LEAGUE_NAME:
        return element->leagueName();
    case E_LEAGUE_LOGO:
        return element->leagueLogo();
    case E_LEAGUE_ID:
        return element->leagueId();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> SportsLeagueListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_LEAGUE_NAME] = "name";
    roles[E_LEAGUE_LOGO] = "logoUrl";
    roles[E_LEAGUE_ID] = "id";

    return roles;
}

void SportsLeagueListModel::remove(int idx)
{
    if (idx < m_elements.size()) {
        beginRemoveRows(QModelIndex(), idx, idx);
        BaseElementPtr element = m_elements.takeAt(idx);
        Q_UNUSED(element)
        endRemoveRows();
    }
}

bool SportsLeagueListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if(index.isValid() && (index.row() < m_elements.size())) {
        SportsLeagueElementsPtr element = std::dynamic_pointer_cast<SportsLeagueElements>(m_elements[index.row()]);
        switch (role) {
        case E_LEAGUE_NAME:
            element->setLeagueName(value.toString());
            break;
        case E_LEAGUE_LOGO:
            element->setLeagueLogo(value.toString());
            break;
        case E_LEAGUE_ID:
            element->setLeagueId(value.toInt());
            break;
        default:
            ret = false;
            break;
        }
    }
    return ret;
}
