#ifndef FAVORITESLISTELEMENTS_H
#define FAVORITESLISTELEMENTS_H

#include "BaseElement.h"
#include "ChannelElements.h"

class FavoritesListElements : public ChannelElements
{
public:
    FavoritesListElements();
    ~FavoritesListElements();

    int favType() const;
    void setFavType(int favType);

    QString favName() const;
    void setFavName(const QString &favName);

    QString favId() const;
    void setFavId(const QString &favId);

    QString favBanner() const;
    void setFavBanner(const QString &favBanner);

//    ChannelElementPtr channelElement() const;
//    void setChannelElement(const ChannelElementPtr &channelElement);

private:
    int m_favType;
    QString m_favName;
    QString m_favId;
    QString m_favBanner;
//    ChannelElementPtr m_channelElement;
};
typedef std::shared_ptr<FavoritesListElements> FavoritesListElementsPtr;

#endif // FAVORITESLISTELEMENTS_H
