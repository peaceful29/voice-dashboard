#ifndef SPORTINFORMATIONLISTMODEL_H
#define SPORTINFORMATIONLISTMODEL_H

#include <QObject>
#include "BaseListModel.h"
#include "SportInformationElement.h"

class SportInformationListModel : public BaseListModel
{
public:
    SportInformationListModel();
    ~SportInformationListModel();

    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;
    virtual QHash<int,QByteArray> roleNames() const;
protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // SPORTINFORMATIONLISTMODEL_H
