#include "TeamListModel.h"
#include "Common/SXMDefine.h"

TeamListModel::TeamListModel(QObject *parent)
    : PagingBaseListModel(parent)
{
}

TeamListModel::~TeamListModel()
{

}

QVariant TeamListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    TeamPtr element = std::dynamic_pointer_cast<TeamElement>(m_elements[index.row()]);
    if (element == nullptr)
        return QVariant();
    switch (role) {
    case E_TEAM_NAME:
        return element->name();
    case E_TEAM_LOGO:
        return element->logoUrl();
    case E_TEAM_ID:
        return element->id();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> TeamListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_TEAM_NAME] = "name";
    roles[E_TEAM_LOGO] = "logoUrl";
    roles[E_TEAM_ID] = "id";

    return roles;
}

bool TeamListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if(index.isValid() && (index.row() < m_elements.size())) {
        TeamPtr element = std::dynamic_pointer_cast<TeamElement>(m_elements[index.row()]);
        switch (role) {
        case E_TEAM_NAME:
            element->setName(value.toString());
            break;
        case E_TEAM_LOGO:
            element->setlogoUrl(value.toString());
            break;
        case E_TEAM_ID:
            element->setId(value.toInt());
            break;
        default:
            ret = false;
            break;
        }
    }
    return ret;
}
