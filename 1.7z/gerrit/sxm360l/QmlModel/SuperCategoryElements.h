#ifndef SUPERCATEGORYELEMENTS_H
#define SUPERCATEGORYELEMENTS_H

#include "BaseElement.h"

class SuperCategoryElements : public BaseElement
{
public:
    SuperCategoryElements();
    virtual ~SuperCategoryElements();

    QString superCategoryName() const;
    void setSuperCategoryName(const QString &superCategoryName);

    bool isCurrent() const;
    void setIsCurrent(bool isCurrent);

private:
    QString m_superCategoryName;
    bool    m_isCurrent;
};
typedef std::shared_ptr<SuperCategoryElements> SuperCategoryElementsPtr;

#endif // SUPERCATEGORYELEMENTS_H
