#include "VoiceTunerChannelList.h"
#include <iostream>
#include <QList>

VoiceTunerChannelList::VoiceTunerChannelList(QObject *parent)
    : QAbstractListModel(parent)
{
}

VoiceTunerChannelList::VoiceTunerChannelList(const VoiceTunerChannelList &m)
{
    m_model=m.m_model;
}


VoiceTunerChannelList::~VoiceTunerChannelList()
{
    std::cout << "Ended" << std::endl;
}

void VoiceTunerChannelList::addItem(const NumberedListModel &item)
{
    beginInsertRows(QModelIndex(), rowCount(), rowCount());
    m_model << item;
    endInsertRows();
}

void VoiceTunerChannelList::removeItem(int i)
{
    beginRemoveRows(QModelIndex(),i,i);
    if(!m_model.isEmpty())
    {
        m_model.removeAt(i);
    }
    else
    {
        std::cout << "List is empty" << std::endl;
    }
    endRemoveRows();
}

int VoiceTunerChannelList::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return m_model.count();
}

QVariant VoiceTunerChannelList::data(const QModelIndex &index, int role) const
{
    if ((index.row()<0) || (index.row()) >= m_model.count())
        return QVariant();
    const NumberedListModel &obj = m_model[index.row()];
    if (role == NameRole)
        return obj.getName();
    else if (role == ImageSrcRole)
        return obj.getImageSrc();
    else if (role == IndxRole)
        return obj.getIndx();
    return QVariant();
}

QHash<int, QByteArray> VoiceTunerChannelList::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[NameRole] = "name";
    roles[ImageSrcRole] = "imgSrc";
    roles[IndxRole] = "Indx";
    return roles;
}



