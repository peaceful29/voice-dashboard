#ifndef TEAMALERTELEMENTS_H
#define TEAMALERTELEMENTS_H

#include "BaseElement.h"

class TeamAlertElements : public BaseElement
{
public:
    TeamAlertElements();
    virtual ~TeamAlertElements();

    int teamId() const;
    void setTeamId(int teamId);

    QString teamName() const;
    void setTeamName(const QString &teamName);

    QString teamLogo() const;
    void setTeamLogo(const QString &teamLogo);

private:
    int m_teamId;
    QString m_teamName;
    QString m_teamLogo;
};
typedef std::shared_ptr<TeamAlertElements> TeamAlertElementsPtr;
#endif // TEAMALERTELEMENTS_H
