#ifndef MODELDEFINE_H
#define MODELDEFINE_H

#include <memory>
class BaseElement;

typedef std::shared_ptr<BaseElement> BaseElementPtr;


#endif // MODELDEFINE_H
