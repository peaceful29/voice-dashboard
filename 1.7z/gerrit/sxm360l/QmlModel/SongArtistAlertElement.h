#ifndef SONGARTISTALERTELEMENT_H
#define SONGARTISTALERTELEMENT_H

#include "BaseElement.h"

class SongArtistAlertElement: public BaseElement
{
public:
    SongArtistAlertElement();
    ~SongArtistAlertElement();

    QString alertName() const;
    void setAlertName(const QString &alertName);

    int alertType() const;
    void setAlertType(const uint8_t &alertType);

private:
    QString m_alertName;
    uint8_t m_alertType;
};

typedef std::shared_ptr<SongArtistAlertElement> SongArtistAlertElementPtr;

#endif // SONGARTISTALERTELEMENT_H
