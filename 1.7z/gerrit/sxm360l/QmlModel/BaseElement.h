#ifndef BASEELEMENT_H
#define BASEELEMENT_H

#include <QObject>
#include <memory>

class BaseElement : public QObject
{
    Q_OBJECT
public:
    virtual ~BaseElement() {}
};

#endif // BASEELEMENT_H
