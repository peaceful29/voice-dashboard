#include "VideoTunerListShowElement.h"

VideoTunerListShowElement::VideoTunerListShowElement()
    : m_nameComp("")
    , m_indexComp("")
    , m_imagePathComp("")
    , m_isHighLight(false)
{

}

VideoTunerListShowElement::~VideoTunerListShowElement()
{

}

QString VideoTunerListShowElement::nameComp() const
{
    return m_nameComp;
}

void VideoTunerListShowElement::setNameComp(const QString &name)
{
    m_nameComp = name;
}

QString VideoTunerListShowElement::indexComp() const
{
    return m_indexComp;
}

void VideoTunerListShowElement::setIndexComp(const QString index)
{
    m_indexComp = index;
}

QString VideoTunerListShowElement::imagePathComp() const
{
    return m_imagePathComp;
}

void VideoTunerListShowElement::setImagePathComp(QString path)
{
    m_imagePathComp = path;
}

bool VideoTunerListShowElement::isHighLight() const
{
    return m_isHighLight;
}

void VideoTunerListShowElement::setHighLight(const bool isHighLight)
{
    m_isHighLight = isHighLight;
}


