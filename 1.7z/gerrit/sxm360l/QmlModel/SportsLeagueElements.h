#ifndef SPORTSLEAGUEELEMENTS_H
#define SPORTSLEAGUEELEMENTS_H

#include "BaseElement.h"

class SportsLeagueElements : public BaseElement
{
public:
    SportsLeagueElements();
    virtual ~SportsLeagueElements();

    int leagueId() const;
    void setLeagueId(int leagueId);

    QString leagueName() const;
    void setLeagueName(const QString &leagueName);

    QString leagueLogo() const;
    void setLeagueLogo(const QString &leagueLogo);

private:
    int m_leagueId;
    QString m_leagueName;
    QString m_leagueLogo;
};
typedef std::shared_ptr<SportsLeagueElements> SportsLeagueElementsPtr;
#endif // SPORTSLEAGUEELEMENTS_H
