#ifndef VIDEOTUNERLISTSHOWELEMENT_H
#define VIDEOTUNERLISTSHOWELEMENT_H

#include "BaseElement.h"

class VideoTunerListShowElement : public BaseElement
{
public:
    VideoTunerListShowElement();
    virtual ~VideoTunerListShowElement();

    QString nameComp() const;
    void setNameComp(const QString &name);

    QString indexComp() const;
    void setIndexComp(const QString index);

    QString imagePathComp() const;
    void setImagePathComp(QString path);

    bool isHighLight() const;
    void setHighLight(const bool isHighLight);
private:
    QString m_nameComp;
    QString m_indexComp;
    QString m_imagePathComp;
    bool m_isHighLight;

};

typedef std::shared_ptr<VideoTunerListShowElement> VideoTunerListShowElementPtr;

#endif // VIDEOTUNERLISTSHOWELEMENT_H
