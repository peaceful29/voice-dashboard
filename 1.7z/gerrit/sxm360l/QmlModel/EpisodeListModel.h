#ifndef EPISODE_H
#define EPISODE_H

#include <QObject>
#include "BaseListModel.h"

class EpisodeListModel : public BaseListModel
{
    Q_OBJECT
public:
    explicit EpisodeListModel(QObject* parent = nullptr);
    ~EpisodeListModel();

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    virtual QHash<int, QByteArray> roleNames() const;

protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // EPISODE_H