#ifndef PAGINGBASELISTMODEL_H
#define PAGINGBASELISTMODEL_H

#include "BaseListModel.h"
#include "SXMDefine.h"

class PagingBaseListModel : public BaseListModel
{
public:
    explicit PagingBaseListModel(QObject *parent = nullptr);
    virtual ~PagingBaseListModel();

    void configurePaging(int numItemOnPage);
    int getNumItemOnPage() const;
    void setCurrentIndex(const int currentInd);
    virtual void reset();


    int nextPage();
    int previousPage();
    int pageNavigation(const E_VIDEO_TUNER_PAGE_NAVIGATION direction);
    int requestToHighLight(const int32_t lineNum);
    int highLightItem(const int32_t absoluteIdx);
    int getLineNumber(const int absoluteIdx);

private:
    int m_numItemOnPage;
    int m_currentIndex;
};

#endif // PAGINGBASELISTMODEL_H
