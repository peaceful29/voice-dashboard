#include "BaseListModel.h"

BaseListModel::BaseListModel(QObject *parent)
    : QAbstractListModel(parent)
{

}

BaseListModel::~BaseListModel()
{
    m_elements.clear();
    m_newElements.clear();
}

void BaseListModel::appendData(BaseElementPtr element)
{
    m_newElements.append(element);
}

void BaseListModel::onDataReady()
{
    //Insert new item to current list
    beginResetModel();
    int count = m_newElements.count();
    for (int i = 0; i < count; i++)
        m_elements.append(m_newElements.at(i));
    m_newElements.clear();
    endResetModel();
}

int BaseListModel::rowCount(const QModelIndex & parent) const
{
    Q_UNUSED(parent);
    return m_elements.size();
}

void BaseListModel::reset()
{
    beginResetModel();
    m_elements.clear();
    m_newElements.clear();
    endResetModel();
}

BaseElement* BaseListModel::getElement(const int index)
{
    BaseElement* ret = nullptr;
    if ((index >= 0) && (index < m_elements.size())){
        ret = m_elements[index].get();
    }
    return ret;
}

void BaseListModel::updateData(int idx, int role, QVariant value)
{
    if ((idx >= 0) && (idx < m_elements.size())){
        bool ret = setData(index(idx, 0), value, role);
        if (ret == true){
            emit dataChanged(index(idx, 0), index(idx, 0));
        }
    }
}

void  BaseListModel::updateData(int idx, QMap<int, QVariant> &roleValues)
{
    if ((idx >= 0) && (idx < m_elements.size())){
        QMap<int, QVariant>::iterator it = roleValues.begin();
        bool ret = true;
        for (; it != roleValues.end(); ++it){
            bool partSuccess = setData(index(idx, 0), it.value(), it.key());
            ret = ret && partSuccess;
        }
        if (ret == true){
            emit dataChanged(index(idx, 0), index(idx, 0));
        }
    }
}

void BaseListModel::insertData(BaseElementPtr element, int idx)
{
    beginInsertRows(QModelIndex(), idx, idx);
    m_elements.insert(idx, element);
    endInsertRows();
}

void BaseListModel::removeData(int idx)
{
    if (idx < m_elements.size()) {
        beginRemoveRows(QModelIndex(), idx, idx);
        BaseElementPtr element = m_elements.takeAt(idx);
        Q_UNUSED(element)
        endRemoveRows();
    }
}

//void BaseListModel::dataUpdated()
//{
//    beginResetModel();
//    endResetModel();
//}

void BaseListModel::moveData(int src, int dst)
{
    if (0 <= src && src < m_elements.size() && 0 <= dst && dst < m_elements.size() && src != dst) {
        beginMoveRows(QModelIndex(), src, src, QModelIndex(), dst);
        m_elements.move(src, dst);
        endMoveRows();
    }
}

QList<BaseElementPtr>& BaseListModel::getElements()
{
    return m_elements;
}

QList<BaseElementPtr>& BaseListModel::getNewElements()
{
    return m_newElements;
}
