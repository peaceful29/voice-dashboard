#ifndef VOICETUNERCHANNELLIST_H
#define VOICETUNERCHANNELLIST_H

#include <QAbstractListModel>
#include "NumberedListModel.h"

class VoiceTunerChannelList : public QAbstractListModel
{
    Q_OBJECT
public:
    VoiceTunerChannelList(QObject *parent=0);
    VoiceTunerChannelList(const VoiceTunerChannelList&m);
    ~VoiceTunerChannelList();
    enum DataRoles {
        NameRole = Qt::UserRole +1,
        ImageSrcRole,
        IndxRole
    };
public slots:
    void addItem(const NumberedListModel &item);
    void removeItem(int i);

private:
    int rowCount(const QModelIndex &parent  = QModelIndex()) const;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    QHash<int, QByteArray> roleNames() const;
    QList<NumberedListModel> m_model;
};

#endif // VOICETUNERCHANNELLIST_H
