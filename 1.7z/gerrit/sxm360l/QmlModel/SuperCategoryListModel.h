#ifndef SXMSUPERCATEGORYLISTMODEL_H
#define SXMSUPERCATEGORYLISTMODEL_H

#include <QObject>
#include "BaseListModel.h"

class SuperCategoryListModel : public BaseListModel
{
    Q_OBJECT
public:
    explicit SuperCategoryListModel(QObject* parent = nullptr);
    ~SuperCategoryListModel();

    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;
    virtual QHash<int,QByteArray> roleNames() const;

protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // SXMSUPERCATEGORYLISTMODEL_H
