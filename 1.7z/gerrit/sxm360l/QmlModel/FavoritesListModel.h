#ifndef FAVORITESLISTMODEL_H
#define FAVORITESLISTMODEL_H

#include <QObject>
#include "BaseListModel.h"
#include "FavoritesListElements.h"
#include "Common/SXMDefine.h"

class FavoritesListModel : public BaseListModel
{
    Q_OBJECT
public:
    explicit FavoritesListModel(QObject* parent = nullptr);
    ~FavoritesListModel();

    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;
    virtual QHash<int,QByteArray> roleNames() const;
    Q_INVOKABLE void move(int src, int dst);
    Q_INVOKABLE void remove(int idx);
//    Q_INVOKABLE int rowCount(const QModelIndex & parent = QModelIndex()) const override;

protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // FAVORITESLISTMODEL_H
