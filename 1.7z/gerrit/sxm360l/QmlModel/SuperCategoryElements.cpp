#include "SuperCategoryElements.h"

SuperCategoryElements::SuperCategoryElements() : m_superCategoryName("")
{

}

SuperCategoryElements::~SuperCategoryElements()
{

}

QString SuperCategoryElements::superCategoryName() const
{
    return m_superCategoryName;
}

void SuperCategoryElements::setSuperCategoryName(const QString &superCategoryName)
{
    m_superCategoryName = superCategoryName;
}

bool SuperCategoryElements::isCurrent() const
{
    return m_isCurrent;
}

void SuperCategoryElements::setIsCurrent(bool isCurrent)
{
    m_isCurrent = isCurrent;
}
