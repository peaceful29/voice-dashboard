#include "TeamAlertListModel.h"
#include "SXMDefine.h"
#include "TeamAlertElements.h"
TeamAlertListModel::TeamAlertListModel(QObject *parent): BaseListModel(parent)
{

}

TeamAlertListModel::~TeamAlertListModel()
{

}

QVariant TeamAlertListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    TeamAlertElementsPtr element = std::dynamic_pointer_cast<TeamAlertElements>(m_elements[index.row()]);
    if (element == nullptr)
        return QVariant();
    switch (role) {
    case E_TEAM_NAME:
        return element->teamName();
    case E_TEAM_LOGO:
        return element->teamLogo();
    case E_TEAM_ID:
        return element->teamId();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> TeamAlertListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_TEAM_NAME] = "name";
    roles[E_TEAM_LOGO] = "logoUrl";
    roles[E_TEAM_ID] = "id";

    return roles;
}

void TeamAlertListModel::remove(int idx)
{
    if (idx < m_elements.size()) {
        beginRemoveRows(QModelIndex(), idx, idx);
        BaseElementPtr element = m_elements.takeAt(idx);
        Q_UNUSED(element)
        endRemoveRows();
    }
}

bool TeamAlertListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if(index.isValid() && (index.row() < m_elements.size())) {
        TeamAlertElementsPtr element = std::dynamic_pointer_cast<TeamAlertElements>(m_elements[index.row()]);
        switch (role) {
        case E_TEAM_NAME:
            element->setTeamName(value.toString());
            break;
        case E_TEAM_LOGO:
            element->setTeamLogo(value.toString());
            break;
        case E_TEAM_ID:
            element->setTeamId(value.toInt());
            break;
        default:
            ret = false;
            break;
        }
    }
    return ret;
}
