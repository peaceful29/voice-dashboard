#include "CategoryElements.h"

CategoryElements::CategoryElements()
    : m_categoryName("")
    , m_categoryLogo("")
{

}

CategoryElements::~CategoryElements()
{

}

QString CategoryElements::categoryName() const
{
    return m_categoryName;
}

void CategoryElements::setCategoryName(const QString &categoryName)
{
    m_categoryName = categoryName;
}

QString CategoryElements::categoryLogo() const
{
    return m_categoryLogo;
}

void CategoryElements::setCategoryLogo(const QString &categoryLogo)
{
    m_categoryLogo = categoryLogo;
}

int32_t CategoryElements::categoryId() const
{
    return m_Id;
}

void CategoryElements::setCategoryId(const int32_t &categoryId)
{
    m_Id = categoryId;
}
