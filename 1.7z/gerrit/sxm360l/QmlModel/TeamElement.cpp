#include "TeamElement.h"

TeamElement::TeamElement()
{
}

TeamElement::~TeamElement()
{
}
QString TeamElement::name() const
{
    return m_name;
}

void TeamElement::setName(const QString &teamName)
{
    m_name = teamName;
}

QString TeamElement::logoUrl() const
{
    return m_logoUrl;
}

void TeamElement::setlogoUrl(const QString &url)
{
    m_logoUrl = url;
}

int TeamElement::id() const
{
    return m_id;
}

void TeamElement::setId(int id)
{
    m_id = id;
}
