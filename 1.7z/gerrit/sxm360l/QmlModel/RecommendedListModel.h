#ifndef RECOMMENDED_H
#define RECOMMENDED_H

#include <QObject>
#include "BaseListModel.h"

class RecommendedListModel : public BaseListModel
{
    Q_OBJECT
public:
    explicit RecommendedListModel(QObject* parent = nullptr);
    ~RecommendedListModel();

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    virtual QHash<int, QByteArray> roleNames() const;

protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // RECOMMENDED_H