#include "EpisodeListModel.h"
#include "Common/SXMDefine.h"
#include "EpisodeElement.h"

EpisodeListModel::EpisodeListModel(QObject *parent)
    : BaseListModel(parent)
{
}

EpisodeListModel::~EpisodeListModel()
{

}

QVariant EpisodeListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    EpisodeElementPtr element = std::dynamic_pointer_cast<EpisodeElement>(m_elements[index.row()]);
    switch (role) {
    case E_EPISODE_TITLE:
        return element->tittle();
    case E_EPISODE_SHORT_DESCRIPTION:
        return element->shortDes();
    case E_EPISODE_GUID:
        return element->episodeGuid();
    case E_EPISODE_CONTEXTUAL:
        return element->contextual();
    case E_EPISODE_IS_LIVE:
        return element->isLive();
    case E_EPISODE_IS_HIGHLIGHTED:
        return element->isHighlighted();
    case E_EPISODE_IS_HOT:
        return element->isHot();
    case E_EPISODE_IS_VALUABLE:
        return element->isValuable();
    case E_EPISODE_IS_SPECIAL:
        return element->isSpecial();
    case E_EPISODE_PERCENTCONSUMED:
        return element->percentConsumed();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> EpisodeListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_EPISODE_TITLE] = "title";
    roles[E_EPISODE_SHORT_DESCRIPTION] = "shortDescription";
    roles[E_EPISODE_GUID] = "episodeGuid";
    roles[E_EPISODE_CONTEXTUAL] = "contextual";
    roles[E_EPISODE_IS_LIVE] = "isLive";
    roles[E_EPISODE_IS_HIGHLIGHTED] = "isHighlighted";
    roles[E_EPISODE_IS_HOT] = "isHot";
    roles[E_EPISODE_IS_VALUABLE] = "isValuable";
    roles[E_EPISODE_IS_SPECIAL] = "isSpecial";
    roles[E_EPISODE_PERCENTCONSUMED] = "percentConsumed";
    return roles;
}

bool EpisodeListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if(index.isValid() && (index.row() < m_elements.size())) {
        EpisodeElementPtr element = std::dynamic_pointer_cast<EpisodeElement>(m_elements[index.row()]);
        switch (role) {
        case E_EPISODE_TITLE:
            element->setTittle(value.toString());
            break;
        case E_EPISODE_SHORT_DESCRIPTION:
            element->setShortDes(value.toString());
            break;
        case E_EPISODE_GUID:
            element->setEpisodeGuid(value.toString());
            break;
        case E_EPISODE_CONTEXTUAL:
            element->setContextual(value.toString());
            break;
        case E_EPISODE_IS_LIVE:
            element->setIsLive(value.toBool());
            break;
        case E_EPISODE_IS_HIGHLIGHTED:
            element->setIsHighlighted(value.toBool());
            break;
        case E_EPISODE_IS_HOT:
            element->setIsHot(value.toBool());
            break;
        case E_EPISODE_IS_VALUABLE:
            element->setIsValuable(value.toBool());
            break;
        case E_EPISODE_IS_SPECIAL:
            element->setIsSpecial(value.toBool());
            break;
        case E_EPISODE_PERCENTCONSUMED:
            element->setPercentConsumed(value.toInt());
            break;
        default:
            ret = false;
            break;
        }
    }
    return ret;
}
