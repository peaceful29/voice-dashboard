#ifndef CHANNELELEMENTS_H
#define CHANNELELEMENTS_H

#include "BaseElement.h"
#include "sxm360l/Sxm360lMsgDef.h"
#include "UIBridge.h"

class ChannelElements : public BaseElement
{
    Q_OBJECT
    Q_PROPERTY(QString name READ name WRITE setName NOTIFY channelInfomationsChanged)
    Q_PROPERTY(QString shortDescription READ shortDescription WRITE setShortDescription NOTIFY channelInfomationsChanged)
    Q_PROPERTY(unsigned int number READ number WRITE setNumber NOTIFY channelInfomationsChanged)
    Q_PROPERTY(unsigned int sid READ sid WRITE setSid NOTIFY channelInfomationsChanged)
    Q_PROPERTY(bool isAvailable READ isAvailable WRITE setIsAvailable NOTIFY channelInfomationsChanged)
    Q_PROPERTY(bool isFavorite READ isFavorite WRITE setIsFavorite NOTIFY channelInfomationsChanged)
    Q_PROPERTY(bool isPlayByPlay READ isPlayByPlay WRITE setIsPlayByPlay NOTIFY channelInfomationsChanged)
    Q_PROPERTY(bool isSatOnly READ isSatOnly WRITE setIsSatOnly NOTIFY channelInfomationsChanged)
    Q_PROPERTY(bool isFreeToAir READ isFreeToAir WRITE setIsFreeToAir NOTIFY channelInfomationsChanged)
    Q_PROPERTY(bool isSubscribed READ isSubscribed WRITE setIsSubscribed NOTIFY channelInfomationsChanged)
    Q_PROPERTY(bool isNowPlaying READ isNowPlaying WRITE setIsNowPlaying NOTIFY channelInfomationsChanged)
    Q_PROPERTY(QString category READ category WRITE setCategory NOTIFY channelInfomationsChanged)
    Q_PROPERTY(QString id READ id WRITE setId NOTIFY channelInfomationsChanged)
    Q_PROPERTY(QString logo READ logo WRITE setLogo NOTIFY channelInfomationsChanged)
    Q_PROPERTY(UIBridge::E_HMI_EVENT_CHANNEL_TYPE channelType READ channelType WRITE setChannelType NOTIFY channelInfomationsChanged)

    // for ALBUM_INFORMATION_T
    Q_PROPERTY(QString artistName READ artistName WRITE setArtistName NOTIFY channelInfomationsChanged)
    Q_PROPERTY(QString songName READ songName WRITE setSongName NOTIFY channelInfomationsChanged)
    Q_PROPERTY(QString artUrl READ artUrl WRITE setArtUrl NOTIFY channelInfomationsChanged)
    Q_PROPERTY(QString categoryLogoUrl READ categoryLogoUrl WRITE setCategoryLogoUrl NOTIFY channelInfomationsChanged)
    Q_PROPERTY(bool isFavoriteArtist READ isFavoriteArtist WRITE setIsFavoriteArtist NOTIFY channelInfomationsChanged)
    Q_PROPERTY(bool isFavoriteSong READ isFavoriteSong WRITE setIsFavoriteSong NOTIFY channelInfomationsChanged)

    // for RECOMMENDED_SHOW_T
    Q_PROPERTY(QString mediumTitle READ mediumTitle WRITE setMediumTitle NOTIFY channelInfomationsChanged)
//    Q_PROPERTY(QString shortDescription READ shortDescription WRITE setShortDescription NOTIFY channelInfomationsChanged)
    Q_PROPERTY(QString contextualBanner READ contextualBanner WRITE setContextualBanner NOTIFY channelInfomationsChanged)
//    Q_PROPERTY(QString liveChannelId READ liveChannelId WRITE setLiveChannelId NOTIFY channelInfomationsChanged)
    //Sport
    Q_PROPERTY(UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE sportState READ sportState WRITE setSportState NOTIFY channelInfomationsChanged)

public:
    ChannelElements();
    ~ChannelElements();

    QString name() const;
    void setName(const QString &name);
    QString shortDescription() const;
    void setShortDescription(const QString &shortDescription);
    QString category() const;
    void setCategory(const QString &category);
    QString id() const;
    void setId(const QString &id);
    QString logo() const;
    void setLogo(const QString &logo);
    QString artistName() const;
    void setArtistName(const QString &artistName);
    QString songName() const;
    void setSongName(const QString &songName);
    QString artUrl() const;
    void setArtUrl(const QString &artUrl);
    QString mediumTitle() const;
    void setMediumTitle(const QString &mediumTitle);
//    QString liveChannelId() const;
//    void setLiveChannelId(const QString &liveChannelId);
    QString contextualBanner() const;
    void setContextualBanner(const QString &contextualBanner);

    unsigned int deliveryState() const;
    void setDeliveryState(const unsigned int &deliveryState);
    int number() const;
    void setNumber(const int &number);
    unsigned int sid() const;
    void setSid(const unsigned int &sid);

    bool isAvailable() const;
    void setIsAvailable(const bool &isAvailable);
    bool isFavorite() const;
    void setIsFavorite(const bool &isFavorite);
    bool isPlayByPlay() const;
    void setIsPlayByPlay(const bool &isPlayByPlay);
    bool isSatOnly() const;
    void setIsSatOnly(const bool &isSatOnly);
    bool isFreeToAir() const;
    void setIsFreeToAir(const bool &isFreeToAir);
    bool isSubscribed() const;
    void setIsSubscribed(const bool &isSubscribed);
    bool isNowPlaying() const;
    void setIsNowPlaying(const bool &isNowPlaying);
    UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE sportState() const;
    void setSportState(const UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE sportState);
    QString categoryLogoUrl() const;
    void setCategoryLogoUrl(const QString &categoryLogoUrl);
    bool isFavoriteSong() const;
    void setIsFavoriteSong(bool isFavoriteSong);
    bool isFavoriteArtist() const;
    void setIsFavoriteArtist(bool isFavoriteArtist);

    UIBridge::E_HMI_EVENT_CHANNEL_TYPE channelType() const;
    void setChannelType(const UIBridge::E_HMI_EVENT_CHANNEL_TYPE &channelType);

public:
//    void setValue(QString name = "",
//                   QString shortDescription = "",
//                   unsigned int number = 0,
//                   unsigned int sid = 0,
//                   bool isAvailable = false,
//                   bool isFavorite = false,
//                   bool isPlayByPlay = false,
//                   bool isSatOnly = false,
//                   bool isFreeToAir = false,
//                   bool isSubscribed = false,
//                   bool isNowPlaying = false,
//                   QString category = "",
//                   QString id = "",
//                   QString logo = "",
//                   QString artistName = "",
//                   QString songName = "",
//                   QString artUrl = "",
//                   QString mediumTitle = "",
//                   QString contextualBanner = "",
//                   UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE state = UIBridge::E_HMI_EVENT_SPORTS_UNKNOWN,
//                  UIBridge::E_HMI_EVENT_CHANNEL_TYPE channelType = UIBridge::E_HMI_EVENT_NONE,
//                   QString categoryUrl = "");
    void setValue(CHANNEL_INFORMATION_T& stChannelInfomation);// = {0});

private:
    QString m_name;
    QString m_shortDescription;
    QString m_category;
    QString m_id;
    QString m_logo;

    // album
    QString m_artistName;
    QString m_songName;
    QString m_artUrl;
    QString m_categoryLogoUrl;
    bool m_isFavoriteSong;
    bool m_isFavoriteArtist;

    // show
    QString m_mediumTitle;
    QString m_longTitle;
    QString m_contextualBanner;
    unsigned int m_deliveryState;
    int m_number;
    unsigned int m_sid;

    //Sport
    UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE m_sportState;
    UIBridge::E_HMI_EVENT_CHANNEL_TYPE m_channelType;
    bool m_isAvailable;
    bool m_isFavorite;
    bool m_isPlayByPlay;
    bool m_isSatOnly;
    bool m_isFreeToAir;
    bool m_isSubscribed;
    bool m_isNowPlaying;

signals:
    void channelInfomationsChanged();
};
typedef std::shared_ptr<ChannelElements> ChannelElementPtr;
#endif // CHANNELELEMENTS_H
