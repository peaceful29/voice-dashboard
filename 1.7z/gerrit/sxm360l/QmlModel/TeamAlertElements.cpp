#include "TeamAlertElements.h"

TeamAlertElements::TeamAlertElements()
{

}

TeamAlertElements::~TeamAlertElements()
{

}

int TeamAlertElements::teamId() const
{
    return m_teamId;
}

void TeamAlertElements::setTeamId(int teamId)
{
    m_teamId = teamId;
}

QString TeamAlertElements::teamName() const
{
    return m_teamName;
}

void TeamAlertElements::setTeamName(const QString &teamName)
{
    m_teamName = teamName;
}

QString TeamAlertElements::teamLogo() const
{
    return m_teamLogo;
}

void TeamAlertElements::setTeamLogo(const QString &teamLogo)
{
    m_teamLogo = teamLogo;
}
