#include "VideoTunerListShowListModel.h"

VideoTunerListShowListModel::VideoTunerListShowListModel(QObject *parent)
    : PagingBaseListModel(parent)
{

}

VideoTunerListShowListModel::~VideoTunerListShowListModel()
{

}

QVariant VideoTunerListShowListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    VideoTunerListShowElementPtr element = std::dynamic_pointer_cast<VideoTunerListShowElement>(m_elements[index.row()]);
    switch (role) {
    case E_VIDEO_TUNER_LIST_SHOW_NAME:
        return element->nameComp();
    case E_VIDEO_TUNER_LIST_SHOW_INDEX:
        return element->indexComp();
    case E_VIDEO_TUNER_LIST_SHOW_IMAGE_PATH:
        return element->imagePathComp();
    case E_VIDEO_TUNER_LIST_SHOW_HIGH_LIGHT:
        return element->isHighLight();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> VideoTunerListShowListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_VIDEO_TUNER_LIST_SHOW_NAME] = "nameComp";
    roles[E_VIDEO_TUNER_LIST_SHOW_INDEX] = "indexComp";
    roles[E_VIDEO_TUNER_LIST_SHOW_IMAGE_PATH] = "imagePathComp";
    roles[E_VIDEO_TUNER_LIST_SHOW_HIGH_LIGHT] = "isHighLight";
    return roles;
}

bool VideoTunerListShowListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if (index.isValid() && (index.row() < m_elements.size())) {
        VideoTunerListShowElementPtr element = std::dynamic_pointer_cast<VideoTunerListShowElement>(m_elements[index.row()]);
        switch (role) {
        case E_VIDEO_TUNER_LIST_SHOW_NAME:
            element->setNameComp(value.toString());
            break;
        case E_VIDEO_TUNER_LIST_SHOW_INDEX:
            element->setIndexComp(value.toString());
            break;
        case E_VIDEO_TUNER_LIST_SHOW_IMAGE_PATH:
            element->setIndexComp(value.toString());
            break;
        case E_VIDEO_TUNER_LIST_SHOW_HIGH_LIGHT:{
            element->setHighLight(value.toBool());
        }
            break;
        default:
            ret = false;
            break;
        }
    }
    return ret;
}

