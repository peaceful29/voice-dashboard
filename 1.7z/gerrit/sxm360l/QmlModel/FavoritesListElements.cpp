#include "FavoritesListElements.h"

FavoritesListElements::FavoritesListElements()
{

}

FavoritesListElements::~FavoritesListElements()
{
	
}

int FavoritesListElements::favType() const
{
    return m_favType;
}

void FavoritesListElements::setFavType(int favType)
{
    m_favType = favType;
}

QString FavoritesListElements::favName() const
{
    return m_favName;
}

void FavoritesListElements::setFavName(const QString &favName)
{
    m_favName = favName;
}

QString FavoritesListElements::favId() const
{
    return m_favId;
}

void FavoritesListElements::setFavId(const QString &favId)
{
    m_favId = favId;
}

QString FavoritesListElements::favBanner() const
{
    return m_favBanner;
}

void FavoritesListElements::setFavBanner(const QString &favBanner)
{
    m_favBanner = favBanner;
}

//ChannelElementPtr FavoritesListElements::channelElement() const
//{
//    return m_channelElement;
//}

//void FavoritesListElements::setChannelElement(const ChannelElementPtr &channelElement)
//{
//    m_channelElement = channelElement;
//}
