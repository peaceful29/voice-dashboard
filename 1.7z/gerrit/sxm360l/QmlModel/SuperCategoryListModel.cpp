#include "SuperCategoryListModel.h"
#include "SuperCategoryElements.h"
#include "Common/SXMDefine.h"

SuperCategoryListModel::SuperCategoryListModel(QObject* parent)
    :BaseListModel(parent)
{

}

SuperCategoryListModel::~SuperCategoryListModel()
{

}

QVariant SuperCategoryListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    SuperCategoryElementsPtr element = std::dynamic_pointer_cast<SuperCategoryElements>(m_elements[index.row()]);
    switch (role) {
    case E_SUPER_CATEGORIES_LIST_ROLES_NAME:
        return element->superCategoryName();
    case E_SUPER_CATEGORIES_LIST_ROLES_IS_CURRENT:
        return element->isCurrent();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> SuperCategoryListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_SUPER_CATEGORIES_LIST_ROLES_NAME] = "name";
    roles[E_SUPER_CATEGORIES_LIST_ROLES_IS_CURRENT] = "isCurrent";
    return roles;
}

bool SuperCategoryListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if(index.isValid() && (index.row() < m_elements.size())) {
        SuperCategoryElementsPtr element = std::dynamic_pointer_cast<SuperCategoryElements>(m_elements[index.row()]);
        switch (role) {
        case E_SUPER_CATEGORIES_LIST_ROLES_NAME:
            element->setSuperCategoryName(value.toString());
            break;
        case E_SUPER_CATEGORIES_LIST_ROLES_IS_CURRENT:
            element->setIsCurrent(value.toBool());
            break;
        default:
            ret = false;
            break;
        }
    }
    return ret;
}
