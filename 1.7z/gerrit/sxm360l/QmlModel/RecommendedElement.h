#ifndef RECOMMENDEDELEMENT_H
#define RECOMMENDEDELEMENT_H

#include "BaseElement.h"
#include "sxm360l/Sxm360lMsgDef.h"
#include "QmlModel/ChannelElements.h"
class RecommendedElement: public ChannelElements
{
public:
    RecommendedElement();
    virtual ~RecommendedElement();
    QString mediumTitle() const;
    void setMediumTitle(const QString &mediumTitle);

    QString longTitle() const;
    void setLongTitle(const QString &longTitle);

    QString shortDes() const;
    void setShortDes(const QString &shortDes);

    QString showGui() const;
    void setShowGui(const QString &showGui);

    PROGRAM_TYPE programType() const;
    void setProgramType(const PROGRAM_TYPE &programType);

    uint32_t audioEpisode() const;
    void setAudioEpisode(const uint32_t &audioEpisode);

    uint32_t videoEpisode() const;
    void setVideoEpisode(const uint32_t &videoEpisode);

    uint32_t newEpisodeCount() const;
    void setNewEpisodeCount(const uint32_t &newEpisodeCount);

    QString contextual() const;
    void setContextual(const QString &contextual);

    bool isMature() const;
    void setIsMature(bool isMature);

    uint32_t episodeCount() const;
    void setEpisodeCount(const uint32_t &episodeCount);

private:
    QString      m_mediumTitle;
    QString      m_longTitle;
    QString      m_shortDes;
    QString      m_showGui;
    PROGRAM_TYPE m_programType;
    uint32_t     m_audioEpisode;
    uint32_t     m_videoEpisode;
    uint32_t     m_newEpisodeCount;
    uint32_t     m_episodeCount;
    QString      m_contextual;
    bool         m_isMature;
};

typedef std::shared_ptr<RecommendedElement> RecommendedElementPtr;

#endif // RECOMMENDEDELEMENT_H
