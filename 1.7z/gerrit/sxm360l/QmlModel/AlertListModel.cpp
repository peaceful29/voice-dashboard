#include "AlertListModel.h"

AlertListModel::AlertListModel(QObject *parent)
    :BaseListModel(parent)
{

}

AlertListModel::~AlertListModel()
{

}

QVariant AlertListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    SongArtistAlertElementPtr element = std::dynamic_pointer_cast<SongArtistAlertElement>(m_elements[index.row()]);
    switch (role) {
    case E_ALERT_NAME:
        return element->alertName();
    case E_ALERT_TYPE:
        return element->alertType();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> AlertListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_ALERT_NAME] = "name";
    roles[E_ALERT_TYPE] = "type";
    return roles;
}

void AlertListModel::remove(int idx)
{
    if (idx < m_elements.size()) {
        beginRemoveRows(QModelIndex(), idx, idx);
        BaseElementPtr element = m_elements.takeAt(idx);
        Q_UNUSED(element)
        endRemoveRows();
    }
}

bool AlertListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if (index.isValid() && (index.row() < m_elements.size())) {
        SongArtistAlertElementPtr element = std::dynamic_pointer_cast<SongArtistAlertElement>(m_elements[index.row()]);
        switch (role) {
        case E_ALERT_NAME:
            element->setAlertName(value.toString());
            break;
        case E_ALERT_TYPE:
            element->setAlertType(value.toInt());
            break;
        default:
            break;
        }
    }
    return ret;
}
