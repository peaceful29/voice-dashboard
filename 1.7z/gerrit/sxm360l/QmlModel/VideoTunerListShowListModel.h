#ifndef VIDEOTUNERLISTSHOWLISTMODEL_H
#define VIDEOTUNERLISTSHOWLISTMODEL_H

#include <QObject>
#include <QDebug>
#include "PagingBaseListModel.h"
#include "Common/SXMDefine.h"
#include "VideoTunerListShowElement.h"

class VideoTunerListShowListModel : public PagingBaseListModel
{
    Q_OBJECT
public:
    explicit VideoTunerListShowListModel(QObject* parent = nullptr);
    ~VideoTunerListShowListModel();

    QVariant data(const QModelIndex & index, int role = Qt::DisplayRole) const;
    virtual QHash<int,QByteArray> roleNames() const;
protected:
    bool setData(const QModelIndex &index, const QVariant &value, int role);
};

#endif // VIDEOTUNERLISTSHOWLISTMODEL_H
