#include "CategoryListModel.h"
#include "CategoryElements.h"
#include "Common/SXMDefine.h"

CategoryListModel::CategoryListModel(QObject *parent)
    :BaseListModel(parent)
{

}

CategoryListModel::~CategoryListModel()
{

}

QVariant CategoryListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    CategoryElementsPtr element = std::dynamic_pointer_cast<CategoryElements>(m_elements[index.row()]);
    switch (role) {
    case E_CATEGORIES_LIST_ROLES_NAME:
        return element->categoryName();
    case E_CATEGORIES_LIST_ROLES_LOGO_IMAGE:
        return element->categoryLogo();
    case E_CATEGORIES_LIST_ROLES_ID:
        return element->categoryId();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> CategoryListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_CATEGORIES_LIST_ROLES_NAME] = "name";
    roles[E_CATEGORIES_LIST_ROLES_LOGO_IMAGE] = "logoImage";
    roles[E_CATEGORIES_LIST_ROLES_ID] = "id";
    return roles;
}

bool CategoryListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if (index.isValid() && (index.row() < m_elements.size())) {
        CategoryElementsPtr element = std::dynamic_pointer_cast<CategoryElements>(m_elements[index.row()]);
        switch (role) {
        case E_CATEGORIES_LIST_ROLES_NAME:
            element->setCategoryName(value.toString());
            break;
        case E_CATEGORIES_LIST_ROLES_LOGO_IMAGE:
            element->setCategoryLogo(value.toString());
            break;
        default:
            break;
        }
    }
    return ret;
}
