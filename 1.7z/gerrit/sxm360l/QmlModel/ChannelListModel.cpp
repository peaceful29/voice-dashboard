#include "ChannelListModel.h"

ChannelListModel::ChannelListModel(QObject *parent):BaseListModel(parent)
{

}
ChannelListModel::~ChannelListModel(){

}

QVariant ChannelListModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() > (m_elements.size()-1) ) {
        return QVariant();
    }
    ChannelElementPtr element = std::dynamic_pointer_cast<ChannelElements>(m_elements[index.row()]);
    switch (role) {
    case E_CHANNELS_LIST_ROLES_NAME:
        return element->name();
    case E_CHANNELS_LIST_ROLES_SHORT_DESCRIPTION:
        return element->shortDescription();
    case E_CHANNELS_LIST_ROLES_CATEGORY:
        return element->category();
    case E_CHANNELS_LIST_ROLES_ID:
        return element->id();
    case E_CHANNELS_LIST_ROLES_LOGO:
        return element->logo();
    case E_CHANNELS_LIST_ROLES_ARTIST_NAME:
        return element->artistName();
    case E_CHANNELS_LIST_ROLES_ART_URL:
        return element->artUrl();
    case E_CHANNELS_LIST_ROLES_MEDIUM_TITLE:
        return element->mediumTitle();
//    case E_CHANNELS_LIST_ROLES_LIVE_CHANNEL_ID:
//        return element->liveChannelId();
    case E_CHANNELS_LIST_ROLES_CONTEXTUAL_BANNER:
        return element->contextualBanner();
    case E_CHANNELS_LIST_ROLES_DELIVERY_STATE:
        return element->deliveryState();
    case E_CHANNELS_LIST_ROLES_NUMBER:
        return element->number();
    case E_CHANNELS_LIST_ROLES_SID:
        return element->sid();
    case E_CHANNELS_LIST_ROLES_IS_AVAILABLE:
        return element->isAvailable();
    case E_CHANNELS_LIST_ROLES_IS_FAVORITE:
        return element->isFavorite();
    case E_CHANNELS_LIST_ROLES_IS_PLAYBYPLAY:
        return element->isPlayByPlay();
    case E_CHANNELS_LIST_ROLES_IS_SATONLY:
        return element->isSatOnly();
    case E_CHANNELS_LIST_ROLES_IS_FREETOAIR:
        return element->isFreeToAir();
    case E_CHANNELS_LIST_ROLES_IS_SUBSCRIBED:
        return element->isSubscribed();
    case E_CHANNELS_LIST_ROLES_IS_NOWPLAYING:
        return element->isNowPlaying();
    case E_CHANNELS_LIST_ROLES_SPORT_STATE:
        return element->sportState();
    case E_CHANNELS_LIST_ROLES_TYPE:
        return element->channelType();
    default:
        return QVariant();
    }
}
QHash<int, QByteArray> ChannelListModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[E_CHANNELS_LIST_ROLES_NAME] = "name";
    roles[E_CHANNELS_LIST_ROLES_SHORT_DESCRIPTION] = "shortDescription";
    roles[E_CHANNELS_LIST_ROLES_CATEGORY] = "category";
    roles[E_CHANNELS_LIST_ROLES_ID] = "id";
    roles[E_CHANNELS_LIST_ROLES_LOGO] = "logoUrl";
    roles[E_CHANNELS_LIST_ROLES_ARTIST_NAME] = "artistName";
    roles[E_CHANNELS_LIST_ROLES_ART_URL] = "artUrl";
    roles[E_CHANNELS_LIST_ROLES_MEDIUM_TITLE] = "mediumTitle";
//    roles[E_CHANNELS_LIST_ROLES_LIVE_CHANNEL_ID] = "liveChannelId";
    roles[E_CHANNELS_LIST_ROLES_CONTEXTUAL_BANNER] = "contextualBanner";
    roles[E_CHANNELS_LIST_ROLES_DELIVERY_STATE] = "deliveryState";
    roles[E_CHANNELS_LIST_ROLES_NUMBER] = "number";
    roles[E_CHANNELS_LIST_ROLES_SID] = "sid";
    roles[E_CHANNELS_LIST_ROLES_IS_AVAILABLE] = "isAvailable";
    roles[E_CHANNELS_LIST_ROLES_IS_FAVORITE] = "isFavorite";
    roles[E_CHANNELS_LIST_ROLES_IS_PLAYBYPLAY] = "isPlayByPlay";
    roles[E_CHANNELS_LIST_ROLES_IS_SATONLY] = "isSatOnly";
    roles[E_CHANNELS_LIST_ROLES_IS_FREETOAIR] = "isFreeToAir";
    roles[E_CHANNELS_LIST_ROLES_IS_SUBSCRIBED] = "isSubscribed";
    roles[E_CHANNELS_LIST_ROLES_IS_NOWPLAYING] = "isNowPlaying";
    roles[E_CHANNELS_LIST_ROLES_SPORT_STATE] = "sportState";
    roles[E_CHANNELS_LIST_ROLES_TYPE] = "channelType";

    return roles;
}

void ChannelListModel::move(int src, int dst)
{
    if (0 <= src && src < m_elements.size() && 0 <= dst && dst < m_elements.size() && src != dst) {
        if(dst > src) {
            beginMoveRows(QModelIndex(), src, src, QModelIndex(), dst + 1);
        } else {
            beginMoveRows(QModelIndex(), src, src, QModelIndex(), dst);
        }
        m_elements.move(src, dst);
        endMoveRows();
    }
}

void ChannelListModel::remove(int idx)
{
    if (idx < m_elements.size()) {
        beginRemoveRows(QModelIndex(), idx, idx);
        BaseElementPtr element = m_elements.takeAt(idx);
        Q_UNUSED(element)
        endRemoveRows();
    }
}

bool ChannelListModel::setData(const QModelIndex &index, const QVariant &value, int role)
{
    bool ret = true;
    if(index.isValid() && (index.row() < m_elements.size())) {
        ChannelElementPtr element = std::dynamic_pointer_cast<ChannelElements>(m_elements[index.row()]);
        switch (role) {
        case E_CHANNELS_LIST_ROLES_NAME:
            element->setName(value.toString());
            break;
        case E_CHANNELS_LIST_ROLES_SHORT_DESCRIPTION:
            element->setShortDescription(value.toString());
            break;
        case E_CHANNELS_LIST_ROLES_CATEGORY:
            element->setCategory(value.toString());
            break;
        case E_CHANNELS_LIST_ROLES_ID:
            element->setId(value.toString());
            break;
        case E_CHANNELS_LIST_ROLES_LOGO:
            element->setLogo(value.toString());
            break;
        case E_CHANNELS_LIST_ROLES_ARTIST_NAME:
            element->setArtistName(value.toString());
            break;
        case E_CHANNELS_LIST_ROLES_ART_URL:
            element->setArtUrl(value.toString());
            break;
        case E_CHANNELS_LIST_ROLES_MEDIUM_TITLE:
            element->setMediumTitle(value.toString());
            break;
//        case E_CHANNELS_LIST_ROLES_LIVE_CHANNEL_ID:
//            element->setLiveChannelId(value.toString());
//            break;
        case E_CHANNELS_LIST_ROLES_CONTEXTUAL_BANNER:
            element->setContextualBanner(value.toString());
            break;
        case E_CHANNELS_LIST_ROLES_DELIVERY_STATE:
            element->setDeliveryState(value.toUInt());
            break;
        case E_CHANNELS_LIST_ROLES_NUMBER:
            element->setNumber(value.toUInt());
            break;
        case E_CHANNELS_LIST_ROLES_SID:
            element->setSid(value.toUInt());
            break;
        case E_CHANNELS_LIST_ROLES_IS_AVAILABLE:
            element->setIsAvailable(value.toBool());
            break;
        case E_CHANNELS_LIST_ROLES_IS_FAVORITE:
            element->setIsFavorite(value.toBool());
            break;
        case E_CHANNELS_LIST_ROLES_IS_PLAYBYPLAY:
            element->setIsPlayByPlay(value.toBool());
            break;
        case E_CHANNELS_LIST_ROLES_IS_SATONLY:
            element->setIsSatOnly(value.toBool());
            break;
        case E_CHANNELS_LIST_ROLES_IS_FREETOAIR:
            element->setIsFreeToAir(value.toBool());
            break;
        case E_CHANNELS_LIST_ROLES_IS_SUBSCRIBED:
            element->setIsSubscribed(value.toBool());
            break;
        case E_CHANNELS_LIST_ROLES_IS_NOWPLAYING:
            element->setIsNowPlaying(value.toBool());
            break;
        case E_CHANNELS_LIST_ROLES_SPORT_STATE:
            element->setSportState(static_cast<UIBridge::E_HMI_EVENT_SPORTS_TEAM_STATE>(value.toInt()));
            break;
        case E_CHANNELS_LIST_ROLES_TYPE:
            element->setChannelType(static_cast<UIBridge::E_HMI_EVENT_CHANNEL_TYPE>(value.toInt()));
            break;
        default:
            ret = false;
            break;
        }
    }
    return ret;
}
