#include "AutoClickTest.h"
#include <QMouseEvent>
#include <QGraphicsSceneMouseEvent>
#include <QJsonDocument>
#include <QJsonArray>
#include <QDebug>

AutoClickTest::AutoClickTest()
{

}

QQuickItem *AutoClickTest::rootObject() const
{
    return m_rootObject;
}

void AutoClickTest::setRootObject(QQuickItem *rootObject)
{
    m_rootObject = rootObject;
}

QQuickView *AutoClickTest::view() const
{
    return m_view;
}

void AutoClickTest::setView(QQuickView *view)
{
    m_view = view;
}

QJsonObject AutoClickTest::jsonObj() const
{
    return m_jsonObj;
}

void AutoClickTest::setJsonObj(const QJsonObject &jsonObj)
{
    m_jsonObj = jsonObj;
}

void AutoClickTest::onMouseEventSlot()
{
    static int count = 1;
    QString step = "Step_" + QString::number(count);
    QJsonObject stepObj = m_jsonObj.value(step).toObject();
    qDebug() << "stepObj Count: " << m_jsonObj.count();
    QString lstName = stepObj.value("lstName").toString();
    qDebug() << "lstName: " << lstName;
    QQuickItem* mouseArea;
    //Click Item in List
    if (lstName != "") {
        QQuickItem* lstItem = m_rootObject->findChild<QQuickItem *>(lstName);
        if (lstItem == nullptr)
            return;
        int lstIndex = stepObj.value("lstIndex").toInt();
        QList<QQuickItem*> lstChil = lstItem->childItems();
        if (lstIndex >= lstChil.count())
            return;
        mouseArea = lstChil.at(lstIndex)->findChild<QQuickItem *>("MouseArea");
    } else {
        QString objName = stepObj.value("objName").toString();
        mouseArea = m_rootObject->findChild<QQuickItem *>(objName)->findChild<QQuickItem *>("MouseArea");
    }

    if (mouseArea) {
        QString mouseEvent = stepObj.value("mouseEvent").toString();
        if (mouseEvent == "onClicked") {
            QMouseEvent pressEvent(QEvent::MouseButtonPress, QPoint(0, 0), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
            QMouseEvent releaseEvent(QEvent::MouseButtonRelease, QPoint(0, 0), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);

            const bool isSentPress = m_view->sendEvent(mouseArea, &pressEvent);
            const bool isSentRelease = m_view->sendEvent(mouseArea, &releaseEvent);
            Q_UNUSED(isSentPress);
            Q_UNUSED(isSentRelease);

        } else if (mouseEvent == "onDoubleClicked") {
            QMouseEvent doubleClickedEvent(QEvent::MouseButtonDblClick, QPoint(0, 0), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
            const bool isDoubleded = m_view->sendEvent(mouseArea, &doubleClickedEvent);
            Q_UNUSED(isDoubleded);
        }
    }
    if (count <= m_jsonObj.count())
        count++;
    else {
        qDebug() << "Count Step Ended: " << count;
        emit onTestEnded();
    }
}

