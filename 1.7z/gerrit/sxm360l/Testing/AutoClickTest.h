#ifndef AUTOCLICKTEST_H
#define AUTOCLICKTEST_H

#include <QObject>
#include <QQuickItem>
#include <QQuickView>
#include <QJsonObject>

class AutoClickTest : public QObject
{
    Q_OBJECT
public:
    AutoClickTest();
    QQuickItem *rootObject() const;
    void setRootObject(QQuickItem *rootObject);

    QQuickView *view() const;
    void setView(QQuickView *view);

    QJsonObject jsonObj() const;
    void setJsonObj(const QJsonObject &jsonObj);

private:
    QQuickItem* m_rootObject;
    QQuickView* m_view;
    QJsonObject m_jsonObj;

public slots:
    void onMouseEventSlot();
signals:
    void onTestEnded();
};

#endif // AUTOCLICKTEST_H
