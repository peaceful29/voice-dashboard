#include "ResourceManager.h"
#include "DataExchange/DataController.h"

ResourceManager* ResourceManager::instance()
{
    return SingletonHmi::getInstance();
}

void ResourceManager::initResourceManager()
{
    initProgramType();
}

QString ResourceManager::getProgramType(const int& categoryId)
{
    return m_programType[static_cast<PROGRAM_TYPE>(categoryId)];
}

QString ResourceManager::getCategoryLogo(QString _category)
{
    return m_categoryLogo[_category];
}

void ResourceManager::addCategoryLogo(QString _category, QString _logoUrl)
{
    m_categoryLogo[_category] = _logoUrl;
}


ResourceManager::ResourceManager()
{
    m_currentChannelNumber = 0;
    m_currentSuperCategory = "Music";
    m_isBackButtonShowed = false;
    m_isBackButtonClick = false;
}

ResourceManager::~ResourceManager()
{

}

void ResourceManager::initProgramType()
{
    m_programType[Unknown] = "";
    m_programType[MusicShow] = "Music Show";
    m_programType[MusicSpecial]  = "Music Special";
    m_programType[TalkShow] = "Talk Show";
    m_programType[TalkSpecial] = "Talk Special";
    m_programType[SpecialEvent] ="Special Event";
    m_programType[SportsSpecial] =  "Sports Special";
    m_programType[Interviews] =  "Interviews";
    m_programType[InterviewSpecial]  = "Interview Special";
    m_programType[CallInShow]   =  "Call-In Show";
    m_programType[Performance]   =  "Performance";
    m_programType[ConcertSpecial]    = "Concert Special";
    m_programType[Countdown]    = "Countdown";
    m_programType[PlayByPlay]     =  "Play by Play";
    m_programType[SportsTalk]      = "Sports Talk";
    m_programType[NewsUpdate]       =  "News Update";
    m_programType[StandUp]        = "Stand-Up";
    m_programType[Other]  = "";
}

bool ResourceManager::getIsBackButtonClick() const
{
    return m_isBackButtonClick;
}

void ResourceManager::setIsBackButtonClick(bool isBackButtonClick)
{
    m_isBackButtonClick = isBackButtonClick;
}

uint32_t ResourceManager::getCurrentChannelNumber() const
{
    return m_currentChannelNumber;
}

void ResourceManager::setCurrentChannelNumber(uint32_t currentChannelNumber)
{
    m_currentChannelNumber = currentChannelNumber;
}

bool ResourceManager::getIsBackButtonShowed() const
{
    return m_isBackButtonShowed;
}

void ResourceManager::setIsBackButtonShowed(bool isBackButtonShowed)
{
    m_isBackButtonShowed = isBackButtonShowed;
}

QString ResourceManager::getCurrentSuperCategory() const
{
    return m_currentSuperCategory;
}

void ResourceManager::setCurrentSuperCategory(const QString &currentSuperCategory)
{
    m_currentSuperCategory = currentSuperCategory;
}
