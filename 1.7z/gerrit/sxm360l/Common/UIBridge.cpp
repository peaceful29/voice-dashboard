#include "UIBridge.h"
#include <QDebug>
#include "SXMAppMain.h"

//UIBridge* UIBridge::m_instance = nullptr;

UIBridge::UIBridge(QObject *parent) : QObject(parent)
{
    LOGI().writeFormatted("UIBridge::UIBridge() called");
//    m_sxmHandler = SXMKeyPadHandler::instance();
//    connect(m_sxmHandler, SIGNAL(doneGetSXMValidNumber(QString, bool)), this, SLOT(onGetSXMValidNumberDone(QString, bool)));
}

//UIBridge *UIBridge::getInstance(QObject *parent)
//{
//    if (m_instance == nullptr)
//        m_instance = new UIBridge(parent);
//    return m_instance;
//}

UIBridge::~UIBridge()
{

}

void UIBridge::setStyleMode(QString _styleMode)
{
    m_styleMode = _styleMode;
}

void UIBridge::onHmiEvent(int fncId, QString parameters)
{
    emit hmiEvent(fncId, parameters);
}

QString UIBridge::getImageSource(QString prefixFolder, QString sourceImage)
{
//    QString styleMode = m_AppMain->getCurrentStyleMode();
    return QUrl::fromLocalFile(qApp->applicationDirPath() + "/res/Landrover/Luxury/png/" + prefixFolder + "/" + m_styleMode+"/" + sourceImage).toString();
}

QString UIBridge::getImageSource(QString prefixFolder, QString mode, QString sourceImage)
{
    return QUrl::fromLocalFile(qApp->applicationDirPath() + "/res/Landrover/Luxury/png/" + prefixFolder + "/" + mode +"/" + sourceImage).toString();
}

QString UIBridge::getFont(QString fontName)
{
    if (fontName == "menuText") fontName = "TipperaryForJLR-SB_JP";
//    LOGI().writeFormatted("[UIBridge::Font Name]%s", fontName.toStdString().c_str());
    return QUrl::fromLocalFile(qApp->applicationDirPath() + "/res/font/" + fontName + ".ttf").toString();
}

void UIBridge::consoleLog(QString log)
{
    LOGI().writeFormatted("UIBridge::consoleLog() log: %s", log.toStdString().c_str());
}

void UIBridge::onSXMValidNumberChanged(QString enteredNumber)
{
    QString validKey;
    bool isValid;
    SXMKeyPadHandler::instance()->getSXMValidNumber(enteredNumber.toInt(), validKey, isValid);
    onGetSXMValidNumberDone(validKey, isValid);
}

QString UIBridge::getSeekChannelDirectune(QString currentChannel, QString seekType)
{
    return SXMKeyPadHandler::instance()->getSeekChannel(currentChannel, seekType);
}

void UIBridge::onGetSXMValidNumberDone(QString number, bool isValid)
{
    emit currentSXMValidNumberChanged(number, isValid);
}
