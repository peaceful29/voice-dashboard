#ifndef SINGLETONHMI_H
#define SINGLETONHMI_H

#include <atomic>
#include <thread>
#include <mutex>
#include <exception>

class Synchronize {
public:
    Synchronize() {

    }

    virtual ~Synchronize() = default;
    void lockGuard() {
        std::lock_guard<std::mutex> lock(m_mutex);
    }

    void lock() {
        m_mutex.lock();
    }

    void unlock() {
        m_mutex.unlock();
    }

private:
    std::mutex m_mutex;
};

template<typename T>
class SingletonHmi {
protected:
    static T* getInstance() {
        T* tmp = m_storage.load();
        if (tmp == nullptr) {
            m_synchronize.lock();
            tmp = new T();
            m_storage.store(tmp);
            m_instance = tmp;
            m_synchronize.unlock();
        }
        return tmp;
    }

    static void deleteInstance() {
        m_synchronize.lock();
        if (m_instance != nullptr) {
            delete m_instance;
            m_instance = nullptr;
            m_storage.store(nullptr);
        }
        m_synchronize.unlock();
    }

    SingletonHmi() {}
    virtual ~SingletonHmi() = default;
    static T* m_instance;
    static Synchronize m_synchronize;
private:
    SingletonHmi(const SingletonHmi&);
    SingletonHmi& operator=(const SingletonHmi&);
    static std::atomic<T*> m_storage;
};

template<typename T> std::atomic<T*> SingletonHmi<T>::m_storage;
template<typename T> T* SingletonHmi<T>::m_instance = nullptr;
template<typename T> Synchronize SingletonHmi<T>::m_synchronize;

#endif // SINGLETONHMI_H
