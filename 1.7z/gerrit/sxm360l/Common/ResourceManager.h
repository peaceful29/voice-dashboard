#ifndef RESOURCEMANAGER_H
#define RESOURCEMANAGER_H

#include <QList>
#include <QString>
#include <map>
#include <QMap>
#include "sxm360l/Sxm360lMsgDef.h"
#include "SingletonHmi.h"

class ResourceManager : public SingletonHmi<ResourceManager>
{
    friend class SingletonHmi<ResourceManager>;
public:
    static ResourceManager *instance();
    void initResourceManager();
    QString getProgramType(const int& categoryId);
    QString getCategoryLogo(QString _category);
    void addCategoryLogo(QString _category, QString _logoUrl);
    QString getCurrentSuperCategory() const;
    void setCurrentSuperCategory(const QString &currentSuperCategory);

    bool getIsBackButtonShowed() const;
    void setIsBackButtonShowed(bool isBackButtonShowed);

    uint32_t getCurrentChannelNumber() const;
    void setCurrentChannelNumber(uint32_t currentChannelNumber);

    bool getIsBackButtonClick() const;
    void setIsBackButtonClick(bool isBackButtonClick);
    QList<int> m_lstBackScreen;

protected:
    virtual ~ResourceManager();
private:
    ResourceManager();
    void initProgramType();

    std::map<PROGRAM_TYPE ,QString> m_programType;
    std::map<QString, QString> m_categoryLogo;
    QList<int> m_lstChannel;
    QString m_currentSuperCategory;
    bool m_isBackButtonShowed;
    uint32_t m_currentChannelNumber;
    bool m_isBackButtonClick;
};

#endif // RESOURCEMANAGER_H
