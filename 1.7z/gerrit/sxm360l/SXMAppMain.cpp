#include "SXMAppMain.h"
#include "MacroDefine.h"
#include "ComponentStates.h"
#include "ScreenIdentifier.h"
#include "ScreenList.h"
#include <QQmlEngine>
#include <QQmlContext>
#include <QQuickItem>
#include "Adapter/BaseAdapter.h"
#include "Common/UIBridge.h"
#include "Adapter/ScreenFactory.h"
//#ifndef APP_ON_DESKTOP
#include "Interfaces/SxmInterfaceFactory.h"
#include "Interfaces/SxmAppServiceInterface.h"
#include "Interfaces/SxmServiceInterface.h"
#include "SxmPopupServiceInterface.h"
#include "SxmKeyboardInterface.h"
#include "DataExchange/DataController.h"
#include "Adapter/BaseAdapter.h"
#include "hmi/WindowNameDef.h"
#include "ResourceManager.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include "SxmSpeechServiceInterface.h"

//#define AUTO_CLICK_TEST_MODE

SXMAppMain::SXMAppMain(QObject *parent) : QObject(parent)
  , m_view(nullptr)
  , m_uiBridge(nullptr)
  , m_styleMode("night")
  , m_speechView(nullptr)
  , m_isInitialized(false)
  , m_isSATSubscriptionStatus(false)
  , m_speechVoicetags(UIBridge::E_HMI_STATE_VOICETAGS_OFF)
//  , m_isLossSignal(false)
{
    DataController::instance();
    ResourceManager::instance();
    m_autoClickTest = new AutoClickTest();
    createInterface();
}

SXMAppMain::~SXMAppMain()
{
    SafeDelete<AutoClickTest>(m_autoClickTest);
    SafeDelete<QQuickView>(m_view);
    SafeDelete<QQuickView>(m_speechView);
    SafeDelete<UIBridge>(m_uiBridge);
}

QString SXMAppMain::getCurrentStyleMode()
{
    return m_styleMode;
}

void SXMAppMain::registerType()
{
    LOGI().writeFormatted("SxmAppMain::registerType() called");
    qRegisterMetaType<uint32_t>("uint32_t");
    qmlRegisterType<UIBridge>("UIBridgeEvent",1,0,"UIBrigdeEvent");
    qmlRegisterType<ComponentStates>("ComponentStates", 1, 0, "ComponentStates");
    qmlRegisterType<ScreenIdentifier>("ScreenIdentifier", 1, 0, "ScreenIdentifier");
    qmlRegisterSingletonType(QUrl("qrc:/resources/qmls/units/CommonStyle/GeneraColorOverlayStyle.qml"), "OverlayStyle", 1, 0, "OverlayStyle");
    qmlRegisterSingletonType(QUrl("qrc:/resources/qmls/units/CommonStyle/GeneralButtonTextStyle.qml"), "ButtonStyle", 1, 0, "ButtonStyle");
    qmlRegisterSingletonType(QUrl("qrc:/resources/qmls/units/CommonStyle/GeneralTextStyle.qml"), "TextStyle", 1, 0, "TextStyle");
    qmlRegisterSingletonType(QUrl("qrc:/resources/qmls/units/CommonStyle/FontLoaderJLR.qml"), "font", 1, 0, "LoadFont");
    qRegisterMetaType<DataIdentifier::E_EVENT_NOTIFIER>();
}

void SXMAppMain::initializeContextProperty()
{
    LOGI().writeFormatted("SxmAppMain::initializeContextProperty() called");
    m_view->rootContext()->setContextProperty("styleMode", m_styleMode);
    m_speechView->rootContext()->setContextProperty("styleMode", m_styleMode);
}

void SXMAppMain::initializeScreenFactory()
{
    LOGI().writeFormatted("SxmAppMain::initializeScreenFactory() called");
    ScreenFactory* screenFactory = ScreenFactory::instance();
    screenFactory->initializeAdapter(nullptr);
}

void SXMAppMain::initializeView()
{
    LOGI().writeFormatted("SxmAppMain::initializeView() called>>>>>");
    m_uiBridge = new UIBridge(this);
    m_uiBridge->setStyleMode(m_styleMode);
    connect(m_uiBridge,SIGNAL(requestShow(QString,int)), this, SLOT(onRequestShow(QString,int)));
    connect(m_uiBridge, SIGNAL(changedStyleMode()), this, SLOT(onChangeStyleMode()));
    connect(m_uiBridge, SIGNAL(hmiEvent(int,QString)), this, SLOT(onHmiEvent(int,QString)));
#ifdef AUTO_CLICK_TEST_MODE
    connect(m_autoClickTest, SIGNAL(onTestEnded()), &m_autoClickTimer, SLOT(stop()));
#endif
    //Initialize normal view
    m_view->rootContext()->setContextProperty("UIBridge", m_uiBridge);
    m_view->rootContext()->setContextProperty("contentMode", "normalMode");
    m_view->rootContext()->setContextProperty("satSubscriptionStatus", "m_isSATSubscriptionStatus");
    m_view->rootContext()->setContextProperty("speechVoicetags", m_speechVoicetags);
//    m_view->rootContext()->setContextProperty("isLossSignal", "m_isLossSignal");

    m_view->setProperty("qnxWindowId", WIN_NAME_SXM360L);
    m_view->setResizeMode(QQuickView::SizeRootObjectToView);
    m_view->setColor(Qt::transparent);
    m_view->setSource(QUrl(QStringLiteral("qrc:/resources/qmls/main.qml")));
    m_rootObject = m_view->rootObject();
    //Initialize speech view
    m_speechView->rootContext()->setContextProperty("UIBridge", m_uiBridge);
    m_speechView->rootContext()->setContextProperty("contentMode", "speechMode");
    m_speechView->setProperty("qnxWindowId", "win_hmi_sxm360l_speechmode");
    m_speechView->setResizeMode(QQuickView::SizeRootObjectToView);
    m_speechView->setColor(Qt::transparent);
    m_speechView->setSource(QUrl(QStringLiteral("qrc:/resources/qmls/speechmain.qml")));

#ifdef TEST_APP
//    if (m_mainLoader) {
//        m_mainLoader->setProperty("source", "qrc:/resources/qmls/pages/SXM/TestPage.qml");
//    }
//    m_view.show();
#endif
    connect(m_view->engine(), SIGNAL(warnings(QList<QQmlError>)), SLOT(onWarnings(QList<QQmlError>)));
    connect(m_speechView->engine(), SIGNAL(warnings(QList<QQmlError>)), SLOT(onWarnings(QList<QQmlError>)));
//    m_view->show();
}

void SXMAppMain::initButtonBack(int screenID)
{
    if((ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_CATEGORIES == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_FAVORITES == screenID)){
        ResourceManager::instance()->m_lstBackScreen.clear();
        ResourceManager::instance()->m_lstBackScreen.push_back(screenID);
    }
    if ((ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECOMMENDATION == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_ARTIST_SONG_NOTIFICATIONS == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_RELATED_CONTENT == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_AVAILABLE_SHOWS == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_RECENT_HISTORY == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_LIVE_CHANNEL == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_BROWSE_SPORTS_PLAY_BY_PLAY == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_LINER_TUNER == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_MANAGE_TEAM_NOTIFICATIONS == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_CHOOSE_LEAGUE == screenID) ||
            (ScreenIdentifier::E_HMI_VIEW_ID_SXM_SETTINGS_CHOOSE_TEAM == screenID)){
        if (ResourceManager::instance()->getIsBackButtonShowed() == false){
            DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TO_SHOW_SYSTEM_COMPONENT,
                                                           "31,3, ");
        }
        bool bContain = ResourceManager::instance()->m_lstBackScreen.contains(screenID);
        if(bContain == false){
            ResourceManager::instance()->m_lstBackScreen.push_back(screenID);
        }
    } else if (ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_DIRECT_TUNE == screenID) {
        //
    } else if (ResourceManager::instance()->getIsBackButtonShowed() == true) {
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TO_HIDE_SYSTEM_COMPONENT,
                                                       "31,3, ");
    }
    else{
        //
    }
}

void SXMAppMain::readJsonTestFile()
{
    qDebug() << "readJsonTestFile 1";
    QFile file;
    file.setFileName(":/resources/others/TestStep.json");
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QJsonParseError parseError;
        QJsonObject jsonObj = QJsonDocument::fromJson(file.readAll(), &parseError).object();
        file.close();
        if(parseError.error == QJsonParseError::NoError) {
            qDebug() << "readJsonTestFile 2";
            m_autoClickTest->setJsonObj(jsonObj);
        } else {
            qDebug() << "Load Error: " << parseError.errorString().toLatin1().data();
        }
    }
}

void SXMAppMain::onAutoClick()
{
    connect(&m_autoClickTimer, SIGNAL(timeout()), m_autoClickTest, SLOT(onMouseEventSlot()));
    m_autoClickTimer.start(3000);
}

void SXMAppMain::switch2NormalMode()
{
    LOGI().writeFormatted("[SxmAppMain::switch2NormalMode]");
    //Set view root for adapter
    ScreenFactory::instance()->setCurrentQQuickView(m_view);
    m_view->rootContext()->setContextProperty("contentMode", "normalMode");
    //show normal screen
    m_view->show();
    m_view->setGeometry(0, 0, 1920, 720);

    int size = ResourceManager::instance()->m_lstBackScreen.size();
    LOGI().writeFormatted("[SxmAppMain::switch2NormalMode] SIZE [%d]", size);

    if (0 >= size) {
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_LAST_CHANNEL_INFO,"");
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNELS_2, "");
        onRequestShow("", ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER);
    }
    else {
        int lastcreenSXM = ResourceManager::instance()->m_lstBackScreen.at(size -1);
        onRequestShow("", lastcreenSXM);
        LOGI().writeFormatted("[SxmAppMain::switch2NormalMode] lastcreenSXM [%d]", lastcreenSXM);
    }
}

void SXMAppMain::switch2SpeechMode(QString strIntent)
{
    LOGI().writeFormatted("[SxmAppMain::switch2SpeechMode]");
    ScreenFactory::instance()->setCurrentQQuickView(m_speechView);
    m_speechView->rootContext()->setContextProperty("contentMode", "speechMode");
    SpeechAdapter *speechAdapter = dynamic_cast<SpeechAdapter*>(ScreenFactory::instance()->getAdapter(ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_START));

    if (speechAdapter != nullptr){
        speechAdapter->activeSpeechMode(strIntent);
    }
    m_speechView->show();
    m_speechView->setGeometry(0, 0, 1920, 720);
}

SXM_APP_ROLE SXMAppMain::getCurrentAppRole(QString appRole)
{
    SXM_APP_ROLE ret = E_SXM_APP_ROLE_NORMAL_MODE;
    if (appRole.contains("speechmode") == true)
        ret = E_SXM_APP_ROLE_SPEECH_MODE;
    return ret;
}

void SXMAppMain::onWarnings(const QList<QQmlError> &_warnings)
{
    LOGI().writeFormatted("SxmAppMain::onWarnings() called");
    foreach (const QQmlError& _error, _warnings) {
        if (_error.isValid()) {
            m_lastError = _error;
            break;
        }
    }
    LOGI().writeFormatted("SxmAppMain::onWarnings() called %s", m_lastError.toString().toStdString().c_str());
}

bool SXMAppMain::isValid() const
{
    LOGI().writeFormatted("SXMAppMain::isValid() called");
    return !m_lastError.isValid();
}

QString SXMAppMain::lastError() const
{
    LOGI().writeFormatted("SXMAppMain::lastError() called");
    return m_lastError.toString();
}

void SXMAppMain::onRequestShow(QString objectName, int screenId)
{
    LOGI().writeFormatted("[SXMAppMain::onRequestShow] Request %s ScreenId %d", objectName.toStdString().c_str(), screenId);
    int currentScreenId = ScreenListInstance()->getCurrentScreenID();
    initButtonBack(screenId);
    LOGI().writeFormatted("[SXMAppMain::onRequestShow][%d][%d]", screenId, currentScreenId);
    if (ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_TUNING  == screenId) {
        DataController::instance()->setIsTuning(true);
    }
    LOGI().writeFormatted("[SXMAppMain::onRequestShow]getIsTuning [%d]", DataController::instance()->getIsTuning());

    if ((DataController::instance()->getIsTuning() == true) && (ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER  == screenId)){
        screenId = ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_TUNING;
    }
//    LOGI().writeFormatted("[SXMAppMain::onRequestShow] NO TUNING");
    if (screenId != currentScreenId) {
        LOGI().writeFormatted("[SXMAppMain::onRequestShow]");
//        ScreenList::getInstance()->setPreviousScreenID(currentScreenId);
        BaseAdapter *adapter = ScreenFactory::instance()->getAdapter(screenId);
        if (adapter != nullptr){
            LOGI().writeFormatted("[SXMAppMain::onScreenReady][%s]onForeground", adapter->name().toStdString().c_str());
            m_currentActAdapter = adapter;
            adapter->onEventScreenReady(screenId);
        }else{
            LOGI().writeFormatted("[SXMAppMain::onRequestShow]Null");
        }
        DataController::instance()->requestDataDependScreen(screenId);
    }
#ifdef AUTO_CLICK_TEST_MODE
    static bool isFirstClick = true;
    if (isFirstClick) {
        readJsonTestFile();
        m_autoClickTest->setRootObject(m_rootObject);
        m_autoClickTest->setView(&m_view);
        onAutoClick();
        isFirstClick = false;
    }
#endif
}

void SXMAppMain::onHmiEvent(int fncId, QString parameters)
{
    LOGI().writeFormatted("SxmAppMain::onHmiEvent() called fncId %d", fncId);
    DataController::instance()->makeCommandRequest(fncId, parameters);
}

void SXMAppMain::onCmdShowApplication(QString appRole, QString intent)
{
    LOGI().writeFormatted("[SxmAppMain::onCmdShowApplication]");
    requestToShowApplication(appRole, intent);
}

void SXMAppMain::onCmdShowAppWindow(QString appRole, QString intent)
{
    LOGI().writeFormatted("[SxmAppMain::onCmdShowAppWindow]");
    requestToShowApplication(appRole, intent);
}

void SXMAppMain::onSatSubscriptionState(const int state)
{
    LOGI().writeFormatted("[SxmAppMain::onSatSubscriptionState]SAT subscription state: [%d]", state);
    if ((1 == state) || (3 == state)){
        m_isSATSubscriptionStatus = true;
    }
    else {
        m_isSATSubscriptionStatus = false;
    }
    m_view->rootContext()->setContextProperty("satSubscriptionStatus", m_isSATSubscriptionStatus);
}

void SXMAppMain::onChangeStyleMode()
{
    if (m_styleMode == "day")
        m_styleMode = "night";
    else
        m_styleMode = "day";
    m_uiBridge->setStyleMode(m_styleMode);
    m_view->rootContext()->setContextProperty("styleMode", m_styleMode);
}
void SXMAppMain::requestToShowApplication(QString appRole, QString intent)
{
    LOGI().writeFormatted("[SxmAppMain::requestToShowApplication][%s][%s]", appRole.toStdString().c_str(), intent.toStdString().c_str());
    SXM_APP_ROLE role = getCurrentAppRole(appRole);
    if (!m_isInitialized){
        m_isInitialized = true;

        m_sxmInterface = m_ifactory->interface<SxmServiceInterface>();
        m_ifactory->newStart(m_sxmInterface);
        m_keyboardInterface = m_ifactory->interface<SxmKeyboardInterface>();
        m_ifactory->newStart(m_keyboardInterface);
        m_popupInterface = m_ifactory->interface<SxmPopupServiceInterface>();
        m_ifactory->newStart(m_popupInterface);
        DataController::instance()->initialize(m_sxmInterface, m_appInterface, m_keyboardInterface, m_speechInterface, m_popupInterface);
        connect(m_sxmInterface, SIGNAL(eventSatSubscriptionState(const int)), this, SLOT(onSatSubscriptionState(const int)));
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_SAT_SUBSCRIPTION_STATE, "");
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_GET_ANTENNA_STATE,"");

        switch (role){
        case E_SXM_APP_ROLE_NORMAL_MODE:{
            if (requestToShowFromVoicetags(appRole, intent)) {
                break;
            }
            else {
                m_speechVoicetags = UIBridge::E_HMI_STATE_VOICETAGS_OFF;
                m_view->rootContext()->setContextProperty("speechVoicetags", m_speechVoicetags);
            }
            m_view->show();
            m_view->setGeometry(0, 0, 1920, 720);
        }
            break;
        case E_SXM_APP_ROLE_SPEECH_MODE:{
            m_speechView->show();
            m_speechView->setGeometry(0, 0, 1920, 720);
        }
            break;
        }
    }else{
        switch (role){
        case E_SXM_APP_ROLE_NORMAL_MODE:{
            if (requestToShowFromVoicetags(appRole, intent)) {
                break;
            }
            else {
                m_speechVoicetags = UIBridge::E_HMI_STATE_VOICETAGS_OFF;
                m_view->rootContext()->setContextProperty("speechVoicetags", m_speechVoicetags);
            }
            switch2NormalMode();
        }
            break;
        case E_SXM_APP_ROLE_SPEECH_MODE:{
            switch2SpeechMode(intent);
        }
            break;
        }
    }
}

bool SXMAppMain::requestToShowFromVoicetags(QString appRole, QString intent)
{
    bool    bRet = true;
    if (appRole != QString(HMI_ROLE_SXM360L_RADIO)) {
        return false;
    }
//    QByteArray  data = QByteArray::fromRawData(intent, std::char_traits<char>::length(intent));
//    QJsonObject obj = QJsonDocument::fromJson(data).object();
    QJsonParseError parseError;
    QJsonDocument   doc = QJsonDocument::fromJson(intent.toUtf8(), &parseError);
    QJsonObject     obj = doc.object();

    if (obj.value("source").toString() != HMI_APP_NAME_SPEECH) {
        return false;
    }

    QString menu = obj.value("menu").toString().toUpper();
    ScreenFactory::instance()->setCurrentQQuickView(m_view);
    // setContextProperty
    m_speechVoicetags = UIBridge::E_HMI_STATE_VOICETAGS_ON;
    m_view->rootContext()->setContextProperty("contentMode", "normalMode");
    m_view->rootContext()->setContextProperty("speechVoicetags", m_speechVoicetags);
    //show normal screen
    m_view->show();
    m_view->setGeometry(0, 0, 1920, 720);

    if (menu.contains("FAVORITES")) {
        LOGI().writeFormatted("SxmAppMain::requestToShowFromVoicetags go to FAVORITES tab");
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_FAVORITES, "");
        onRequestShow("", ScreenIdentifier::E_HMI_VIEW_ID_SXM_FAVORITES);
    }
    else if (menu.contains("CHANNEL_INPUT")) {
        LOGI().writeFormatted("SxmAppMain::requestToShowFromVoicetags go to CHANEL INPUT tab");
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNELS_2, "");
        onRequestShow("", ScreenIdentifier::E_HMI_VIEW_ID_SXM_PLAYER_DIRECT_TUNE);
    }
    else if (menu.contains("CHANNEL")) {
        LOGI().writeFormatted("SxmAppMain::requestToShowFromVoicetags go to CHANNEL");
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_CHANNELS_2, "");
        onRequestShow("", ScreenIdentifier::E_HMI_VIEW_ID_SXM_LINER_TUNER);
    }
    else {
        LOGE().writeFormatted("SxmAppMain::requestToShowFromVoicetags menu name invalid");
    }

    return bRet;
}

void SXMAppMain::onCmdCreateAppWindow()
{
    LOGI().writeFormatted("SxmAppMain::onCmdCreateAppWindow() called");

    if ((nullptr == m_view) && (m_speechView == nullptr)) {
        m_view = new QQuickView();
        m_speechView = new QQuickView();
        initializeContextProperty();
        registerType();
        initializeView();
        initializeScreenFactory();
    }
}

void SXMAppMain::onCmdDestroyAppWindow()
{
    LOGI().writeFormatted("SxmAppMain::onCmdDestroyAppWindow() called");

    SafeDelete<QQuickView>(m_view);
    SafeDelete<QQuickView>(m_speechView);
    SafeDelete<UIBridge>(m_uiBridge);
}

void SXMAppMain::createInterface()
{
    LOGI().writeFormatted("SxmAppMain::createInterface() called");
    m_ifactory = SxmInterfaceFactory::instance();
    m_appInterface = m_ifactory->interface<SxmAppServiceInterface>();
    connect(m_appInterface, SIGNAL(cmdCreateAppWindow()), this, SLOT(onCmdCreateAppWindow()));
    connect(m_appInterface, SIGNAL(cmdDestroyAppWindow()), this, SLOT(onCmdDestroyAppWindow()));
    connect(m_appInterface, SIGNAL(cmdShowApplication(QString, QString)), this, SLOT(onCmdShowApplication(QString, QString)));
    connect(m_appInterface, SIGNAL(eventCmdShowAppWindow(QString, QString)), this, SLOT(onCmdShowAppWindow(QString, QString)));
    m_speechInterface = m_ifactory->interface<SxmSpeechServiceInterface>();

    //Connect speech interface and application interface
    connect(m_speechInterface, SIGNAL(eventLaunchingBaseFeature()), m_appInterface, SLOT(onEventRequestSpeechModeLaunchingBaseFeature()));
    connect(m_appInterface, SIGNAL(eventResponseScfaScreenShow(int, int)), m_speechInterface, SLOT(onEventResponseScfaScreenShow(int, int)));

    m_ifactory->newStart(m_appInterface);
    m_ifactory->newStart(m_speechInterface);
    m_appInterface->registerApplication();
}
