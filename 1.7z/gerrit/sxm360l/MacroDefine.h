#ifndef MACRODEFINE_H
#define MACRODEFINE_H


#define SETPROPERTY(OBJECT, PROPERTY, VALUE) {QList<QObject*> _uiObjects = m_rootObject->findChildren<QObject*>(OBJECT); \
                                                if (m_rootObject->objectName() == OBJECT) m_rootObject->setProperty(PROPERTY, VALUE); \
                                                foreach (QObject* _uiObject, _uiObjects) {\
                                                    if (_uiObject) _uiObject->setProperty(PROPERTY, VALUE);}}

#endif // MACRODEFINE_H
