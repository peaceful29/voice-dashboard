#ifndef SXMPOPUPSERVICE_H
#define SXMPOPUPSERVICE_H

#include "Utils.h"
#include "popupservice/IOnPopupListener.h"

class PopupProxy;
class SxmPopupServiceInterface;
class OnBaseListener;

class SxmPopupService: public IOnPopupListener
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
public:
    explicit SxmPopupService(SxmPopupServiceInterface *_interface);
    virtual ~SxmPopupService();

    void initialize(OnBaseListener* engine);

    void requestShowPopup(const uint32_t& clientSessionID, const E_POPUP_TYPE& ePopupType, const E_POPUP_SIDE_TYPE& ePopupSideType, const E_POPUP_SIZE& ePopupSize, const char* popupContext, const uint32_t& priority);
    void requestHidePopup(const uint32_t& clientSessionID, const uint32_t& handle);
    void requestUpdatePopup(const uint32_t& clientSessionID, const uint32_t& handle, const char* popupContext);
    void requestShowSpecialPopup(const uint32_t& clientSessionID, const E_SPECIAL_POPUP_TYPE& eSpecialPopupType, const char* popupContext, const uint32_t& priority);

private:
    void onResponseShowPopup(const uint32_t& clientSessionID, const uint32_t& handle, const E_POPUP_RESPONSE& eResponse);
    void onResponseHidePopup(const uint32_t& clientSessionID, const uint32_t& handle, const E_POPUP_RESPONSE& eResponse);
    void onNotifyPopupResult(const uint32_t& clientSessionID, const uint32_t& handle, const E_POPUP_RESULT& eResult, const bool& isChecked);
    void onResponseUpdatePopup(const uint32_t& clientSessionID, const uint32_t& handle, const E_POPUP_RESPONSE& eResponse);
    void onNotifyStatusChanged(const uint32_t& clientSessionID, const uint32_t& handle, const E_POPUP_DISPLAY_STATUS& ePopupDisplayStatus);

    PopupProxy *m_popupProxy;
    SxmPopupServiceInterface *m_interface;
    //test code start
    OnBaseListener *m_baseListener;
    //test code end

};

#endif // SXMPOPUPSERVICE_H
