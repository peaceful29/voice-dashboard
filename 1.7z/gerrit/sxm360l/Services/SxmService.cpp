#include <QGuiApplication>

#include "SxmService.h"
#include "base/interface/OnBaseListener.h"
#include "sxm360l/Sxm360lProxy.h"
#include "DataExchange/DataController.h"
#include "Interfaces/SxmServiceInterface.h"

/*!
 * \brief SxmService::SxmService
 * \param _interface
 */
SxmService::SxmService(SxmServiceInterface *_interface)
    : m_interface(_interface)
{
    LOGI().writeFormatted("SxmService::SxmService called");
    m_proxy = nullptr;
    m_proxySync = nullptr;
}

/*!
 * \brief SxmService::initialize
 * \param engine
 */
void SxmService::initialize(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmService::initialize called");
    m_proxy = Sxm360lProxy::getInstance((BaseReceiver*)engine, HMI_APP_NAME_SXM360L);
    m_proxy->registerName(HMI_APP_NAME_SXM360L);

    m_proxySync = Sxm360lProxySync::getInstance(HMI_APP_NAME_SXM360L);
    m_proxySync->registerName(HMI_APP_NAME_SXM360L);
}

/*!
 * \brief SxmService::requestSATDiagnostics
 */
void SxmService::requestSATDiagnostics()
{
    LOGI().writeFormatted("SxmService::requestSATDiagnostics() called");
    if (m_proxy)
        m_proxy->requestSATDiagnostics();
}


/*!
 * \brief SxmService::requestSuperCategories
 */
void SxmService::requestSuperCategories()
{
    LOGI().writeFormatted("SxmService::requestSuperCategories() called");
    if (m_proxy)
        m_proxy->requestSuperCategories();
}

/*!
 * \brief SxmService::requestAllCategories
 */
void SxmService::requestAllCategories()
{
    LOGI().writeFormatted("SxmService::requestAllCategories() called");
    if (m_proxy)
        m_proxy->requestAllCategories();
}

/*!
 * \brief SxmService::requestCategories
 * \param superCategory
 */
void SxmService::requestCategories(const char *superCategory)
{
    LOGI().writeFormatted("SxmService::requestCategories() called supercategories %s", superCategory);
    if (m_proxy)
        m_proxy->requestCategories(superCategory);
}

/*!
 * \brief SxmService::requestChannels
 * \param category
 */
void SxmService::requestChannels(const char *category)
{
    LOGI().writeFormatted("SxmService::requestChannels called");
    if (m_proxy)
        m_proxy->requestChannels(category);
}

/*!
 * \brief SxmService::requestChannels
 */
void SxmService::requestChannels()
{
    LOGI().writeFormatted("SxmService::requestChannels() called");
    if (m_proxy)
        m_proxy->requestChannels();
}

/*!
 * \brief SxmService::requestChannelInformation
 * \param channelNumber
 */
void SxmService::requestChannelInformation(const uint32_t channelNumber)
{
    LOGI().writeFormatted("SxmService::requestChannelInformation() called");
    if (m_proxy)
        m_proxy->requestChannelInformation(channelNumber);
}

/*!
 * \brief SxmService::requestSmartFavorites
 */
void SxmService::requestSmartFavorites()
{
    LOGI().writeFormatted("SxmService::requestSmartFavorites() called");
    if (m_proxy)
        m_proxy->requestSmartFavorites();
}

/*!
 * \brief SxmService::requestPlayback
 * \param state
 */
void SxmService::requestPlayback(const PLAY_STATE state)
{
    LOGI().writeFormatted("SxmService::requestPlayback() called");
    if (m_proxy)
        m_proxy->requestPlayback(state);
}

/*!
 * \brief SxmService::requestTuneLastChannel
 */
void SxmService::requestTuneLastChannel()
{
    LOGI().writeFormatted("SxmService::requestTuneLastChannel() called");
    if (m_proxy)
        m_proxy->requestTuneLastChannel();
}

/*!
 * \brief SxmService::requestInitState
 */
void SxmService::requestInitState()
{
    LOGI().writeFormatted("SxmService::requestInitState() called");
    if (m_proxy)
        m_proxy->requestInitState();
}

/*!
 * \brief SxmService::requestInitSet
 * \param id
 * \param bFlag
 * \param msg
 */
void SxmService::requestInitSet(const int &id, const bool &bFlag, const char *msg)
{
    Q_UNUSED(id)
    Q_UNUSED(bFlag)
    Q_UNUSED(msg)
    LOGI().writeFormatted("SxmService::requestInitTest() called");
//    if (m_proxy)
//        m_proxy->requestInitSet(id, bFlag, msg);
}

/*!
 * \brief SxmService::requestFavorites
 */
void SxmService::requestFavorites()
{
    LOGI().writeFormatted("SxmService::requestFavorites() called");
    if (m_proxy)
        m_proxy->requestFavorites();
}

/*!
 * \brief SxmService::requestAddFavorite
 * \param channelNumber
 */
void SxmService::requestAddFavorite(const uint32_t channelNumber)
{
    LOGI().writeFormatted("SxmService::requestAddFavorite() called");
    if (m_proxy)
        m_proxy->requestAddFavorite(channelNumber);
}

/*!
 * \brief SxmService::requestRemoveFavorite
 * \param channelNumber
 */
void SxmService::requestRemoveFavorite(const uint32_t channelNumber)
{
    LOGI().writeFormatted("SxmService::requestRemoveFavorite() called");
    if (m_proxy)
        m_proxy->requestRemoveFavorite(channelNumber);
}

/*!
 * \brief SxmService::requestTuneFavorite
 * \param channelNumber
 */
void SxmService::requestTuneFavorite(const uint32_t channelNumber)
{
    LOGI().writeFormatted("SxmService::requestTuneFavorite() called");
    if (m_proxy)
        m_proxy->requestTuneFavorite(channelNumber);
}

void SxmService::requestMoveFavorite(const uint32_t index, const uint32_t new_index)
{
    LOGI().writeFormatted("SxmService::requestMoveFavorite() called index[%d] new_index[%d]", index, new_index);
    if (m_proxy)
        m_proxy->requestMoveFavorite(index, new_index);
}

/*!
 * \brief SxmService::requestTuneChannel
 * \param channelNumber
 */
void SxmService::requestTuneChannel(const uint32_t channelNumber)
{
    LOGI().writeFormatted("SxmService::requestTuneChannel() called");
    if (m_proxy)
        m_proxy->requestTuneChannel(channelNumber);
}

/*!
 * \brief SxmService::requestSeekChannel
 * \param action
 */
void SxmService::requestSeekChannel(const SEEK_ACTION action)
{
    LOGI().writeFormatted("SxmService::requestSeekChannel() called");
    if (m_proxy)
        m_proxy->requestSeekChannel(action);
}

/*!
 * \brief SxmService::requestSongAlerts
 */
void SxmService::requestSongAlerts()
{
    LOGI().writeFormatted("SxmService::requestSongAlerts() called");
    if (m_proxy)
        m_proxy->requestSongAlerts();
}

/*!
 * \brief SxmService::requestArtistAlerts
 */
void SxmService::requestArtistAlerts()
{
    LOGI().writeFormatted("SxmService::requestArtistAlerts() called");
    if (m_proxy)
        m_proxy->requestArtistAlerts();
}

void SxmService::requestArtistAndSongAlerts()
{
    LOGI().writeFormatted("SxmService::requestArtistAndSongAlerts() called");
    if (m_proxy)
        m_proxy->requestArtistAndSongAlerts();
}

/*!
 * \brief SxmService::requestAddSongAlert
 * \param songTitle
 */
void SxmService::requestAddSongAlert(const char* songTitle)
{
    LOGI().writeFormatted("SxmService::requestAddSongAlert() called");
    if (m_proxy)
        m_proxy->requestAddSongAlert(songTitle);
}

/*!
 * \brief SxmService::requestAddArtistAlert
 * \param artistName
 */
void SxmService::requestAddArtistAlert(const char* artistName)
{
    LOGI().writeFormatted("SxmService::requestAddArtistAlert() called");
    if (m_proxy)
        m_proxy->requestAddArtistAlert(artistName);
}

/*!
 * \brief SxmService::requestRemoveArtistAlert
 * \param artistName
 */
void SxmService::requestRemoveArtistAlert(const char *artistName)
{
    LOGI().writeFormatted("SxmService::requestRemoveArtistAlert() called");
    if (m_proxy)
        m_proxy->requestRemoveArtistAlert(artistName);
}

/*!
 * \brief SxmService::requestRemoveSongAlert
 * \param songTitle
 */
void SxmService::requestRemoveSongAlert(const char *songTitle)
{
    LOGI().writeFormatted("SxmService::requestRemoveSongAlert() called");
    if (m_proxy)
        m_proxy->requestRemoveSongAlert(songTitle);
}

/*!
 * \brief SxmService::requestRewind
 * \param step
 */
void SxmService::requestRewind(const uint32_t step)
{
    LOGI().writeFormatted("SxmService::requestRewind() called");
//    if (m_proxy)
//        m_proxy->requestRewind(step);
}

/*!
 * \brief SxmService::requestFastForward
 * \param step
 */
void SxmService::requestFastForward(const uint32_t step)
{
    LOGI().writeFormatted("SxmService::requestFastForward() called");
//    if (m_proxy)
//        m_proxy->requestFastForward(step);
}

/*!
 * \brief SxmService::requestJumpPoint
 * \param point
 */
void SxmService::requestJumpPoint(const uint32_t point)
{
    LOGI().writeFormatted("SxmService::requestJumpPoint() called");
//    if (m_proxy)
//        m_proxy->requestJumpPoint(point);
}


/*!
 * \brief SxmService::requestRecommendation
 */
void SxmService::requestRecommendation()
{
    LOGI().writeFormatted("SxmService::requestRecommendation() called");
    if (m_proxy)
        m_proxy->requestRecommendation();
}

/*!
 * \brief SxmService::requestListeningHistory
 */
void SxmService::requestListeningHistory()
{
//    LOGI().writeFormatted("SxmService::requestListeningHistory() called");
//    if (m_proxy)
//        m_proxy->requestListeningHistory();
    //make color Start
    LOGI().writeFormatted("SxmService::requestListeningHistory() called make color");
    DataController::instance()->eventListeningHistory(STATE_OK);
    //make color End
}

/*!
 * \brief SxmService::requestLastChannelInfo
 */
void SxmService::requestLastChannelInfo()
{
    LOGI().writeFormatted("SxmService::requestLastChannelInfo() called");
    if (m_proxy)
        m_proxy->requestLastChannelInfo();
}

void SxmService::requestGetChannelList(const int count)
{
    LOGI().writeFormatted("SxmService::requestGetChannelList() called");
    DataController::instance()->eventGetChannelList(count);
}

void SxmService::requestTestLossSignal()
{
    LOGI().writeFormatted("SxmService::requestTestLossSignal() called");
    DataController::instance()->eventSignalState(SIGNALNOTAVAILABLE);
//    DataController::instance()->eventAudioAvailability(AUDIONOTAVAILABLE);
}

/*!
 * \brief SxmService::requestResumingSatelliteOnCompleted
 */
void SxmService::requestResumingSatelliteOnCompleted()
{
    LOGI().writeFormatted("SxmService::requestResumingSatelliteOnCompleted() called");
    DataController::instance()->eventResumingSatelliteOnCompleted();
}

/*!
 * \brief SxmService::requestGetActiveProfiles
 */
void SxmService::requestGetActiveProfiles()
{
    LOGI().writeFormatted("SxmService::requestGetActiveProfiles() called");
    if (m_proxy)
        m_proxy->requestGetActiveProfiles();
}

/*!
 * \brief SxmService::requestCreateProfile
 * \param name
 */
void SxmService::requestCreateProfile(const char *name)
{
    LOGI().writeFormatted("SxmService::requestCreateProfile() called");
    if (m_proxy)
        m_proxy->requestCreateProfile(name);
}

/*!
 * \brief SxmService::requestSetDefaultProfile
 */
void SxmService::requestSetDefaultProfile()
{
    LOGI().writeFormatted("SxmService::requestSetDefaultProfile() called");
    if (m_proxy)
        m_proxy->requestSetDefaultProfile();
}
/*!
 * \brief SxmService::requestDeleteProfile
 */
void SxmService::requestDeleteProfile()
{
    LOGI().writeFormatted("SxmService::requestDeleteProfile() called");
    if (m_proxy)
        m_proxy->requestDeleteProfile();
}

/*!
 * \brief SxmService::requestModifyProfileName
 * \param name
 */
void SxmService::requestModifyProfileName(const char *name)
{
    LOGI().writeFormatted("SxmService::requestModifyProfileName() called");
    if (m_proxy)
        m_proxy->requestModifyProfileName(name);
}

/*!
 * \brief SxmService::requestModifyProfileAvatar
 * \param logoUrl
 */
void SxmService::requestModifyProfileAvatar(const char *logoUrl)
{
    LOGI().writeFormatted("SxmService::requestModifyProfileAvatar() called");
    if (m_proxy)
        m_proxy->requestModifyProfileAvatar(logoUrl);
}

/*!
 * \brief SxmService::requestGetSettingNotification
 */
void SxmService::requestGetSettingNotification()
{
    LOGI().writeFormatted("SxmService::requestGetSettingNotification() called");
    if (m_proxy)
        m_proxy->requestGetSettingNotification();
}

/*!
 * \brief SxmService::requestSetSettingNotification
 * \param state
 */
void SxmService::requestSetSettingNotification(const SETTING_NOTIFICATION_STATE state)
{
    LOGI().writeFormatted("SxmService::requestSetSettingNotification() called");
    if (m_proxy)
        m_proxy->requestSetSettingNotification(state);
}

//make color
void SxmService::requestRelatedList()
{
    LOGI().writeFormatted("SxmService::requestRelatedList() called");
    DataController::instance()->eventRelatedList();
}
//make color

/*!
 * \brief SxmService::requestAddFavoriteTeam
 * \param type
 */
void SxmService::requestAddFavoriteTeam(const SPORTS_TEAM_TYPE type)
{
    LOGI().writeFormatted("SxmService::requestAddFavoriteTeam() called");
    if (m_proxy)
        m_proxy->requestAddFavoriteTeam(type);
}

/*!
 * \brief SxmService::requestRemoveFavoriteTeam
 * \param teamId
 */
void SxmService::requestRemoveFavoriteTeam(const int teamId)
{
    LOGI().writeFormatted("SxmService::requestRemoveFavoriteTeam() called");
    if (m_proxy)
        m_proxy->requestRemoveFavoriteTeam(teamId);
}

/*!
 * \brief SxmService::requestGetTeams
 * \param leagueId
 */
void SxmService::requestGetTeams(const int leagueId)
{
    LOGI().writeFormatted("SxmService::requestGetTeams() called");
    if (m_proxy)
        m_proxy->requestGetTeams(leagueId);
}

/*!
 * \brief SxmService::requestGetLeague
 */
void SxmService::requestGetLeagues()
{
    LOGI().writeFormatted("SxmService::requestGetLeague() called");
    if (m_proxy)
        m_proxy->requestGetLeagues();
}

/*!
 * \brief SxmService::requestAddTeamAlerts
 * \param teamId
 */
void SxmService::requestAddTeamAlerts(const int teamId)
{
    LOGI().writeFormatted("SxmService::requestAddTeamAlerts() called");
    if (m_proxy)
        m_proxy->requestAddTeamAlerts(teamId);
}

/*!
 * \brief SxmService::requestRemoveTeamAlerts
 * \param teamId
 */
void SxmService::requestRemoveTeamAlerts(const int teamId)
{
    LOGI().writeFormatted("SxmService::requestRemoveTeamAlerts() called");
    if (m_proxy)
        m_proxy->requestRemoveTeamAlerts(teamId);
}

/*!
 * \brief SxmService::requestGetTeamAlerts
 */
void SxmService::requestGetTeamAlerts()
{
    LOGI().writeFormatted("SxmService::requestGetTeamAlerts() called");
    if (m_proxy)
        m_proxy->requestGetTeamAlerts();
}

void SxmService::requestGetFavoriteTeams()
{
    LOGI().writeFormatted("SxmService::requestGetFavoriteTeams() called");
    if (m_proxy)
        m_proxy->requestGetFavoriteTeams();
}

void SxmService::requestSatSubscriptionState()
{
    LOGI().writeFormatted("SxmService::requestSatSubscriptionState() called");
    if (m_proxy)
        m_proxy->requestSatSubscriptionState();
}

void SxmService::requestGetAntennaState()
{
    LOGI().writeFormatted("SxmService::requestGetAntennaState() called");
    ANTENNA_STATE state;
    if (m_proxy)
        m_proxySync->requestAntennaStateSync(state);
    DataController::instance()->setAntennaState(state);
}

/*!
 * \brief SxmService::requestGetLiveSports
 */
//void SxmService::requestGetLiveSports()
//{
//    LOGI().writeFormatted("SxmService::requestGetLiveSports() called");
//    if (m_proxy)
//        m_proxy->requestGetLiveSports();
//}

/*!
 * \brief SxmService::requestTuneLiveSports
 * \param leagueId
 */
//void SxmService::requestTuneLiveSports(const int leagueId)
//{
//    LOGI().writeFormatted("SxmService::requestTuneLiveSports() called");
//    if (m_proxy)
//        m_proxy->requestTuneLiveSports(leagueId);
//}

/*!
 * \brief SxmService::requestSwitchProfile
 * \param name
 */
void SxmService::requestSwitchProfile(const char *name)
{
    LOGI().writeFormatted("SxmService::requestSwitchProfile() called");
    if (m_proxy)
        m_proxy->requestSwitchProfile(name);
}

/*!
 * \brief SxmService::onSATDiagnostics
 * \param data
 */
void SxmService::onSATDiagnostics(const SXM_SATDIAGNOSTICS_T &data)
{
    LOGI().writeFormatted("SxmService::onSATDiagnostics() called");
    DataController::instance()->eventSATDiagnostics(data);
}
/*!
 * \brief SxmService::onInitState
 * \param state
 */
void SxmService::onInitState(const INIT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onInitState() called");
//    printf("\n\nSxm360lTest::onInitState() called\n");
//    printf("\n####################################\n");
//    printf("INIT_STATE %d", state);
//    printf("####################################\n");
//    int id = 0;
//    bool bFlag = true;
//    const char* msg = "TestInit";
    DataController::instance()->eventInitState(state);
}

/*!
 * \brief SxmService::onSuperCategories
 * \param state
 */
void SxmService::onSuperCategories(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onSuperCategories() called");
    DataController::instance()->eventSuperCategories(state);
}

/*!
 * \brief SxmService::onSuperCategories
 * \param state
 */
void SxmService::onAllCategories(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onAllCategories() called");
    DataController::instance()->eventAllCategories(state);
}

/*!
 * \brief SxmService::onCategories
 * \param state
 */
void SxmService::onCategories(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onCategories() called");
    DataController::instance()->eventCategories(state);
}

/*!
 * \brief SxmService::onChannels
 * \param state
 */
void SxmService::onChannels(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onChannels() called");
    DataController::instance()->eventChannels(state);
}

/*!
 * \brief SxmService::onChannelInformation
 * \param state
 */
void SxmService::onChannelInformation(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onChannelInformation() called");
    DataController::instance()->eventChannelInformation(state);

}

/*!
 * \brief SxmService::onSmartFavorites
 * \param state
 */
void SxmService::onSmartFavorites(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onSmartFavorites() called");
    DataController::instance()->eventSmartFavorites(state);
}

/*!
 * \brief SxmService::onSatSubscriptionState
 * \param state
 */
void SxmService::onSatSubscriptionState(const int &state)
{
    LOGI().writeFormatted("SxmService::onSatSubscriptionState() called");
    m_interface->onEventSatSubscriptionState(state);
//    DataController::instance()->eventSatSubscriptieventStatus(state);
}

/*!
 * \brief SxmService::onSignalState
 * \param state
 */
void SxmService::onSignalState(const SIGNAL_STATE &state)
{
    LOGI().writeFormatted("SxmService::onSignalState() called");
    DataController::instance()->eventSignalState(state);
}

/*!
 * \brief SxmService::onAudioAvailability
 * \param state
 */
void SxmService::onAudioAvailability(const AUD_AVAIL_STATE &state)
{
    LOGI().writeFormatted("SxmService::onAudioAvailability() called");
    DataController::instance()->eventAudioAvailability(state);
}


/*!
 * \brief SxmService::onFavorites
 */
void SxmService::onFavorites(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onFavorites() called");
    DataController::instance()->eventFavorites(state);
}

/*!
 * \brief SxmService::onAddFavorite
 * \param state
 */
void SxmService::onAddFavorite(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onAddFavorite() called");
    DataController::instance()->eventAddFavorite(state);
}

/*!
 * \brief SxmService::onRemoveFavorite
 * \param state
 */
void SxmService::onRemoveFavorite(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onRemoveFavorite() called");
    DataController::instance()->eventRemoveFavorite(state);
}

/*!
 * \brief SxmService::onTuneFavorite
 * \param state
 */
void SxmService::onTuneFavorite(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onTuneFavorite() called");
    DataController::instance()->eventTuneFavorite(state);
}

/*!
 * \brief SxmService::onPlayback
 * \param state
 */
void SxmService::onPlayback(const PLAY_STATE &state)
{
    LOGI().writeFormatted("SxmService::onPlayback() called");
    DataController::instance()->eventPlayback(state);
}

/*!
 * \brief SxmService::onTuneChannel
 * \param state
 * \param channelNumber
 */
void SxmService::onTuneChannel(const RESULT_STATE& state, const uint32_t& channelNumber)
{
//    Q_UNUSED(state)
//    Q_UNUSED(channelNumber)
    LOGI().writeFormatted("SxmService::onTuneChannel(tune_state) called");
    DataController::instance()->eventTuneChannel(state, channelNumber);
}

void SxmService::onTuneRequest(const LOADING_CHANNEL_INFORMATION_T &chInfo)
{
    LOGI().writeFormatted("SxmService::onTuneRequest called");
    DataController::instance()->eventTuneRequest(chInfo);
}

/*!
 * \brief SxmService::onTuneLastChannel
 * \param state
 * \param channelNumber
 */
void SxmService::onTuneLastChannel(const RESULT_STATE &state, const uint32_t &channelNumber)
{
    Q_UNUSED(state)
    Q_UNUSED(channelNumber)
    LOGI().writeFormatted("SxmService::onTuneLastChannel(tune_state) called");
    //fix onchannelInfomation not occurs
    DataController::instance()->eventTuneLastChannel(state, channelNumber);
}

/*!
 * \brief SxmService::onSeekChannel
 * \param state
 */
void SxmService::onSeekChannel(const RESULT_STATE& state, const uint32_t& channelNumber)
{
//    Q_UNUSED(state)
//    Q_UNUSED(channelNumber)
    LOGI().writeFormatted("SxmService::onSeekChannel() called CHANNEL NUMBER [%d]", channelNumber);
    DataController::instance()->eventSeekChannel(state, channelNumber);
}

/*!
 * \brief SxmService::onAddSongAlert
 * \param state
 */
void SxmService::onAddSongAlert(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onAddSongAlert() called");
    DataController::instance()->eventAddSongAlert(state);
}
/*!
 * \brief SxmService::onRemoveArtistAlert
 * \param state
 */
void SxmService::onRemoveArtistAlert(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onRemoveArtistAlert() called");
    DataController::instance()->eventRemoveArtistAlert(state);
}
/*!
 * \brief SxmService::onRemoveSongAlert
 * \param state
 */
void SxmService::onRemoveSongAlert(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onRemoveSongAlert() called");
    DataController::instance()->eventRemoveSongAlert(state);
}

/*!
 * \brief SxmService::onAddArtistAlert
 * \param state
 */
void SxmService::onAddArtistAlert(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onAddArtistAlert() called");
    DataController::instance()->eventAddArtistAlert(state);
}

/*!
 * \brief SxmService::onRewind
 * \param state
 */
void SxmService::onRewind(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onRewind() called");
    DataController::instance()->eventRewind(state);
}

/*!
 * \brief SxmService::onFastForward
 * \param state
 */
void SxmService::onFastForward(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onFastForward() called");
    DataController::instance()->eventFastForward(state);
}

/*!
 * \brief SxmService::onJumpPoint
 * \param state
 */
void SxmService::onJumpPoint(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onJumpPoint() called");
    DataController::instance()->eventJumpPoint(state);
}

/*!
 * \brief SxmService::onRecommendation
 */
void SxmService::onRecommendation(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onRecommendation() called state %d\n", state);
    DataController::instance()->eventRecommendation(state);
}

/*!
 * \brief SxmService::onListeningHistory
 */
void SxmService::onListeningHistory(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onListeningHistory() called state %d\n", state);
    DataController::instance()->eventListeningHistory(state);
}

/*!
 * \brief SxmService::onLastChannelInfo
 * \param state
 */
void SxmService::onLastChannelInfo(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onLastChannelInfo() called state %d\n", state);
    DataController::instance()->eventLastChannelInfo(state);
}

/*!
 * \brief SxmService::onGetActiveProfiles
 * \param state
 */
void SxmService::onGetActiveProfiles(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onGetActiveProfiles() called state %d\n", state);
    DataController::instance()->eventGetActiveProfiles(state);
}

/*!
 * \brief SxmService::onCreateProfile
 * \param state
 */
void SxmService::onCreateProfile(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onCreateProfile() called state %d\n", state);
    DataController::instance()->eventCreateProfile(state);
}

/*!
 * \brief SxmService::onSetDefaultProfile
 * \param state
 */
void SxmService::onSetDefaultProfile(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onSetDefaultProfile() called state %d\n", state);
    DataController::instance()->eventSetDefaultProfile(state);
}

/*!
 * \brief SxmService::onSwitchProfile
 * \param state
 */
void SxmService::onSwitchProfile(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onSwitchProfile() called state %d\n", state);
    DataController::instance()->eventSwitchProfile(state);
}

/*!
 * \brief SxmService::onDeleteProfile
 * \param state
 */
void SxmService::onDeleteProfile(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onDeleteProfile() called state %d\n", state);
    DataController::instance()->eventDeleteProfile(state);
}

/*!
 * \brief SxmService::onModifyProfileName
 * \param state
 */
void SxmService::onModifyProfileName(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onModifyProfileName() called state %d\n", state);
    DataController::instance()->eventModifyProfileName(state);
}

/*!
 * \brief SxmService::onModifyProfileAvatar
 * \param state
 */
void SxmService::onModifyProfileAvatar(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onModifyProfileAvatar() called state %d\n", state);
    DataController::instance()->eventModifyProfileAvatar(state);
}

/*!
 * \brief SxmService::onGetSettingNotification
 * \param state
 */
void SxmService::onGetSettingNotification(const SETTING_NOTIFICATION_STATE &state)
{
    LOGI().writeFormatted("SxmService::onGetSettingNotification() EnableNotification %d", state.EnableNotification);
    LOGI().writeFormatted("SxmService::onGetSettingNotification() ArtistAndSong %d", state.ArtistAndSong);
    LOGI().writeFormatted("SxmService::onGetSettingNotification() Sports %d", state.Sports);
    LOGI().writeFormatted("SxmService::onGetSettingNotification() ContinueListening %d", state.ContinueListening);
    DataController::instance()->eventGetSettingNotification(state);
}

/*!
 * \brief SxmService::onSetSettingNotification
 * \param state
 */
void SxmService::onSetSettingNotification(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onSetSettingNotification() called state %d\n", state);
    DataController::instance()->eventSetSettingNotification(state);
}

/*!
 * \brief SxmService::onAddFavoriteTeam
 */
void SxmService::onAddFavoriteTeam(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onAddFavoriteTeam() called state %d\n", state);
    DataController::instance()->eventAddFavoriteTeam(state);
}

/*!
 * \brief SxmService::onRemoveFavoriteTeam
 */
void SxmService::onRemoveFavoriteTeam(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onRemoveFavoriteTeam() called state %d\n", state);
    DataController::instance()->eventRemoveFavoriteTeam(state);
}

/*!
 * \brief SxmService::onGetTeams
 */
void SxmService::onGetTeams(const RESULT_STATE& state, const int& count)
{
    LOGI().writeFormatted("SxmService::onGetTeams() called state %d, count %d\n", state, count);
    DataController::instance()->eventGetTeams(state, count);
}

/*!
 * \brief SxmService::onGetLeague
 */
void SxmService::onGetLeagues(const SPORTS_LEAGUE_T& data)
{
    LOGI().writeFormatted("SxmService::onGetLeague() called");
    DataController::instance()->eventGetLeagues(data);
}

/*!
 * \brief SxmService::onAddTeamAlerts
 */
void SxmService::onAddTeamAlerts(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onAddTeamAlerts() called state %d\n", state);
    DataController::instance()->eventAddTeamAlerts(state);
}

/*!
 * \brief SxmService::onRemoveTeamAlerts
 */
void SxmService::onRemoveTeamAlerts(const RESULT_STATE& state)
{
    LOGI().writeFormatted("SxmService::onRemoveTeamAlerts() called state %d\n", state);
    DataController::instance()->eventRemoveTeamAlerts(state);

}

/*!
 * \brief SxmService::onGetTeamAlerts
 */
void SxmService::onGetTeamAlerts(const SPORTS_TEAM_ALERTS_T& data)
{
    LOGI().writeFormatted("SxmService::onGetTeamAlerts() called");
    DataController::instance()->eventGetTeamAlerts(data);
}

void SxmService::onMpfaValidate(const MPFA_RET_STATE &state)
{

}

void SxmService::onRelatedContents(const RESULT_STATE &state)
{

}

void SxmService::onMpfaSelect(const MPFA_RET_STATE &state)
{

}

void SxmService::onAntennaState(const ANTENNA_STATE &state)
{
    LOGI().writeFormatted("SxmService::onAntennaState() called");
    DataController::instance()->eventAntennaState(state);
}

///*!
// * \brief SxmService::onGetLiveSports
// */
//void SxmService::onGetLiveSports()
//{
//LOGI().writeFormatted("SxmService::onGetLiveSports() called");
//}

///*!
// * \brief SxmService::onTuneLiveSports
// */
//void SxmService::onTuneLiveSports()
//{
//    LOGI().writeFormatted("SxmService::onTuneLiveSports() called");
//}

void SxmService::onGetFavoriteTeams(const SPORTS_TEAM_FAVORITE_T &data)
{
    LOGI().writeFormatted("SxmService::onTuneLiveSports() called");
    DataController::instance()->eventGetFavoriteTeams(data);
}

/*!
 * \brief SxmService::onArtistAlerts
 * \param state
 */
void SxmService::onArtistAlerts(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onArtistAlerts() called state %d\n", state);
    DataController::instance()->eventArtistAlerts(state);
}
/*!
 * \brief SxmService::onSongAlerts
 * \param state
 */
void SxmService::onSongAlerts(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onSongAlerts() called state %d\n", state);
    DataController::instance()->eventSongAlerts(state);
}

void SxmService::onArtistAndSongAlerts(const RESULT_STATE &state)
{
    LOGI().writeFormatted("SxmService::onArtistAndSongAlerts() called state %d\n", state);
    DataController::instance()->eventArtistAndSOngAlerts(state);
}
