#ifndef SXMAPPSERVICE_H
#define SXMAPPSERVICE_H

#include <QGuiApplication>

// Common Header
#include "hmi/AppNameDef.h"
#include "hmi/AppRoleDef.h"
#include "hmi/WindowNameDef.h"

//Application Service Header
#include "appservice/AppMsgDef.h"
#include "appservice/AppProxy.h"
#include "appservice/IOnAppListener.h"
#include "appservice/BrAppListener.h"
#include "appservice/AppServiceProviderDef.h"
#include "appservice/AppServiceProvider.h"

#include "Common/Utils.h"


class OnBaseListener;
class SxmAppServiceInterface;

class SxmAppService: public IOnAppListener, public BrAppListener
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
public:
    explicit SxmAppService(SxmAppServiceInterface * _interface);
    virtual ~SxmAppService();

    void initialize(OnBaseListener* engine);

    void registerApplication();

    void requestToGoBack();
    void requestToGoApplication(const int& requestID, const INTENT_T& tIntent);
    void requestToGoApplication(const int& requestID, const char* strAppBinaryName, const char* strIntent=STRING_DATA_NONE);
    void requestToGoApplication(const int& requestID, const char* strAppBinaryName, const E_SHOW_OPT& eShowOption, const char* strIntent);

    void requestToGoApplication(const int& requestID, const char* strAppBinaryName, const char* strAppRole, const char* strIntent, const E_SHOW_OPT& eShowOpt=E_SHOW_OPT_CLEAR_AND_ADD);
    void requestToGoApplication(const int& requestID, const char* strAppRole, const char* strIntent, const E_SHOW_OPT& eShowOption); // Target IP6


    void requestToShowSystemComponent(const int& requestID, const E_SYSTEM_COMPONENT& eSystemComponent, const char* strData=STRING_DATA_NONE);
    void requestToHideSystemComponent(const int& requestID, const E_SYSTEM_COMPONENT& eSystemComponent, const char* strData=STRING_DATA_NONE);
//    void requestToGoApplication(const int& requestId, const APP_INFO_T& tAppInfo);
    void requestSpeechModeLaunchingBaseFeature();

private:
    void onGoBackResult(const int& requestID, const E_REQ_RESULT_MSG& eResult);
    void onGoApplicationResult(const int& requestID, const E_REQ_RESULT_MSG& eResult);
    void onRegisterApplicationResult(const int& requestID, const E_REQ_RESULT_MSG& eResult) override;
    void onCmdShowApplication(const int& requestID, const char* strAppRole, const char* strIntent) override;
    void onCmdActivateApplication(const int &requestID, const bool &bActivation) override;
    void onCmdHideApplication(const int& requestID, const char* strAppRole, const char* strIntent);
    void onCmdResumeApplication(const int& requestID, const char* strAppRole, const char* strIntent);
    void onCmdCreateAppWindow(const int& requestID, const char* strAppRole, const char* strIntent);
    void onCmdShowAppWindow(const int& requestID, const char* strAppRole, const char* strIntent);
    void onCmdDestroyAppWindow(const int& requestID, const char* strAppRole, const char* strIntent);
    void onCmdReadyToSuspendSystem(const int& requestID);
    void onCmdSuspendSystem(const int& requestID);
    void onCmdReadyToResumeSystem(const int& requestID);
    void onCmdResumeSystem(const int& requestID);

    void onShowSystemComponentResult(const int& requestID, const E_REQ_RESULT_MSG& eResult);
    void onHideSystemComponentResult(const int& requestID, const E_REQ_RESULT_MSG& eResult);

    void onCmdGoBack(const int& requestID);
    void onButtonEvent(const E_SWITCH& eSwitchType, const E_BUTTON& eButton, const E_ACTION& eAction);
    void onRotaryEvent(const E_ROTARY& eRotary, const E_ROTATION& eRotation, const int& step);

    AppProxy* m_proxy;
//    E_HMI_APP_ID m_appId;
    bool m_showed;
    SxmAppServiceInterface *m_interface;

    bool m_isRequestingLaunchBaseFeature;
};

#endif // SXMAPPSERVICE_H
