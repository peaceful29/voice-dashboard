#include <QGuiApplication>

#include "SpeechService.h"
#include "SxmSpeechServiceInterface.h"
#include "DataController.h"
#include "ScreenList.h"


SpeechService::SpeechService(SxmSpeechServiceInterface *interface)
    : m_interface(interface)
    , m_nReqID(0)
    , m_selectCommand("")
    , m_absoluteIdx(-1)
{
    m_proxy = nullptr;
}

SpeechService::~SpeechService()
{
    m_proxy = nullptr;
}

void SpeechService::initialize(OnBaseListener *engine)
{
    m_proxy = SpeechLib::SpeechProxy::getInstance((BaseReceiver*)engine, HMI_APP_NAME_SXM360L);
    m_proxy->registerName(HMI_APP_NAME_SXM360L);
}

void SpeechService::onTestCompleted(const char* msg, const int& id, const bool& bFlag)
{
    Q_UNUSED(msg);
    Q_UNUSED(id);
    Q_UNUSED(bFlag);

    LOGI().writeFormatted("[SpeechService::onTestCompleted]");
}

void SpeechService::onRequestSystemSettingGet(const int& requestID)
{
    Q_UNUSED(requestID);
    LOGI().writeFormatted("[SpeechService::onRequestSystemSettingGet]");
}

void SpeechService::onRequestSystemSettingSet(const int& requestID)
{
    Q_UNUSED(requestID);
    LOGI().writeFormatted("[SpeechService::onRequestSystemSettingSet]");
}

void SpeechService::onResponseToGetSpeechLanguage(const int& requestID)
{
    Q_UNUSED(requestID);
    LOGI().writeFormatted("[SpeechService::onResponseToGetSpeechLanguage]");
}

//void SpeechService::onTtsPlay(const int32_t& nReqID, const TTS_PLAY_RESULT_E& eResult)
//{
//    LOGI().writeFormatted("[SpeechService::onTtsPlay]");
//}

//void SpeechService::onTtsPlayFile(const int32_t& nReqID, const TTS_PLAY_RESULT_E& eResult)
//{
//    LOGI().writeFormatted("[SpeechService::onTtsPlayFile]");
//}

//void SpeechService::onTtsStop(const int32_t& nReqID, const TTS_STOP_RESULT_E& eResult)
//{
//    LOGI().writeFormatted("[SpeechService::onTtsStop]");
//}

//void SpeechService::onTtsPause(const int32_t& nReqID, const TTS_PAUSE_RESULT_E& eResult)
//{
//    LOGI().writeFormatted("[SpeechService::onTtsPause]");
//}

//void SpeechService::onTtsResume(const int32_t& nReqID, const TTS_RESUME_RESULT_E& eResult)
//{
//    LOGI().writeFormatted("[SpeechService::onTtsResume]");
//}

//void SpeechService::onResponse_TtsPlay(const int32_t& nReqID, const TTS_PLAY_RESULT_E& eResult, const int32_t& nSessionID)
//{
//    LOGI().writeFormatted("[SpeechService::onResponse_TtsPlay]");
//}

//void SpeechService::onResponse_TtsPlayTextFile(const int32_t& nReqID, const TTS_PLAY_RESULT_E& eResult, const int32_t& nSessionID)
//{
//    LOGI().writeFormatted("[SpeechService::onResponse_TtsPlayTextFile]");
//}

//void SpeechService::onResponse_TtsEnd(const int32_t& nReqID, const TTS_END_RESULT_E& eResult, const int32_t& nSessionID)
//{
//    LOGI().writeFormatted("[SpeechService::onResponse_TtsEnd]");
//}

//void SpeechService::onResponse_TtsStop(const int32_t& nReqID, const TTS_STOP_RESULT_E& eResult, const int32_t& nSessionID)
//{
//    LOGI().writeFormatted("[SpeechService::onResponse_TtsStop]");
//}

//void SpeechService::onResponse_TtsPause(const int32_t& nReqID, const TTS_PAUSE_RESULT_E& eResult, const int32_t& nSessionID)
//{
//    LOGI().writeFormatted("[SpeechService::onResponse_TtsPause]");
//}

//void SpeechService::onResponse_TtsResume(const int32_t& nReqID, const TTS_RESUME_RESULT_E& eResult, const int32_t& nSessionID)
//{
//    LOGI().writeFormatted("[SpeechService::onResponse_TtsResume]");
//}

void SpeechService::onResponse_PTT_LONGPRESS(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_PTT_LONGPRESS]");
}

void SpeechService::onResponse_ABORT(const E_SSVC_RESULT& eResult)
{
    LOGI().writeFormatted("[SpeechService::onResponse_ABORT]Result[%d]", eResult);
}

void SpeechService::onResponse_ABORT_SILENT(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_ABORT_SILENT]");
}

void SpeechService::onResponse_CMD_START(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_CMD_START]");
}

void SpeechService::onResponse_GUI_SCROLL_START(const E_SSVC_RESULT& eResult)
{
    LOGI().writeFormatted("[SpeechService::onResponse_GUI_SCROLL_START][%d]", eResult);
}

void SpeechService::onResponse_GUI_SCROLL_STOP(const E_SSVC_RESULT& eResult)
{
    LOGI().writeFormatted("[SpeechService::onResponse_GUI_SCROLL_STOP][%d]", eResult);
}

void SpeechService::onResponse_TP_SELECT(const E_SSVC_RESULT& eResult)
{
    LOGI().writeFormatted("[SpeechService::onResponse_TP_SELECT] at %d",m_absoluteIdx);
}

void SpeechService::onResponse_SELECT(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_SELECT]");
}

void SpeechService::onResponse_VOICEENROLMENT(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_VOICEENROLMENT]");
}

void SpeechService::onResponse_TUTORIAL_START(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_TUTORIAL_START]");
}

void SpeechService::onResponse_System_VEInfoSet(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_System_VEInfoSet]");
}

void SpeechService::onResponse_System_VEEditUpdate(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_System_VEEditUpdate]");
}

void SpeechService::onResponse_System_VEFeature(const SPEECH_VE_CATEGORY_ST& listVECategory, const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(listVECategory);
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_System_VEFeature]");
}

void SpeechService::onResponse_System_VEByCategory(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_System_VEByCategory]");
}

void SpeechService::onResponse_SCFA_CommandCategoryRequest(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_SCFA_CommandCategoryRequest]");
}

void SpeechService::onResponse_SCFA_CommandlistRequest(const E_SSVC_RESULT& eResult)
{
    Q_UNUSED(eResult);
    LOGI().writeFormatted("[SpeechService::onResponse_SCFA_CommandlistRequest]");
}

void SpeechService::onRequest_LANGUAGE_CHANGE(const int32_t& nReqID, const std::string& strLang)
{
    Q_UNUSED(nReqID);
    Q_UNUSED(strLang);
    LOGI().writeFormatted("[SpeechService::onRequest_LANGUAGE_CHANGE]");
}

void SpeechService::onRequest_SHUTDOWN(const int32_t& nReqID)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onRequest_SHUTDOWN]");
}

void SpeechService::onRequest_USER_DATA_RESET(const int32_t& nReqID)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onRequest_USER_DATA_RESET]");
}

void SpeechService::onRequest_PTT(const int32_t& nReqID)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onRequest_PTT]");
}

void SpeechService::onRequest_SCFA_TeleprompterShow(const int32_t& nReqID)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onRequest_SCFA_TeleprompterShow]");
}

void SpeechService::onRequest_SCFA_ListShow(const int32_t& nReqID)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onRequest_SCFA_ListShow]");
}

void SpeechService::onRequest_SCFA_TeleprompterHide(const int32_t& nReqID)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onRequest_SCFA_TeleprompterHide]");
}

void SpeechService::onRequest_SCFA_TutorialChapterPlay(const int32_t& nReqID, const int32_t& nChapter)
{
    Q_UNUSED(nReqID);
    Q_UNUSED(nChapter);
    LOGI().writeFormatted("[SpeechService::onRequest_SCFA_TutorialChapterPlay]");
}

void SpeechService::onRequest_System_SELECTEventRequest(const int32_t& nReqID)
{
//    Q_UNUSED(nReqID);
    LOGI().writeFormatted("SpeechService::onRequest_System_SELECTEventRequest m_selectCommand(%s)", m_selectCommand.toStdString().c_str());
    m_proxy->response_System_SELECTEventRequest(nReqID, m_selectCommand.toStdString(), E_SSVC_RESULT_OK);
    m_selectCommand = QString("");
}

void SpeechService::onRequest_SCFA_ScreenShow(const int32_t& nReqID, const std::string& strContext)
{
    Q_UNUSED(nReqID);
    Q_UNUSED(strContext);
    LOGI().writeFormatted("[SpeechService::onRequest_SCFA_ScreenShow]");

    if (m_interface != nullptr && strContext == "SCFA_SCREEN_CONTEXT_CURRENT"){
        m_interface->requestLaunchingBaseFeature();
    }
}

void SpeechService::onRequest_System_StateSet(const int32_t& nReqID, const std::string& strState, const std::string& strAction)
{
    Q_UNUSED(nReqID);
    Q_UNUSED(strState);
    Q_UNUSED(strAction);
    LOGI().writeFormatted("[SpeechService::onRequest_System_StateSet]");
    m_proxy->response_System_StateSet(nReqID, E_SSVC_RESULT_OK);
}

void SpeechService::onRequest_SCFA_ListFocusGet(const int32_t& nReqID)
{
    LOGI().writeFormatted("[SpeechService::onRequest_SCFA_ListFocusGet], request at %d", m_absoluteIdx);
    m_proxy->response_SCFA_ListFocusGet(nReqID, m_absoluteIdx, E_SSVC_RESULT_OK);
    m_absoluteIdx = -1;
}

void SpeechService::onRequest_Tuner_CategorySelectedGet(const int &nReqID)
{
    LOGI().writeFormatted("[SpeechService::onRequest_Tuner_CategorySelectedGet]%s",m_Name.toStdString().c_str());
    m_proxy->response_Tuner_CategorySelectedGet(nReqID, m_Id, m_Name.toStdString().c_str(), SPEECH_TUNER_WAVEBAND_SAT, E_SSVC_RESULT_OK);
}

void SpeechService::onRequest_Tuner_TeamSelectedGet(const int &nReqID)
{
    LOGI().writeFormatted("[SpeechService::onRequest_Tuner_TeamSelectedGet]");
    m_proxy->response_Tuner_TeamSelectedGet(nReqID, m_Id ,m_Name.toStdString().c_str(), E_SSVC_RESULT_OK);
}

void SpeechService::onRequest_Tuner_StationSelectedGet(const int &nReqID)
{
    LOGI().writeFormatted("[SpeechService::onRequest_Tuner_StationSelectedGet]");
    m_proxy->response_Tuner_StationSelectedGet(nReqID, m_Id ,m_Name.toStdString().c_str(), SPEECH_TUNER_WAVEBAND_SAT, E_SSVC_RESULT_OK);
}

void SpeechService::onRequest_Tuner_SDARSChannelSelectedGet(const int &nReqID)
{
    LOGI().writeFormatted("[SpeechService::onRequest_Tuner_SDARSChannelSelectedGet]");
    m_proxy->response_Tuner_SDARSChannelSelectedGet(nReqID, m_absoluteIdx, E_SSVC_RESULT_OK);
}

void SpeechService::onRequest_SCFA_ListFocusSet(const int32_t& nReqID, const int32_t& nAbsoluteIdx)
{
    m_nReqID = nReqID;
    LOGI().writeFormatted("[SpeechService::onRequest_SCFA_ListFocusSet][%d]", nAbsoluteIdx);
    if (m_interface != nullptr){
        m_interface->onScfaListFocusSet(nAbsoluteIdx);
    }
}

void SpeechService::onRequest_SCFA_ListPageSet(const int32_t& nReqID, const std::string& strPageNavigation)
{
    m_nReqID = nReqID;

    E_VIDEO_TUNER_PAGE_NAVIGATION pageNavigation = E_VIDEO_TUNER_PAGE_NAVIGATION_UNKNOWN;
    LOGI().writeFormatted("[SpeechService::onRequest_SCFA_ListPageSet][%s]", strPageNavigation.c_str());   
    if (strPageNavigation == "SCFA_LIST_PAGE_DOWN"){
        pageNavigation = E_VIDEO_TUNER_PAGE_NAVIGATION_DOWN;
    }else if (strPageNavigation == "SCFA_LIST_PAGE_UP"){
        pageNavigation = E_VIDEO_TUNER_PAGE_NAVIGATION_UP;
    }
    if (m_interface != nullptr){
        m_interface->onScfaListPage(pageNavigation);
    }
}

void SpeechService::onRequest_SCFA_ListDataGet(const int32_t& nReqID, const int32_t& nLineNum)
{
    m_nReqID = nReqID;

    LOGI().writeFormatted("[SpeechService::onRequest_SCFA_ListDataGet]");
    if (m_interface != nullptr){
        m_interface->onScfaListDataGet(nLineNum);
    }
}

void SpeechService::onRequest_System_VEEventRequest(const int32_t& nReqID)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onRequest_System_VEEventRequest]");
}

void SpeechService::onRequest_System_VESelectedGet(const int32_t& nReqID)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onRequest_System_VESelectedGet]");
}

void SpeechService::onRequest_System_VEEventConfirm(const int32_t& nReqID, const int32_t& nEventId, const std::string& strVEResult)
{
    Q_UNUSED(nReqID);
    Q_UNUSED(nEventId);
    Q_UNUSED(strVEResult);
    LOGI().writeFormatted("[SpeechService::onRequest_System_VEEventConfirm]");
}

void SpeechService::onSetSpeechLang(const int& nReqID, const E_SSVC_RESULT& eRet)
{
    Q_UNUSED(nReqID);
    Q_UNUSED(eRet);
    LOGI().writeFormatted("[SpeechService::onSetSpeechLang]");
}

void SpeechService::onSetVoiceSettings(const int& nReqID, const E_SSVC_RESULT& eRet)
{
    Q_UNUSED(nReqID);
    Q_UNUSED(eRet);
    LOGI().writeFormatted("[SpeechService::onSetVoiceSettings]");
}

void SpeechService::onResponse_Speech_SDARSTeamData(const int &nReqID, const E_SSVC_RESULT &eResult)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onResponse_Speech_SDARSTeamData][%d]", eResult);
    if (eResult == E_SSVC_RESULT_OK && m_interface != nullptr){
        m_interface->onSpeechSdarsTeamData();
    }
}

void SpeechService::onResponse_Speech_SDARSChannelData(const int &nReqID, const E_SSVC_RESULT &eResult)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onResponse_Speech_SDARSChannelData][%d]", eResult);
    if (eResult == E_SSVC_RESULT_OK && m_interface != nullptr){
        m_interface->onSpeechSdarsDataChannel();
    }
}

void SpeechService::onResponse_Speech_SDARSCategoryData(const int &nReqID, const E_SSVC_RESULT &eResult)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onResponse_Speech_SDARSChannelData][%d]", eResult);
    if (eResult == E_SSVC_RESULT_OK && m_interface != nullptr){
        m_interface->onSpeechSdarsCategorySatList();
    }
}

void SpeechService::onResponse_Speech_SDARSChannelData(const int &nReqID, const char *szCategoryName, const E_SSVC_RESULT &eResult)
{
    Q_UNUSED(nReqID);
    LOGI().writeFormatted("[SpeechService::onResponse_Speech_SDARSChannelData][%d]", eResult);
    if (eResult == E_SSVC_RESULT_OK && m_interface != nullptr){
        m_interface->onSpeechSdarsCategoryChannels(QString(szCategoryName));
    }
}

void SpeechService::requestPttLongPress()
{
    LOGI().writeFormatted("[SpeechService::requestPttLongPress]");
    m_proxy->request_PTT_LONGPRESS();
}

void SpeechService::requestTpSelect(const int nAbsoluteIdx)
{
    LOGI().writeFormatted("[SpeechService::requestSelect]");
    m_absoluteIdx = nAbsoluteIdx;
    m_proxy->request_TP_SELECT();
}

void SpeechService::requestScrollStart()
{
    LOGI().writeFormatted("[SpeechService::requestScrollStart]");
    m_proxy->request_GUI_SCROLL_START();
}

void SpeechService::requestScrollStop()
{
    LOGI().writeFormatted("[SpeechService::requestScrollStop]");
    m_proxy->request_GUI_SCROLL_STOP();
}

void SpeechService::responseListPage(const bool result)
{
    LOGI().writeFormatted("[SpeechService::responseListPage][%d]", result);
    if (result == true)
        m_proxy->response_SCFA_ListPageSet(m_nReqID, E_SSVC_RESULT_OK);
    else
        m_proxy->response_SCFA_ListPageSet(m_nReqID, E_SSVC_RESULT_ERROR);
}

void SpeechService::responseLineNumAbsoluteIdx(int absoluteIdx)
{
    LOGI().writeFormatted("[SpeechService::responseLineNumAbsoluteIdx][%d]", absoluteIdx);
    m_proxy->response_SCFA_ListDataGet(m_nReqID, absoluteIdx, E_SSVC_RESULT_OK);
}

void SpeechService::responseListFocusSet(bool result)
{
    if (result == true)
        m_proxy->response_SCFA_ListFocusSet(m_nReqID, E_SSVC_RESULT_OK);
    else
        m_proxy->response_SCFA_ListFocusSet(m_nReqID, E_SSVC_RESULT_ERROR);
}

void SpeechService::requestSdarsTeamData()
{
    LOGI().writeFormatted("[SpeechService::requestSdarsTeamData]");
    m_proxy->request_Speech_SDARSTeamData(0);
}
void SpeechService::requestAbort()
{
    LOGI().writeFormatted("[SpeechService::requestAbort]");
    m_proxy->request_ABORT();
}

void SpeechService::requestSdarsDataChannel()
{
    LOGI().writeFormatted("[SpeechService::requestSdarsDataChannel]");
    m_proxy->request_Speech_SDARSChannelData(0);
}
void SpeechService::responseScfaScreenShow(int requestId, int eResult)
{
    m_proxy->response_SCFA_ScreenShow(0, E_SSVC_RESULT_OK);
}

void SpeechService::requestSdarsCategorySatList()
{
    LOGI().writeFormatted("[SpeechService::requestSdarsCategorySatList]");
    m_proxy->request_Speech_SDARSCategoryData(0);
}

void SpeechService::requestSdarsCategoryChannel(QString category)
{
    LOGI().writeFormatted("[SpeechService::requestSdarsCategoryChannel][%s]", category.toStdString().c_str());
    m_proxy->request_Speech_SDARSChannelData(0, category.toStdString().c_str());
}

void SpeechService::requestSelect(QString selectItem, QString command)
{
    uint32_t    currentScreenId = ScreenListInstance()->getCurrentScreenID();
    LOGI().writeFormatted("[SpeechService::requestSelect]");
    m_selectCommand = command;
    switch (currentScreenId) {
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_SAT:
        m_absoluteIdx = selectItem.toInt();
        LOGI().writeFormatted(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> absoluteIdx( %d), command( %s)",
                               m_absoluteIdx, command.toStdString().c_str());
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_STATION_SAT:
        m_absoluteIdx = selectItem.toInt();
        LOGI().writeFormatted(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> absoluteIdx( %d), command( %s)",
                               m_absoluteIdx, command.toStdString().c_str());
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CHANNELLIST:
        m_absoluteIdx = selectItem.toInt();
        LOGI().writeFormatted(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> channel( %d), command( %s)",
                               m_absoluteIdx, command.toStdString().c_str());
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_SAT_LIST:
        m_Name = selectItem;
        LOGI().writeFormatted(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> category name( %s), command( %s)",
                               m_Name.toStdString().c_str(), command.toStdString().c_str());
        break;

    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_CATEGORY_STATION_LIST_SAT:
        break;
    default:
        break;
    }

    m_proxy->request_SELECT();
}

void SpeechService::requestSelect(QString selectItem, QString selectId, QString command)
{
    uint32_t    currentScreenId = ScreenListInstance()->getCurrentScreenID();
    LOGI().writeFormatted("[SpeechService::requestSelect]");
    m_selectCommand = command;
    switch (currentScreenId) {
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_SDARS_TEAM:
        m_Id = selectId.toInt();
        m_Name = selectItem;
        break;
    case ScreenIdentifier::E_HMI_VIEW_ID_SXM_SPEECH_MODE_STATION_LIST_SAT:
        m_Id = selectId.toInt();
        m_Name = selectItem;
        break;
    default:
        break;
    }
    m_proxy->request_SELECT();
}


void SpeechService::requestGuiScroll(E_VIDEO_TUNER_SCROLL scroll)
{
    if (scroll == E_VIDEO_TUNER_SCROLL_START)
        m_proxy->request_GUI_SCROLL_START();
    else if (scroll == E_VIDEO_TUNER_SCROLL_STOP)
        m_proxy->request_GUI_SCROLL_STOP();
}
