#ifndef SPEECHSERVICE_H
#define SPEECHSERVICE_H

#include "speech/SpeechMsgDef.h"
#include "speech/IOnSpeechListener.h"
#include "speech/SpeechProxy.h"
#include "hmi/AppNameDef.h"

#include "Common/Utils.h"
#include "SXMDefine.h"
class OnBaseListener;
class SxmSpeechServiceInterface;

class SpeechService : public SpeechLib::IOnSpeechListener
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
public:
    SpeechService(SxmSpeechServiceInterface *interface);
    virtual ~SpeechService();

    void initialize(OnBaseListener* engine);
    virtual void onTestCompleted(const char* msg, const int& id, const bool& bFlag) Q_DECL_OVERRIDE;
    virtual void onRequestSystemSettingGet(const int& requestID) Q_DECL_OVERRIDE;
    virtual void onRequestSystemSettingSet(const int& requestID) Q_DECL_OVERRIDE;
    virtual void onResponseToGetSpeechLanguage(const int& requestID) Q_DECL_OVERRIDE;
//    virtual void onTtsPlay(const int32_t& nReqID, const TTS_PLAY_RESULT_E& eResult) Q_DECL_OVERRIDE;
//    virtual void onTtsPlayFile(const int32_t& nReqID, const TTS_PLAY_RESULT_E& eResult) Q_DECL_OVERRIDE;
//    virtual void onTtsStop(const int32_t& nReqID, const TTS_STOP_RESULT_E& eResult) Q_DECL_OVERRIDE;
//    virtual void onTtsPause(const int32_t& nReqID, const TTS_PAUSE_RESULT_E& eResult) Q_DECL_OVERRIDE;
//    virtual void onTtsResume(const int32_t& nReqID, const TTS_RESUME_RESULT_E& eResult) Q_DECL_OVERRIDE;
//    virtual void onResponse_TtsPlay(const int32_t& nReqID, const TTS_PLAY_RESULT_E& eResult, const int32_t& nSessionID) Q_DECL_OVERRIDE;
//    virtual void onResponse_TtsPlayTextFile(const int32_t& nReqID, const TTS_PLAY_RESULT_E& eResult, const int32_t& nSessionID) Q_DECL_OVERRIDE;
//    virtual void onResponse_TtsEnd(const int32_t& nReqID, const TTS_END_RESULT_E& eResult, const int32_t& nSessionID) Q_DECL_OVERRIDE;
//    virtual void onResponse_TtsStop(const int32_t& nReqID, const TTS_STOP_RESULT_E& eResult, const int32_t& nSessionID) Q_DECL_OVERRIDE;
//    virtual void onResponse_TtsPause(const int32_t& nReqID, const TTS_PAUSE_RESULT_E& eResult, const int32_t& nSessionID) Q_DECL_OVERRIDE;
//    virtual void onResponse_TtsResume(const int32_t& nReqID, const TTS_RESUME_RESULT_E& eResult, const int32_t& nSessionID) Q_DECL_OVERRIDE;
    virtual void onResponse_PTT_LONGPRESS(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_ABORT(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_ABORT_SILENT(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_CMD_START(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_GUI_SCROLL_START(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_GUI_SCROLL_STOP(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_TP_SELECT(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_SELECT(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_VOICEENROLMENT(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_TUTORIAL_START(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_System_VEInfoSet(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_System_VEEditUpdate(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_System_VEFeature(const SPEECH_VE_CATEGORY_ST& listVECategory, const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_System_VEByCategory(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_SCFA_CommandCategoryRequest(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onResponse_SCFA_CommandlistRequest(const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    virtual void onRequest_LANGUAGE_CHANGE(const int32_t& nReqID, const std::string& strLang) Q_DECL_OVERRIDE;
    virtual void onRequest_SHUTDOWN(const int32_t& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_USER_DATA_RESET(const int32_t& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_PTT(const int32_t& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_SCFA_TeleprompterShow(const int32_t& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_SCFA_ListShow(const int32_t& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_SCFA_TeleprompterHide(const int32_t& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_SCFA_TutorialChapterPlay(const int32_t& nReqID, const int32_t& nChapter) Q_DECL_OVERRIDE;
    virtual void onRequest_System_SELECTEventRequest(const int32_t& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_SCFA_ScreenShow(const int32_t& nReqID, const std::string& strContext) Q_DECL_OVERRIDE;
    virtual void onRequest_System_StateSet(const int32_t& nReqID, const std::string& strState, const std::string& strAction) Q_DECL_OVERRIDE;
    virtual void onRequest_SCFA_ListFocusGet(const int32_t& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_Tuner_CategorySelectedGet(const int &nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_Tuner_TeamSelectedGet(const int& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_Tuner_StationSelectedGet(const int& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_Tuner_SDARSChannelSelectedGet(const int& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_SCFA_ListFocusSet(const int32_t& nReqID, const int32_t& nAbsoluteIdx) Q_DECL_OVERRIDE;
    virtual void onRequest_SCFA_ListPageSet(const int32_t& nReqID, const std::string& strPageNavigation) Q_DECL_OVERRIDE;
    virtual void onRequest_SCFA_ListDataGet(const int32_t& nReqID, const int32_t& nLineNum) Q_DECL_OVERRIDE;
    virtual void onRequest_System_VEEventRequest(const int32_t& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_System_VESelectedGet(const int32_t& nReqID) Q_DECL_OVERRIDE;
    virtual void onRequest_System_VEEventConfirm(const int32_t& nReqID, const int32_t& nEventId, const std::string& strVEResult) Q_DECL_OVERRIDE;
    virtual void onSetSpeechLang(const int& nReqID, const E_SSVC_RESULT& eRet) Q_DECL_OVERRIDE;
    virtual void onSetVoiceSettings(const int& nReqID, const E_SSVC_RESULT& eRet) Q_DECL_OVERRIDE;

    //Response Team data
    virtual void onResponse_Speech_SDARSTeamData(const int& nReqID, const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    //Response all channel
    virtual void onResponse_Speech_SDARSChannelData(const int& nReqID, const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    //Response category data
    virtual void onResponse_Speech_SDARSCategoryData(const int& nReqID, const E_SSVC_RESULT& eResult) Q_DECL_OVERRIDE;
    //Request channel data belong to category name
    virtual void onResponse_Speech_SDARSChannelData(const int& nReqID, const char* szCategoryName, const E_SSVC_RESULT& eResult);

    void responseListPage(const bool result);
    void responseLineNumAbsoluteIdx(int absoluteIdx);
    void responseListFocusSet(bool result);
    void requestSdarsTeamData();
    void requestSdarsDataChannel();
    void requestSdarsCategorySatList();
    void requestSdarsCategoryChannel(QString category);

    void requestPttLongPress();
    void requestAbort();
    void responseScfaScreenShow(int requestId, int eResult);
    void requestSelect(QString selectItem, QString command);
    void requestSelect(QString selectItem , QString selectId, QString command);
    void requestTpSelect(const int nAbsoluteIdx);
    void requestScrollStart();
    void requestScrollStop();
    void requestGuiScroll(E_VIDEO_TUNER_SCROLL scroll);
private:
    SxmSpeechServiceInterface *m_interface;
    SpeechLib::SpeechProxy *m_proxy;
    int32_t m_nReqID;
    QString m_selectCommand;
    int m_absoluteIdx;
    QString m_Name;
    int m_Id;
};

#endif // SPEECHSERVICE_H
