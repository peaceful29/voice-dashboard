#include "base/interface/OnBaseListener.h"
#include "SxmAppService.h"
#include "Interfaces/SxmAppServiceInterface.h"
#include "msg/MqDef.h"
#include "DataController.h"
#include "ResourceManager.h"

/*!
 *  \brief: SxmAppService Constructor
 *  \param: SxmAppServiceInterface * _interface
 *  \return: void
 */
SxmAppService::SxmAppService(SxmAppServiceInterface * _interface)
    : IOnAppListener()
    , BrAppListener()
    , m_interface(_interface)
    , m_isRequestingLaunchBaseFeature(false)
{
    LOGI().writeFormatted("SxmAppService::SxmAppService() called");
    m_proxy = nullptr;
//    m_appId = E_HMI_APP_ID_RADIO_SXM360L;
    m_showed = false;
}

/*!
 * \brief SxmAppService::~SxmAppService
 */
SxmAppService::~SxmAppService()
{

}


/*!
 * \brief SxmAppService::initialize
 * \param engine
 */
void SxmAppService::initialize(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmAppService::initialize() called app name %s", HMI_APP_NAME_SXM360L);
    m_proxy = AppProxy::getInstance((BaseReceiver*)engine, HMI_APP_NAME_SXM360L);
}

/*!
 * \brief SxmAppService::registerApplication
 */
void SxmAppService::registerApplication()
{
    LOGI().writeFormatted("SxmAppService::registerApplication() called");
    if (m_proxy) {
        APP_INFO_T tAppInfo;
        tAppInfo.eAppId = E_HMI_APP_ID_RADIO_SXM360L;
        qstrcpy(tAppInfo.strAppWindowName, WIN_NAME_SXM360L);
        qstrcpy(tAppInfo.strAppBinaryName, HMI_APP_NAME_SXM360L);
        qstrcpy(tAppInfo.strAppRole, HMI_ROLE_SXM360L_RADIO);
        tAppInfo.isApplicationActivation = false;
        tAppInfo.eAppType = E_HMI_APP_TYPE_ENTERTAINMENT;
        tAppInfo.appendWindowInfo(HMI_ROLE_SXM360L_RADIO, WIN_NAME_SXM360L);
        tAppInfo.appendWindowInfo(HMI_ROLE_RADIO_SXM_SAT, WIN_NAME_SXM360L);
        tAppInfo.appendWindowInfo(HMI_ROLE_RADIO_SXM_IP, WIN_NAME_SXM360L);
        tAppInfo.appendWindowInfo("/role/sxm360l/speechmode", "win_hmi_sxm360l_speechmode");
        m_proxy->requestToRegisterApplication(0, tAppInfo);
    } else {
        ;
    }
}

/*!
 * \brief SxmAppService::requestToGoBack
 */
void SxmAppService::requestToGoBack()
{
    LOGI().writeFormatted("SxmAppService::requestToGoBack() called");
    if (m_proxy) {
        m_proxy->requestToGoBack(0);
    } else {
        ;
    }
}

/*!
 * \brief SxmAppService::requestToGoApplication
 * \param requestID
 * \param tIntent
 */
void SxmAppService::requestToGoApplication(const int &requestID, const INTENT_T &tIntent)
{
    LOGI().writeFormatted("SxmAppService::requestToGoApplication() called");
    if (m_proxy) {
        m_proxy->requestToGoApplication(requestID, tIntent);
    } else {
        ;
    }
}

/*!
 * \brief SxmAppService::requestToGoApplication
 * \param requestID
 * \param strAppBinaryName
 * \param strIntent
 */
void SxmAppService::requestToGoApplication(const int &requestID, const char *strAppBinaryName, const char *strIntent)
{
    LOGI().writeFormatted("SxmAppService::requestToGoApplication() called");
    if (m_proxy) {
        m_proxy->requestToGoApplication(requestID, strAppBinaryName, strIntent);
    } else {
        ;
    }
}

/*!
 * \brief SxmAppService::requestToGoApplication
 * \param requestID
 * \param strAppBinaryName
 * \param eShowOption
 * \param strIntent
 */
void SxmAppService::requestToGoApplication(const int &requestID, const char *strAppBinaryName, const E_SHOW_OPT &eShowOption, const char *strIntent)
{
    LOGI().writeFormatted("SxmAppService::requestToGoApplication() called");
    LOGI().writeFormatted(">>>>>> strIntent(%s)", strIntent);
    if (m_proxy) {
        m_proxy->requestToGoApplication(requestID, strAppBinaryName, eShowOption, strIntent);
    } else {
    }
}

/*!
 * \brief SxmAppService::requestToGoApplication
 * \param requestID
 * \param strAppBinaryName
 * \param strAppRole
 * \param strIntent
 * \param eShowOpt
 */
void SxmAppService::requestToGoApplication(const int &requestID, const char *strAppBinaryName, const char *strAppRole, const char *strIntent, const E_SHOW_OPT &eShowOpt)
{
    LOGI().writeFormatted("[SxmAppService::requestToGoApplication]RequestID[%d]Role[%s]Intent[%s]ShowOpt[%d]", requestID, strAppRole, strIntent, eShowOpt);
    LOGI().writeFormatted(">>>>>> strIntent(%s)", strIntent);
    if (m_proxy) {
        m_proxy->requestToGoApplication(requestID, strAppBinaryName, strAppRole, strIntent, eShowOpt);
    }
    else {
        LOGE().writeFormatted("SxmAppService::requestToGoApplication m_proxy = null");
    }
}

/*!
 * \brief SxmAppService::requestToGoApplication
 * \param requestID
 * \param strAppRole
 * \param strIntent
 * \param eShowOption
 */
void SxmAppService::requestToGoApplication(const int &requestID, const char *strAppRole, const char *strIntent, const E_SHOW_OPT &eShowOption)
{
    LOGI().writeFormatted("[SxmAppService::requestToGoApplication]RequestID[%d]Role[%s]Intent[%s]ShowOpt[%d]", requestID, strAppRole, strIntent, eShowOption);
    if (m_proxy) {
        m_proxy->requestToGoApplication(requestID, strAppRole, strIntent, eShowOption);
    }
}

/*!
 * \brief SxmAppService::requestToShowSystemComponent
 * \param requestID
 * \param eSystemComponent
 * \param strData
 */
void SxmAppService::requestToShowSystemComponent(const int &requestID, const E_SYSTEM_COMPONENT &eSystemComponent, const char *strData)
{
    LOGI().writeFormatted("SxmAppService::requestToShowSystemComponent() called requestID %d E_SYSTEM_COMPONENT %d, strData %s",
                          requestID, eSystemComponent, strData);
    if (m_proxy) {
        m_proxy->requestToShowSystemComponent(requestID, eSystemComponent, strData);
    } else {
        ;
    }
}

/*!
 * \brief SxmAppService::requestToHideSystemComponent
 * \param requestID
 * \param eSystemComponent
 * \param strData
 */
void SxmAppService::requestToHideSystemComponent(const int &requestID, const E_SYSTEM_COMPONENT &eSystemComponent, const char *strData)
{
    LOGI().writeFormatted("SxmAppService::requestToHideSystemComponent() called requestID %d E_SYSTEM_COMPONENT %d, strData %s",
                          requestID, eSystemComponent, strData);
    if (m_proxy)
        m_proxy->requestToHideSystemComponent(requestID, eSystemComponent, strData);
    else {

    }
}

void SxmAppService::requestSpeechModeLaunchingBaseFeature()
{
    if (m_proxy != nullptr){
        m_isRequestingLaunchBaseFeature = true;
        m_proxy->requestToGoApplication(0, HMI_APP_NAME_SXM360L, HMI_ROLE_RADIO_SXM_SAT, "SXM", E_SHOW_OPT_ADD);
    }
}

/*!
 * \brief SxmAppService::onGoBackResult
 * \param requestID
 * \param eResult
 */
void SxmAppService::onGoBackResult(const int &requestID, const E_REQ_RESULT_MSG &eResult)
{
    LOGI().writeFormatted("SxmAppService::onGoBackResult() called request id %d result %d", requestID, eResult);
}

void SxmAppService::onGoApplicationResult(const int &requestID, const E_REQ_RESULT_MSG &eResult)
{
    if ((m_isRequestingLaunchBaseFeature == true) &&
           (m_interface != nullptr) &&
            (eResult == E_REQ_RESULT_MSG_OK)){
        m_isRequestingLaunchBaseFeature = false;
        //Response for speechservice
        m_interface->responseScfaScreenShow(requestID, eResult);
    }
}

/*!
 * \brief SxmAppService::onRegisterApplicationResult
 * \param requestID
 * \param eResult
 */
void SxmAppService::onRegisterApplicationResult(const int &requestID, const E_REQ_RESULT_MSG &eResult)
{
    LOGI().writeFormatted("SxmAppService::onRegisterApplicationResult() called reqestID %dresult %d", requestID ,eResult);
}

/*!
 * \brief SxmAppService::onCmdShowApplication
 * \param requestID
 */
void SxmAppService::onCmdShowApplication(const int &requestID, const char *strAppRole, const char *strIntent)
{
    LOGI().writeFormatted("SxmAppService::onCmdShowApplication() called appRole %s Intent %s", strAppRole, strIntent);
//    m_interface->cmdShowApplication();
    m_interface->showApplication(QString(strAppRole), QString(strIntent));
    if (m_proxy != nullptr) {
        m_proxy->responseShowApplicationResult(requestID, E_REQ_RESULT_MSG_OK);
    }
}

/*!
 * \brief SxmAppService::onCmdActivateApplication
 * \param requestID
 * \param bActivation
 */
void SxmAppService::onCmdActivateApplication(const int &requestID, const bool &bActivation)
{
    LOGI().writeFormatted("SxmAppService::onCmdActivateApplication() called requstID %d activation %d", requestID, bActivation);
}

/*!
 * \brief SxmAppService::onCmdHideApplication
 * \param requestID
 * \param strAppRole
 * \param strIntent
 */
void SxmAppService::onCmdHideApplication(const int &requestID, const char *strAppRole, const char *strIntent)
{
    if (m_proxy != nullptr) {
        m_proxy->responseHideApplicationResult(requestID, E_REQ_RESULT_MSG_OK);
    }
}

/*!
 * \brief SxmAppService::onCmdResumeApplication
 * \param requestID
 * \param strAppRole
 * \param strIntent
 */
void SxmAppService::onCmdResumeApplication(const int &requestID, const char *strAppRole, const char *strIntent)
{
    LOGI().writeFormatted("SxmAppService::onCmdResumeApplication() called strAppRole %s, strIntent %s", strAppRole, strIntent);
    if (m_proxy != nullptr) {
        m_proxy->responseResumeApplicationResult(requestID, E_REQ_RESULT_MSG_OK);
    }
}

/*!
 * \brief SxmAppService::onCmdCreateAppWindow
 * \param requestID
 * \param strAppRole
 * \param strIntent
 */
void SxmAppService::onCmdCreateAppWindow(const int &requestID, const char *strAppRole, const char *strIntent)
{
    LOGI().writeFormatted("SxmAppService::onCmdCreateAppWindow() called strAppRole %s, strIntent %s", strAppRole, strIntent);
    if (m_interface != nullptr){
        LOGI().writeFormatted("SxmAppService::onCmdCreateAppWindow() emit cmdCreateAppWindow signal");
        m_interface->onCmdCreateAppWindow();
    }

    if (m_proxy != nullptr) {
        m_proxy->responseCreateAppWindowResult(requestID, E_REQ_RESULT_MSG_OK);
    }
}

/*!
 * \brief SxmAppService::onCmdShowAppWindow
 * \param requestID
 * \param strAppRole
 * \param strIntent
 */
void SxmAppService::onCmdShowAppWindow(const int &requestID, const char *strAppRole, const char *strIntent)
{
    LOGI().writeFormatted("SxmAppService::onCmdShowAppWindow() called strAppRole %s, strIntent %s", strAppRole, strIntent);

    if (m_interface != nullptr){
        LOGI().writeFormatted("SxmAppService::onCmdShowAppWindow() emit cmdShowAppWindow signal");
        m_interface->cmdShowAppWindow(QString(strAppRole), QString(strIntent));
    }
    if (m_proxy != nullptr) {
        m_proxy->responseShowAppWindowResult(requestID, E_REQ_RESULT_MSG_OK);
    }
}

/*!
 * \brief SxmAppService::onCmdDestroyAppWindow
 * \param requestID
 * \param strAppRole
 * \param strIntent
 */
void SxmAppService::onCmdDestroyAppWindow(const int &requestID, const char *strAppRole, const char *strIntent)
{
    LOGI().writeFormatted("SxmAppService::onCmdDestroyAppWindow() called strAppRole %s, strIntent %s", strAppRole, strIntent);

    if (m_interface != nullptr){
        LOGI().writeFormatted("SxmAppService::onCmdShowAppWindow() emit cmdDestroyAppWindow signal");
        m_interface->onCmdDestroyAppWindow();
    }

    if (m_proxy != nullptr) {
        m_proxy->responseDestroyAppWindowResult(requestID, E_REQ_RESULT_MSG_OK);
    }
}

/*!
 * \brief SxmAppService::onCmdReadyToSuspendSystem
 * \param requestID
 */
void SxmAppService::onCmdReadyToSuspendSystem(const int &requestID)
{
    LOGI().writeFormatted("SxmAppService::onCmdReadyToSuspendSystem() called");
    if (m_proxy != nullptr) {
        m_proxy->responseReadyToSuspendSystemResult(requestID, E_REQ_RESULT_MSG_OK);
    }
}

/*!
 * \brief SxmAppService::onCmdSuspendSystem
 * \param requestID
 */
void SxmAppService::onCmdSuspendSystem(const int &requestID)
{
    LOGI().writeFormatted("SxmAppService::onCmdSuspendSystem() called");
    if (m_proxy != nullptr) {
        m_proxy->responseSuspendSystemResult(requestID, E_REQ_RESULT_MSG_OK);
    }
}

/*!
 * \brief SxmAppService::onCmdReadyToResumeSystem
 * \param requestID
 */
void SxmAppService::onCmdReadyToResumeSystem(const int &requestID)
{
    LOGI().writeFormatted("SxmAppService::onCmdReadyToResumeSystem() called");
    if (m_proxy != nullptr) {
        m_proxy->responseReadyToResumeSystemResult(requestID, E_REQ_RESULT_MSG_OK);
    }
}

/*!
 * \brief SxmAppService::onCmdResumeSystem
 * \param requestID
 */
void SxmAppService::onCmdResumeSystem(const int &requestID)
{
    LOGI().writeFormatted("SxmAppService::onCmdResumeSystem() called");
    if (m_proxy != nullptr) {
        m_proxy->responseResumeSystemResult(requestID, E_REQ_RESULT_MSG_OK);
    }
}

/*!
 * \brief SxmAppService::onShowSystemComponentResult
 * \param requestID
 * \param eResult
 */
void SxmAppService::onShowSystemComponentResult(const int &requestID, const E_REQ_RESULT_MSG &eResult)
{
    LOGI().writeFormatted("SxmAppService::onShowSystemComponentResult() called result %d", eResult);
    ResourceManager::instance()->setIsBackButtonShowed(Utils::BUTTON_BACK_SHOW);
    //set back button does not appear
//    m_proxy->responseGoBackResult(10, E_REQ_GO_BACK_RESULT_DEPTH_BACK_OK);
    DataController::instance()->eventShowSystemComponent(requestID, eResult);
}

/*!
 * \brief SxmAppService::onHideSystemComponentResult
 * \param requestID
 * \param eResult
 */
void SxmAppService::onHideSystemComponentResult(const int &requestID, const E_REQ_RESULT_MSG &eResult)
{
    LOGI().writeFormatted("SxmAppService::onHideSystemComponentResult() called result %d", eResult);
    ResourceManager::instance()->setIsBackButtonShowed(Utils::BUTTON_BACK_HIDE);
    DataController::instance()->eventHideSystemComponent(requestID,eResult);
}

/*!
 * \brief SxmAppService::onCmdGoBack
 * \param requestID
 */
void SxmAppService::onCmdGoBack(const int& requestID)
{
    LOGI().writeFormatted("SxmAppService::onCmdGoBack() called result %d", requestID);
    if (m_proxy != nullptr) {
        m_proxy->responseGoBackResult(requestID, E_REQ_GO_BACK_RESULT_DEPTH_BACK_OK);
        DataController::instance()->eventCmdGoBack(requestID);
    }
}

/*!
 * \brief SxmAppService::onButtonEvent
 * \param eSwitchType
 * \param eButton
 * \param eAction
 */
void SxmAppService::onButtonEvent(const E_SWITCH &eSwitchType, const E_BUTTON &eButton, const E_ACTION &eAction)
{
    LOGI().writeFormatted("SxmAppService::onButtonEvent() called switchType %d, button %d action %d",
                          eSwitchType, eButton, eAction);
    DataController::instance()->eventButtonHardkey(eSwitchType, eButton, eAction);

}

void SxmAppService::onRotaryEvent(const E_ROTARY &eRotary, const E_ROTATION &eRotation, const int &step)
{
    LOGI().writeFormatted("SxmAppService::onRotaryEvent() called eRotary %d, eRotation %d step %d",
                          eRotary, eRotation, step);

}
