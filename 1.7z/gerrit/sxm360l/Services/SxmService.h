#ifndef SXMSERVICE_H
#define SXMSERVICE_H

#include "sxm360l/IOnSxm360lListener.h"
#include "Common/Utils.h"
#include "sxm360l/Sxm360lMsgDef.h"
#include "sxm360l/Sxm360lProxySync.h"

class OnBaseListener;
class Sxm360lProxy;
class Sxm360lProxySync;
class SxmServiceInterface;

class SxmService: public IOnSxm360lListener
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
public:
    SxmService(SxmServiceInterface* _interface);
    ~SxmService() = default;

    void initialize(OnBaseListener* engine);

    void requestSATDiagnostics();
    void requestInitSet(const int& id, const bool& bFlag, const char* msg);
    void requestInitState();
    void requestSuperCategories();
    void requestAllCategories();
    void requestCategories(const char* superCategory);
    void requestChannels(const char* category);
    void requestChannels();
    void requestChannelInformation(const uint32_t channelNumber);
    void requestFavorites();
    void requestAddFavorite(const uint32_t channelNumber);
    void requestRemoveFavorite(const uint32_t channelNumber);
    void requestTuneFavorite(const uint32_t channelNumber);
    void requestMoveFavorite(const uint32_t index, const uint32_t new_index);
    void requestSmartFavorites();
    void requestPlayback(const PLAY_STATE state);
    void requestTuneLastChannel();
    void requestTuneChannel(const uint32_t channelNumber);
    void requestSeekChannel(const SEEK_ACTION action);
    void requestSongAlerts();
    void requestArtistAlerts();
    void requestArtistAndSongAlerts();
    void requestAddSongAlert(const char* songTitle);
    void requestAddArtistAlert(const char* artistName);
    void requestRemoveArtistAlert(const char* artistName);
    void requestRemoveSongAlert(const char* songTitle);
    void requestRewind(const uint32_t step);
    void requestFastForward(const uint32_t step);
    void requestJumpPoint(const uint32_t point);
    void requestRecommendation();
    void requestListeningHistory();
    void requestLastChannelInfo();

    void requestGetChannelList(const int);
    void requestTestLossSignal();
    // PlayerResumingSatelliteBroadcastChannel.qml onCompleted
    void requestResumingSatelliteOnCompleted();
    //Profile
    void requestGetActiveProfiles();
    void requestCreateProfile(const char* name);
    void requestSetDefaultProfile();
    void requestSwitchProfile(const char* name);
    void requestDeleteProfile();
    void requestModifyProfileName(const char* name);
    void requestModifyProfileAvatar(const char* logoUrl);
    //Setting Notification
    void requestGetSettingNotification();
    void requestSetSettingNotification(const SETTING_NOTIFICATION_STATE state);
    //make color
    void requestRelatedList();
    //make color

    // Sport Team
    void requestAddFavoriteTeam(const SPORTS_TEAM_TYPE type);
    void requestRemoveFavoriteTeam(const int teamId);
    void requestGetTeams(const int leagueId);
    void requestGetLeagues();
    void requestAddTeamAlerts(const int teamId);
    void requestRemoveTeamAlerts(const int teamId);
    void requestGetTeamAlerts();
    void requestGetFavoriteTeams();
//    void requestGetLiveSports();
//    void requestTuneLiveSports(const int leagueId);
    void requestSatSubscriptionState();
    void requestGetAntennaState();

protected:
    void onSATDiagnostics(const SXM_SATDIAGNOSTICS_T &data);
    void onInitState(const INIT_STATE& state);
    void onSuperCategories(const RESULT_STATE& state);
    void onAllCategories(const RESULT_STATE& state);
    void onCategories(const RESULT_STATE& state);
    void onChannels(const RESULT_STATE& state);
    void onChannelInformation(const RESULT_STATE& state);
    void onFavorites(const RESULT_STATE& state);
    void onAddFavorite(const RESULT_STATE& state);
    void onRemoveFavorite(const RESULT_STATE& state);
    void onTuneFavorite(const RESULT_STATE& state);
    void onSmartFavorites(const RESULT_STATE& state);
    void onSatSubscriptionState(const int& state);
    void onSignalState(const SIGNAL_STATE& state);
    void onAudioAvailability(const AUD_AVAIL_STATE& state);
    void onPlayback(const PLAY_STATE& state);
    void onTuneChannel(const RESULT_STATE& state, const uint32_t& channelNumber);
    void onTuneRequest(const LOADING_CHANNEL_INFORMATION_T& chInfo);
    void onTuneLastChannel(const RESULT_STATE& state, const uint32_t& channelNumber);
    void onSeekChannel(const RESULT_STATE& state, const uint32_t& channelNumber);
    void onArtistAlerts(const RESULT_STATE& state);
    void onSongAlerts(const RESULT_STATE& state);
    void onArtistAndSongAlerts(const RESULT_STATE& state);
    void onAddSongAlert(const RESULT_STATE& state);
    void onAddArtistAlert(const RESULT_STATE& state);
    void onRemoveArtistAlert(const RESULT_STATE& state);
    void onRemoveSongAlert(const RESULT_STATE& state);
    void onRewind(const RESULT_STATE& state);
    void onFastForward(const RESULT_STATE& state);
    void onJumpPoint(const RESULT_STATE& state);

     void onRecommendation(const RESULT_STATE& state);
     void onListeningHistory(const RESULT_STATE& state);
     void onLastChannelInfo(const RESULT_STATE& state);
    //Profile
     void onGetActiveProfiles(const RESULT_STATE& state);
     void onCreateProfile(const RESULT_STATE& state);
     void onSetDefaultProfile(const RESULT_STATE& state);
     void onSwitchProfile(const RESULT_STATE& state);
     void onDeleteProfile(const RESULT_STATE& state);
     void onModifyProfileName(const RESULT_STATE& state);
     void onModifyProfileAvatar(const RESULT_STATE& state);

     //Setting Notification
     void onGetSettingNotification(const SETTING_NOTIFICATION_STATE& state);
     void onSetSettingNotification(const RESULT_STATE& state);

     // Sport Team
     void onGetFavoriteTeams(const SPORTS_TEAM_FAVORITE_T& data);
     void onAddFavoriteTeam(const RESULT_STATE& state);
     void onRemoveFavoriteTeam(const RESULT_STATE& state);
     void onGetTeams(const RESULT_STATE& state, const int& count);
     void onGetLeagues(const SPORTS_LEAGUE_T& data);
     void onAddTeamAlerts(const RESULT_STATE& state);
     void onRemoveTeamAlerts(const RESULT_STATE& state);
     void onGetTeamAlerts(const SPORTS_TEAM_ALERTS_T& data);
//     void onGetLiveSports();
//     void onTuneLiveSports();
    //Fix build
     void onMpfaValidate(MPFA_RET_STATE const&);
     void onRelatedContents(RESULT_STATE const&);
     void onMpfaSelect(MPFA_RET_STATE const&);
     void onAntennaState(const ANTENNA_STATE& state);

private:
    Sxm360lProxy* m_proxy;
    Sxm360lProxySync *m_proxySync;
    SxmServiceInterface *m_interface;

//    SUPER_CATEGORY_LIST_T m_superCategoryList;
//    CATEGORY_LIST_T m_categoryList;
//    CHANNEL_INFORMATION_T m_chanelInformation;
//    LIVE_CHANNEL_LIST_T m_liveChanel;
//    CHANNEL_LIST_T m_channelList;
//    FAVORITE_LIST_T m_favoriteList;
//    SMART_FAVORITE_LIST_T m_smartFavoriteList;
//    SHOW_CHANNEL_LIST_T m_showChannelList;
//    RADIO_RESOURCE_INFO m_radioResourceInfo;
};

#endif // SXMSERVICE_H
