#include "SxmPopupService.h"
#include "popupservice/PopupProxy.h"
#include "popupservice/PopupMsgDef.h"
#include "popupservice/PopupJsonContextHandler.h"
#include "SxmPopupServiceInterface.h"

#include "base/interface/OnBaseListener.h"

SxmPopupService::SxmPopupService(SxmPopupServiceInterface *_interface)
    : IOnPopupListener(),
      m_interface(_interface)
{
    LOGI().writeFormatted("SxmPopupService::SxmPopupService");
    m_popupProxy = nullptr;
    //test code
    m_baseListener = new OnBaseListener(MQ_SYSTEM_POPUP_TEST_PATH);
    //test code
}

SxmPopupService::~SxmPopupService()
{

}

void SxmPopupService::initialize(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmPopupService::initialize");
//    m_popupProxy = PopupProxy::getInstance((const MqBase*)engine, "lge.app.sxm360l");
    //test code
    m_popupProxy = PopupProxy::getInstance((BaseReceiver*)engine, "lge.app.sxm360l");
//    m_baseListener->registerListener(this);
    //test code
}

void SxmPopupService::requestShowPopup(const uint32_t &clientSessionID, const E_POPUP_TYPE &ePopupType, const E_POPUP_SIDE_TYPE &ePopupSideType, const E_POPUP_SIZE &ePopupSize, const char *popupContext, const uint32_t &priority)
{
    LOGI().writeFormatted("SxmPopupService::requestShowPopup");
    if (m_popupProxy)
        m_popupProxy->requestShowPopup(clientSessionID, ePopupType, ePopupSideType ,ePopupSize, popupContext, priority);
    else
        LOGI().writeFormatted("SxmPopupService::requestShowPopup failed");
}

void SxmPopupService::requestHidePopup(const uint32_t &clientSessionID, const uint32_t &handle)
{
    LOGI().writeFormatted("SxmPopupService::requestHidePopup");
    if (m_popupProxy)
        m_popupProxy->requestHidePopup(clientSessionID, handle);
    else
        LOGI().writeFormatted("SxmPopupService::requestShowPopup failed");
}

void SxmPopupService::requestUpdatePopup(const uint32_t &clientSessionID, const uint32_t &handle, const char *popupContext)
{
    LOGI().writeFormatted("SxmPopupService::requestUpdatePopup");
    if (m_popupProxy)
        m_popupProxy->requestUpdatePopup(clientSessionID, handle, popupContext);
    else
        LOGI().writeFormatted("SxmPopupService::requestShowPopup failed");
}

void SxmPopupService::requestShowSpecialPopup(const uint32_t &clientSessionID, const E_SPECIAL_POPUP_TYPE &eSpecialPopupType, const char *popupContext, const uint32_t &priority)
{
    LOGI().writeFormatted("SxmPopupService::requestShowSpecialPopup");
    if (m_popupProxy)
        m_popupProxy->requestShowSpecialPopup(clientSessionID, eSpecialPopupType, popupContext, priority);
    else
        LOGI().writeFormatted("SxmPopupService::requestShowPopup failed");
}

void SxmPopupService::onResponseShowPopup(const uint32_t &clientSessionID, const uint32_t &handle, const E_POPUP_RESPONSE &eResponse)
{
    LOGI().writeFormatted("SxmPopupService::onResponseShowPopup");
}

void SxmPopupService::onResponseHidePopup(const uint32_t &clientSessionID, const uint32_t &handle, const E_POPUP_RESPONSE &eResponse)
{
    LOGI().writeFormatted("SxmPopupService::onResponseShowPopup");
}

void SxmPopupService::onNotifyPopupResult(const uint32_t &clientSessionID, const uint32_t &handle, const E_POPUP_RESULT &eResult, const bool &isChecked)
{
    LOGI().writeFormatted("SxmPopupService::onNotifyPopupResult");
}

void SxmPopupService::onResponseUpdatePopup(const uint32_t &clientSessionID, const uint32_t &handle, const E_POPUP_RESPONSE &eResponse)
{
    LOGI().writeFormatted("SxmPopupService::onResponseUpdatePopup");
}

void SxmPopupService::onNotifyStatusChanged(const uint32_t &clientSessionID, const uint32_t &handle, const E_POPUP_DISPLAY_STATUS &ePopupDisplayStatus)
{
    LOGI().writeFormatted("SxmPopupService::onNotifyStatusChanged");
}
