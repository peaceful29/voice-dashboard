#ifndef AUDIOSERVICE_H
#define AUDIOSERVICE_H

#include <QGuiApplication>

#include "base/interface/OnBaseListener.h"
#include "base/log/LogUtil.h"
#include "audio/IOnAudioListener.h"
#include "audio/AudioProxy.h"
#include "radio/RadioMsgDef.h"
#include "audio/AudioMsgDef.h"
#include "Common/Utils.h"
#include "hmi/AppNameDef.h"

class SxmAppServiceInterface;

class AudioService : public IOnAudioListener
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
public:
    AudioService(SxmAppServiceInterface *interface);
    virtual ~AudioService();
    void initialize(OnBaseListener* engine);

    void requestCmdPlay();
private:
    AudioProxy *m_audioProxy;
    SxmAppServiceInterface *m_interface;
};

#endif // AUDIOSERVICE_H
