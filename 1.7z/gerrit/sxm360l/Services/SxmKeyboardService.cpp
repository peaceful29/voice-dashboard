#include "SxmKeyboardService.h"
#include "keyboardservice/KeyboardProxy.h"
#include "keyboardservice/KeyboardJsonContextHandler.h"
#include"Interfaces/SxmKeyboardInterface.h"
#include "DataExchange/DataController.h"
#include"Common/UIBridge.h"

SxmKeyboardService::SxmKeyboardService(SxmKeyboardInterface *_interface)
    : IOnKeyboardListener()
      ,m_interface(_interface)
{
    LOGI().writeFormatted("SxmKeyboardService::SxmKeyboardService");
}

SxmKeyboardService::~SxmKeyboardService()
{
    LOGI().writeFormatted("SxmKeyboardService::~SxmKeyboardService");
    SafeDelete<SxmKeyboardInterface>(m_interface);
}

void SxmKeyboardService::initialize(OnBaseListener *engine)
{
    LOGI().writeFormatted("SxmKeyboardService::initialize");
    m_keyboardProxy = KeyboardProxy::getInstance((BaseReceiver*)engine, HMI_APP_NAME_SXM360L);
    m_keyboardProxy->registerName(HMI_APP_NAME_SXM360L);
}

void SxmKeyboardService::requestShowKeyboard(const uint32_t &clientSessionID, const E_KEYBOARD_TYPE &eKeyboardType, const char *preFilledText, const char *defaultText, const uint32_t &maxLength)
{
    LOGI().writeFormatted("SxmKeyboardService::requestShowKeyboard");
    if (m_keyboardProxy)
        m_keyboardProxy->requestShowKeyboard(clientSessionID, eKeyboardType, preFilledText, defaultText, maxLength);
    else
        LOGI().writeFormatted("SxmKeyboardService::requestShowKeyboard NULL");

}

void SxmKeyboardService::requestHideKeyboard(const uint32_t &clientSessionID)
{
    LOGI().writeFormatted("SxmKeyboardService::requestHideKeyboard");
    if (m_keyboardProxy)
        m_keyboardProxy->requestHideKeyboard(clientSessionID);
}

void SxmKeyboardService::responseCandidateInfo(const uint32_t &clientSessionID, const uint32_t &userInputID, const uint32_t &candidateSessionID, const uint32_t &suggestionCount, const char *userInputText, const char *suggestionResultContext)
{
    LOGI().writeFormatted("SxmKeyboardService::responseCandidateInfo");
    if (m_keyboardProxy)
        m_keyboardProxy->responseCandidateInfo(clientSessionID, userInputID, candidateSessionID, suggestionCount, userInputText, suggestionResultContext);
}

void SxmKeyboardService::responseCandidateList(const uint32_t &clientSessionID, const uint32_t &candidateSessionID, const char *userInputText, const uint32_t &startIndex, const uint32_t &endIndex, const char *candidateListContext)
{
    LOGI().writeFormatted("SxmKeyboardService::responseCandidateList");
    if (m_keyboardProxy)
        m_keyboardProxy->responseCandidateList(clientSessionID, candidateSessionID, userInputText, startIndex, endIndex, candidateListContext);
}

void SxmKeyboardService::onResponseShowKeyboard(const uint32_t &clientSessionID, const E_KEYBOARD_RESPONSE &eResponse)
{
    Q_UNUSED(clientSessionID);
    LOGI().writeFormatted("SxmKeyboardService::onResponseShowKeyboard %d", eResponse);

}

void SxmKeyboardService::onResponseHideKeyboard(const uint32_t &clientSessionID, const E_KEYBOARD_RESPONSE &eResponse)
{
    Q_UNUSED(clientSessionID);
    LOGI().writeFormatted("SxmKeyboardService::onResponseHideKeyboard %d", eResponse);
}

void SxmKeyboardService::onNotifyKeyboardResult(const uint32_t &clientSessionID, const E_KEYBOARD_RESULT &eResult, const char *userInputText)
{
    Q_UNUSED(clientSessionID);
    if (E_KEYBOARD_RESULT_CANCEL == eResult){
        this->requestHideKeyboard(clientSessionID);
    }
    else if (E_KEYBOARD_RESULT_DONE == eResult){
        DataController::instance()->makeCommandRequest(UIBridge::E_HMI_EVENT_FNC_ID_REQUEST_TUNE_CHANNEL, userInputText);
        this->requestHideKeyboard(clientSessionID);
    }
    LOGI().writeFormatted("SxmKeyboardService::onNotifyKeyboardResult %d %s", eResult, userInputText);
}

void SxmKeyboardService::onRequestCandidateInfo(const uint32_t &clientSessionID, const uint32_t &inputID, const char *userInputText)
{
    Q_UNUSED(clientSessionID);
    LOGI().writeFormatted("SxmKeyboardService::onRequestCandidateInfo %d %s", inputID, userInputText);
     if (QString(userInputText).compare("") != 0){
         m_interface->onEventResponseCandidateInfo(clientSessionID, inputID, userInputText);
         LOGI().writeFormatted("SxmKeyboardService::onRequestCandidateInfo not NULL ");
     }
}

void SxmKeyboardService::onRequestCandidateList(const uint32_t &clientSessionID, const uint32_t &candidateSessionID, const char *userInputText, const uint32_t &startIndex, const uint32_t &endIndex)
{
    Q_UNUSED(clientSessionID);
    LOGI().writeFormatted("SxmKeyboardService::onRequestCandidateList %d %s %d %d", candidateSessionID, userInputText, startIndex, endIndex);
    m_interface->onEventResponseCandidateList(clientSessionID, candidateSessionID, userInputText, startIndex, endIndex);
}
