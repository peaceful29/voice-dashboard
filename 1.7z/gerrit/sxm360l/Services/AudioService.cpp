#include "AudioService.h"

AudioService::AudioService(SxmAppServiceInterface *interface)
: m_interface(interface)
{
    m_audioProxy = nullptr;
}

AudioService::~AudioService()
{

}

void AudioService::initialize(OnBaseListener* engine)
{
    LOGI().writeFormatted("[AudioService::initialize]");
    m_audioProxy = AudioProxy::getInstance((BaseReceiver*)engine, HMI_APP_NAME_SXM360L);
    m_audioProxy->registerName(HMI_APP_NAME_SXM360L);
}

void AudioService::requestCmdPlay()
{
    LOGI().writeFormatted("[AudioService::requestCmdPlay]");
    if (m_audioProxy != nullptr){
        m_audioProxy->sendCmdPause(E_RES_BROADCAST_AM);
        m_audioProxy->sendCmdPause(E_RES_BROADCAST_FM);
        m_audioProxy->sendCmdPause(E_RES_BROADCAST_DAB);
        m_audioProxy->sendCmdPlay(E_RES_BROADCAST_SXM_SAT);
    }
}



