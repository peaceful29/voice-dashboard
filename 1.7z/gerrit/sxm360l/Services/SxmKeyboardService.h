#ifndef SXMKEYBOARDSERVICE_H
#define SXMKEYBOARDSERVICE_H

#include "Utils.h"
#include "keyboardservice/IOnKeyboardListener.h"
#include "keyboardservice/KeyboardMsgDef.h"
#include "SXMKeyPadHandler.h"

class KeyboardProxy;
class SxmKeyboardInterface;
class OnBaseListener;

class SxmKeyboardService: public IOnKeyboardListener
{
    LOG_SET_CLASS_CONTEXT(hmi_sxm_context);
public:
    SxmKeyboardService(SxmKeyboardInterface *_interface);
    virtual ~SxmKeyboardService();

    void initialize(OnBaseListener* engine);

    void requestShowKeyboard(const uint32_t& clientSessionID, const E_KEYBOARD_TYPE& eKeyboardType, const char* preFilledText, const char* defaultText, const uint32_t& maxLength);
    void requestHideKeyboard(const uint32_t& clientSessionID);
    void responseCandidateInfo(const uint32_t& clientSessionID, const uint32_t& userInputID, const uint32_t& candidateSessionID, const uint32_t& suggestionCount, const char* userInputText, const char* suggestionResultContext);
    void responseCandidateList(const uint32_t& clientSessionID, const uint32_t& candidateSessionID, const char* userInputText, const uint32_t& startIndex, const uint32_t& endIndex, const char* candidateListContext);


private:
    void onResponseShowKeyboard(const uint32_t& clientSessionID, const E_KEYBOARD_RESPONSE& eResponse);
    void onResponseHideKeyboard(const uint32_t& clientSessionID, const E_KEYBOARD_RESPONSE& eResponse);
    void onNotifyKeyboardResult(const uint32_t& clientSessionID, const E_KEYBOARD_RESULT& eResult, const char* userInputText);
    void onRequestCandidateInfo(const uint32_t& clientSessionID, const uint32_t& inputID, const char* userInputText);
    void onRequestCandidateList(const uint32_t& clientSessionID, const uint32_t& candidateSessionID, const char* userInputText, const uint32_t& startIndex, const uint32_t& endIndex);

    KeyboardProxy *m_keyboardProxy;
    SxmKeyboardInterface *m_interface;
    SXMKeyPadHandler* m_keypadHandler;
};

#endif // SXMKEYBOARDSERVICE_H
