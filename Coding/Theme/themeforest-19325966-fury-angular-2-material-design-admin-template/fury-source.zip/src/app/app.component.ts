import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'vr-root',
  templateUrl: './app.component.html',
  encapsulation: ViewEncapsulation.None
})
export class AppComponent {
  constructor() {
  }
}
