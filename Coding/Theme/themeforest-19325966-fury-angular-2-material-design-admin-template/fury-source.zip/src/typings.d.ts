declare module 'screenfull' {
  var enabled: any;
  function toggle(): any
}
