#!/bin/sh
PATH=/C/Qt/Qt5.6.0/5.6/mingw49_32/lib:$PATH
export PATH
QT_PLUGIN_PATH=/C/Qt/Qt5.6.0/5.6/mingw49_32/plugins${QT_PLUGIN_PATH:+:$QT_PLUGIN_PATH}
export QT_PLUGIN_PATH
exec "$@"
