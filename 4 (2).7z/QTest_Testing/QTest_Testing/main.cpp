#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <AppMain.h>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    AppMain appMain;

    return app.exec();
}
