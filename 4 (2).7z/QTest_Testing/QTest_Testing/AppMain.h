#ifndef APPMAIN_H
#define APPMAIN_H

#include <QObject>
#include <QQuickView>
#include <QQuickItem>
#include <QJsonObject>

class AppMain : public QObject
{
    Q_OBJECT
public:
    AppMain(QObject* parent = nullptr);
private:
    QQuickView m_view;
    QQuickItem* m_rootObject;
    QJsonObject m_jsonObj;
    int m_stepCount = 0;
    void readJsonFile();
public slots:
    void onClickButton();
};

#endif // APPMAIN_H
