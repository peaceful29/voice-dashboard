#include "AppMain.h"
#include <QTimer>
#include <QTest>
#include <QMouseEvent>
#include <QGraphicsSceneMouseEvent>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
//#include <QtTest/QTest>
AppMain::AppMain(QObject *parent)
{
    m_view.setSource(QUrl(QStringLiteral("qrc:/main.qml")));
    m_view.show();
    m_rootObject = m_view.rootObject();

    //    QTest::mouseClick(d, Qt::LeftButton, Qt::NoModifier, QPoint(x,y));
    //    QQuickItem* childArea = m_rootObject->findChild<QQuickItem *>("ChildMouse");

    //    QMouseEvent pressEvent(QEvent::MouseButtonPress, QPoint(100, 100), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
    //    QQuickItem* item =  m_rootObject->childAt(100, 100);

    //    const bool isSent = m_view.sendEvent(childArea, &pressEvent);
    //const bool isSent = QApplication::sendEvent(m_viewer->scene(), &pressEvent);
    //    qDebug() << "'Press' at (100, 100) successful? " << isSent;
    readJsonFile();
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(onClickButton()));
    timer->start(3000);
//    onClickButton();
}

void AppMain::readJsonFile()
{
    QString val;
    QFile file;
    //   QJsonObject jsonObj;

    file.setFileName(":/TestStep.json");
    QFileInfo file_info(file.fileName());
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QJsonParseError parseError;
        m_jsonObj = QJsonDocument::fromJson(file.readAll(), &parseError).object();
        m_stepCount = m_jsonObj.count();
//        QJsonObject stepObj;
        file.close();
//        if(parseError.error == QJsonParseError::NoError) {
//            qDebug() << jsonObj;
//            foreach (const QString& step, jsonObj.keys()) {
//                stepObj = jsonObj.value(step).toArray().at(0).toObject();
//                qDebug() << jsonObj.value(step).toArray().at(0);
//                if (!stepObj.isEmpty()) {
//                    qDebug() << "Vao 1";
//                    qDebug() << stepObj.value("lstIndex");
//                }
//            }

//        } else {
//            qDebug() << "Load Error: " << parseError.errorString().toLatin1().data();
//        }
    }
    //   val = file.readAll();
    //   qDebug() << val;
}

void AppMain::onClickButton()
{
    static int count = 1;
    QString step = "Step_" + QString::number(count);
//    qDebug() << step;
    QJsonObject stepObj = m_jsonObj.value(step).toObject();
//    qDebug() << stepObj;

    QString objName = stepObj.value("lstName").toString();
//    qDebug() << objName;
    int lstIndex = stepObj.value("lstIndex").toInt();
    QQuickItem* lstItem = m_rootObject->findChild<QQuickItem *>(objName);
    qDebug() << lstItem;
    //    QMouseEvent(Type type, const QPointF &localPos, const QPointF &screenPos,
    //             Qt::MouseButton button, Qt::MouseButtons buttons,
    //             Qt::KeyboardModifiers modifiers);
    //    QMouseEvent onClicked(QEvent::MouseButtonPress, QPointF(0,0), Qt::LeftButton, Qt::NoButton,Qt::NoModifier);
//    QQuickItem* footerArea = m_rootObject->findChild<QQuickItem *>("FooterMenu")->childAt(397, 62);

//    mouseArea = lstItem->childAt(688, 73)->findChild<QQuickItem *>("MouseArea");
//    QList<QQuickItem*> lstChil = lstItem->findChildren<QQuickItem *>("MouseArea", Qt::FindChildrenRecursively);
//    QQuickItem* chilItem = lstItem->childAt(688, 73);
    QList<QQuickItem*> lstChil = lstItem->childItems();

//    qDebug() << chilItem;
    qDebug() << lstChil.count();
    QQuickItem* mouseArea = lstChil.at(lstIndex)->findChild<QQuickItem *>("MouseArea");

    if (mouseArea) {
        qDebug() << "Vao 1";

        QMouseEvent pressEvent(QEvent::MouseButtonPress, QPoint(0, 0), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);
        QMouseEvent releaseEvent(QEvent::MouseButtonRelease, QPoint(0, 0), Qt::LeftButton, Qt::LeftButton, Qt::NoModifier);

        const bool isSentPress = m_view.sendEvent(mouseArea, &pressEvent);
        const bool isSentRelease = m_view.sendEvent(mouseArea, &releaseEvent);
        qDebug() << isSentPress;
    }
    count++;
}
