#ifndef UIBRIDGE_H
#define UIBRIDGE_H

#include <QObject>
#include "AMFMKeypadHandler.h"
#include "AppMain.h"
#include "SXMKeyPadHandler.h"
class UIBridge : public QObject
{
    Q_OBJECT
public:
    UIBridge(QObject *appMain = nullptr);
    Q_INVOKABLE void onAMFMValidNumberChanged(bool isFM, QString enteredNumber);
    Q_INVOKABLE void onSXMValidNumberChanged(QString enteredNumber);
    Q_INVOKABLE void changeScreen(QString screenPath);
    Q_INVOKABLE void changeStyleMode(QString styleMode);
public slots:
    void onGetValidNumberDone(QString validKey);
    void onAddDotToCurrentFMFreq();
    void onGetSXMValidNumberDone(QString validKey);
signals:
    void currentAMFMValidNumberChanged(QString number);
    void currentSXMValidNumberChanged(QString number);
    void addDotToCurrentFMFreq();
    void screenChangeded(QString screenPath);
    void styleModeChanged(QString styleMode);
private:
    AMFMKeypadHandler* m_amfmHandler;
    SXMKeyPadHandler*  m_sxmHandler;
};

#endif // UIBRIDGE_H
