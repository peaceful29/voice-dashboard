#ifndef APPMAIN_H
#define APPMAIN_H

#include <QObject>
#include <QQuickView>
#include <QQuickItem>
#include "ListviewModel.h"
#include "UIBridge.h"

class UIBridge;
class AppMain : public QObject
{
    Q_OBJECT
public:
    static AppMain* getInsctance();
    AppMain(QObject* parent = nullptr);

public slots:
    void onScreenReady();
    void updateList();
    void changedScreen(QString screenPath);
    void onStyleModeChanged(QString styleMode);
private:
    static AppMain *m_instance;
    ListviewModel m_model;
    QQuickView m_view;
    QQuickItem* m_rootObject;
    UIBridge* m_uiBridge;
    QObject* m_mainLoader;
    QString m_styleMode;
};

#endif // APPMAIN_H
