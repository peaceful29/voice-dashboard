#ifndef SXMKEYPADHANDLER_H
#define SXMKEYPADHANDLER_H

#include <QString>
#include <QObject>
#include <QMap>
class SXMKeyPadHandler : public QObject
{
    Q_OBJECT
public:
    SXMKeyPadHandler();
    void getSXMValidNumber(int currentNumber);
    void createValidNumberMapping();
    QString getValidMapValue(int currentNumber);
    QString appendValidNumber(QString currentVal, QString newVal);

signals:
    void doneGetSXMValidNumber(QString validkey);
private:
    QList<int> m_channelList;
    QMap<int, QString> m_validMap;
};

#endif // SXMKEYPADHANDLER_H
