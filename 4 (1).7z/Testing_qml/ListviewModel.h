#ifndef LISTVIEWMODEL_H
#define LISTVIEWMODEL_H

#include <QObject>
#include <QAbstractListModel>
#include <QModelIndex>
#include "ListViewElements.h"

class ListviewModel : public QAbstractListModel
{
    Q_OBJECT
public:
    enum ListEnums {
        NAME = Qt::UserRole + 1,
        NUMBER
    };
    ListviewModel(QObject* parent = nullptr);
    ~ListviewModel();
    Q_INVOKABLE QVariant data(const QModelIndex &index, int role) const;
    int rowCount(const QModelIndex & parent = QModelIndex()) const;
    Q_INVOKABLE void move(int src, int dst);
    Q_INVOKABLE void reOrderListModel(QList<int> indexList);
    virtual QHash<int,QByteArray> roleNames() const;
    void addData(ListViewElements* element);
    void resetData();
protected:
    QList<ListViewElements*> m_elements;

};

#endif // LISTVIEWMODEL_H
