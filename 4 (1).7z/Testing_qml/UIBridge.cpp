#include "UIBridge.h"
#include "AMFMKeypadHandler.h"
#include <QDebug>
#include "AppMain.h"

UIBridge::UIBridge(QObject* appMain)
: QObject(appMain)
{
    m_amfmHandler = new AMFMKeypadHandler();
    m_sxmHandler = new SXMKeyPadHandler();
    connect(m_amfmHandler, SIGNAL(doneGetValidNumber(QString)), this, SLOT(onGetValidNumberDone(QString)));
    connect(m_amfmHandler, SIGNAL(addDotToCurrentFMFreq()), this, SLOT(onAddDotToCurrentFMFreq()));
    connect(m_sxmHandler, SIGNAL(doneGetSXMValidNumber(QString)), this, SLOT(onGetSXMValidNumberDone(QString)));
    connect(this, SIGNAL(screenChangeded(QString)), appMain, SLOT(changedScreen(QString)));
    connect(this, SIGNAL(styleModeChanged(QString)), appMain, SLOT(onStyleModeChanged(QString)));

}

void UIBridge::onAMFMValidNumberChanged(bool isFM, QString enteredNumber)
{
    qDebug() << "isFM: " << isFM << "-----enteredNumber: " << enteredNumber;
    m_amfmHandler->onAMFMValidNumberChanged(isFM, enteredNumber);
}

void UIBridge::onSXMValidNumberChanged(QString enteredNumber)
{
    m_sxmHandler->getSXMValidNumber(enteredNumber.toInt());
}

void UIBridge::changeScreen(QString screenPath)
{
    emit screenChangeded(screenPath);
}

void UIBridge::changeStyleMode(QString styleMode)
{
    qDebug() << "UIBridge: styleMode: " << styleMode;
    emit styleModeChanged(styleMode);
}

void UIBridge::onGetValidNumberDone(QString number)
{
    qDebug() << "validKey: " << number;
    emit currentAMFMValidNumberChanged(number);
}

void UIBridge::onAddDotToCurrentFMFreq() {
    emit addDotToCurrentFMFreq();
}

void UIBridge::onGetSXMValidNumberDone(QString number)
{
    emit currentSXMValidNumberChanged(number);
}

