#include "AppMain.h"
#include "ListviewModel.h"
#include "UIBridge.h"
#include <QDebug>
#include <QQmlContext>
#include <QTimer>
#include <QtQml>
#include "ComponentStates.h"

AppMain* AppMain::m_instance = nullptr;

AppMain *AppMain::getInsctance()
{
    if (!m_instance) {
        m_instance = new AppMain();
    }
   return m_instance;
}

AppMain::AppMain(QObject* parent)
{
    m_styleMode = "day";
    qmlRegisterSingletonType(QUrl("qrc:/CommonStates.qml"), "CommonStates", 1, 0, "CommonStates");
    qmlRegisterSingletonType(QUrl("qrc:/GeneralButtonTextStyle.qml"), "ButtonStyle", 1, 0, "ButtonStyle");
    qmlRegisterSingletonType(QUrl("qrc:/GeneraColorOverlayStyle.qml"), "OverlayStyle", 1, 0, "OverlayStyle");
    qmlRegisterSingletonType(QUrl("qrc:/GeneralTextStyle.qml"), "TextStyle", 1, 0, "TextStyle");
    qmlRegisterType<ComponentStates>("ComponentStates", 1, 0, "ComponentStates");

    m_uiBridge = new UIBridge(this);
    m_view.rootContext()->setContextProperty("UIBridge", m_uiBridge);
    ListviewModel *model;
    model = new ListviewModel();
    model->addData(new ListViewElements("Van Bom", 1098));
    model->addData(new ListViewElements("Van Bom 1", 1097));
    model->addData(new ListViewElements("Van Bom 2", 1096));
    model->addData(new ListViewElements("Van Bom 3", 1098));
    model->addData(new ListViewElements("Van Bom 4", 1097));
    model->addData(new ListViewElements("Van Bom 5", 1096));
    model->addData(new ListViewElements("Van Bom 6", 1098));
    model->addData(new ListViewElements("Van Bom 7", 1097));
    model->addData(new ListViewElements("Van Bom 8", 1096));
    model->addData(new ListViewElements("Van Bom 9", 1098));
    model->addData(new ListViewElements("Van Bom 10", 1097));
    model->addData(new ListViewElements("Van Bom 11", 1096));
    m_view.rootContext()->setContextProperty("stationModel", model);
    m_view.rootContext()->setContextProperty("styleMode", m_styleMode);
    m_view.setSource(QUrl(QStringLiteral("qrc:/main.qml")));
    m_rootObject = m_view.rootObject();
    m_view.show();
    qDebug() << "Vao 1";
    m_mainLoader = m_rootObject->findChild<QObject *>("mainContent");
    if (m_mainLoader) {
        m_mainLoader->setProperty("source", "qrc:/TestingScreen_2.qml");
    }
    QObject *linerTune = m_rootObject->findChild<QObject *>("liner_tunner_station");
    if (linerTune) {
        linerTune->setProperty("currentIndex", 5);
    }
//    changedScreen("qrc:/TestingScreen.qml");
//    if (m_rootObject) {
//        qDebug() << "Vao 1";
//        m_rootObject->setProperty("sourceScreen", "qrc:/TestingScreen.qml");
//    }
//        QObject::connect(m_rootObject, SIGNAL(screenReady()), this, SLOT(onScreenReady()));
}

void AppMain::changedScreen(QString screenPath)
{
    m_mainLoader->setProperty("source", screenPath);
}

void AppMain::onStyleModeChanged(QString styleMode)
{
    if (m_styleMode == "day")
        m_styleMode = "night";
    else
        m_styleMode = "day";
    m_view.rootContext()->setContextProperty("styleMode", m_styleMode);
}

void AppMain::onScreenReady()
{
    m_model.addData(new ListViewElements("Van Bom", 1098));
    m_model.addData(new ListViewElements("Van Bom 1", 1097));
    m_model.addData(new ListViewElements("Van Bom 2", 1096));
    m_model.addData(new ListViewElements("Van Bom", 1098));
    m_model.addData(new ListViewElements("Van Bom 1", 1097));
    m_model.addData(new ListViewElements("Van Bom 2", 1096));
    m_model.addData(new ListViewElements("Van Bom", 1098));
    m_model.addData(new ListViewElements("Van Bom 1", 1097));
    m_model.addData(new ListViewElements("Van Bom 2", 1096));
    m_model.addData(new ListViewElements("Van Bom", 1098));
    m_model.addData(new ListViewElements("Van Bom 1", 1097));
    m_model.addData(new ListViewElements("Van Bom 2", 1096));
    m_model.addData(new ListViewElements("Van Bom", 1098));
    m_model.addData(new ListViewElements("Van Bom 1", 1097));
    m_model.addData(new ListViewElements("Van Bom 2", 1096));
    m_model.addData(new ListViewElements("Van Bom", 1098));
    m_model.addData(new ListViewElements("Van Bom 1", 1097));
    m_model.addData(new ListViewElements("Van Bom 2", 1096));
    m_model.addData(new ListViewElements("Van Bom", 1098));
    m_model.addData(new ListViewElements("Van Bom 1", 1097));
    m_model.addData(new ListViewElements("Van Bom 2", 1096));
    m_model.addData(new ListViewElements("Van Bom", 1098));
    m_model.addData(new ListViewElements("Van Bom 1", 1097));
    m_model.addData(new ListViewElements("Van Bom 2", 1096));
    m_model.addData(new ListViewElements("Van Bom", 1098));
    m_model.addData(new ListViewElements("Van Bom 1", 1097));
    m_model.addData(new ListViewElements("Van Bom 2", 1096));
    m_model.addData(new ListViewElements("Van Bom", 1098));
    m_model.addData(new ListViewElements("Van Bom 1", 1097));
    m_model.addData(new ListViewElements("Van Bom 2", 1096));
//    QObject* mainContent = m_view.findChildren<QObject*>("mainContent");
//    m_rootObject->setProperty("listviewModel", QVariant::fromValue(&m_model));
//    QTimer *timer = new QTimer(this);
//    connect(timer, SIGNAL(timeout()), this, SLOT(updateList()));
//    timer->start(10000);
}

void AppMain::updateList()
{
    m_model.resetData();
//    static int i = 0;
//    i++;
//    m_model.addData(new ListViewElements("Van Bom", i));

    qDebug() << m_model.rowCount();
    m_rootObject->setProperty("listviewModel", QVariant::fromValue(&m_model));
}
