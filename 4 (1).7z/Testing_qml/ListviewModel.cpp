#include "ListviewModel.h"
#include <QDebug>

ListviewModel::ListviewModel(QObject *parent)
{

}

ListviewModel::~ListviewModel()
{

}

QVariant ListviewModel::data(const QModelIndex &index, int role) const
{
    if (index.row() < 0 || index.row() >= m_elements.size()) {
        return QVariant();
    }
    ListViewElements* element = m_elements.at(index.row());
    switch (role) {
    case NAME:
        return QVariant::fromValue(element->name());
        break;
    case NUMBER:
        return QVariant::fromValue(element->number());
    default:
        return QVariant();
        break;
    }
}

int ListviewModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return m_elements.count();
}

QHash<int, QByteArray> ListviewModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[NAME] = "name";
    roles[NUMBER] = "number";
    return roles;
}

void ListviewModel::addData(ListViewElements *element)
{
    beginInsertRows(QModelIndex(), rowCount(), rowCount());
    m_elements << element;
    endInsertRows();
}

void ListviewModel::resetData()
{
    beginResetModel();
    for (QList<ListViewElements*>::size_type index = 0; index < m_elements.size(); index++){
        ListViewElements *element = m_elements[index];
        delete(element);
        element = nullptr;
    }
    m_elements.clear();
    endResetModel();
}

void ListviewModel::move(int src, int dst) {
    if (0 <= src && src < m_elements.size() && 0 <= dst && dst < m_elements.size() && src != dst) {
        if(dst > src) {
            beginMoveRows(QModelIndex(), src, src, QModelIndex(), dst + 1);
        } else {
            beginMoveRows(QModelIndex(), src, src, QModelIndex(), dst);
        }
        m_elements.move(src, dst);
        endMoveRows();
    }
}

void ListviewModel::reOrderListModel(QList<int> indexList)
{
    for (int i = 0; i < indexList.length(); i++) {
        qDebug() << "newIndex: " << indexList.at(i);
    }
}
