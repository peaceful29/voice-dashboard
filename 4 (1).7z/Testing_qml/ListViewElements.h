#ifndef LISTVIEWELEMENTS_H
#define LISTVIEWELEMENTS_H

#include <QObject>
class ListViewElements : public QObject
{
    Q_OBJECT
public:
    ListViewElements(QObject* parent = nullptr);
    ListViewElements(const QString &name, const int &number);
    virtual ~ListViewElements();

    QString name() const;
    void setName(const QString &name);

    int number() const;
    void setNumber(int number);

private:
    QString m_name;
    int     m_number;
};

#endif // LISTVIEWELEMENTS_H
