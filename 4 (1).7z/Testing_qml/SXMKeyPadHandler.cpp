#include "SXMKeyPadHandler.h"
#include <QDebug>

SXMKeyPadHandler::SXMKeyPadHandler()
{
    m_channelList = {1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 21, 25, 27, 29, 31, 32, 33, 35, 38, 39, 40, 41,
                    42, 43, 45, 47, 49, 50, 52, 55, 57, 59, 61, 63, 67, 68, 69, 70, 75, 77, 79, 80, 91, 99, 101, 103,
                    105, 107, 108, 109, 111, 112, 113, 115, 117, 118, 119, 120, 125, 129, 134, 135, 137, 139, 145, 146,
                    155, 157, 159, 160, 161, 163, 167, 170, 185, 189, 192, 193, 201, 202, 223, 225, 235, 237, 256, 304,
                    306, 308, 311, 312, 315, 415, 478, 1001, 1120, 1234};
    createValidNumberMapping();
}


void SXMKeyPadHandler::getSXMValidNumber(int currentNumber)
{
    qDebug() << "VanBom:: Vao 2: currentNumber: " + currentNumber;
    qDebug() << "VanBom:: Vao 3: m_validMap: " + m_validMap.value(currentNumber, "");

    emit doneGetSXMValidNumber(m_validMap.value(currentNumber, ""));
}

void SXMKeyPadHandler::createValidNumberMapping()
{
    qDebug() << "VanBom:: Vao 1";
    for (int i = 0; i < m_channelList.length(); i++){
        int _first = m_channelList.at(i)/10000;
        m_validMap[_first] = appendValidNumber(getValidMapValue(_first), QString::number(m_channelList.at(i)/1000));
        int _second = m_channelList.at(i)/1000;
        m_validMap[_second]  = appendValidNumber(getValidMapValue(_second),  QString::number((m_channelList.at(i)%1000)/100));
        int _third = m_channelList.at(i)/100;
        m_validMap[_third]  = appendValidNumber(getValidMapValue(_third),  QString::number((m_channelList.at(i)%100/10)));
        int _fourth = m_channelList.at(i)/10;
        m_validMap[_fourth]  = appendValidNumber(getValidMapValue(_fourth),  QString::number(m_channelList.at(i)%10));
    }
    qDebug() << "VanBom:: Vao 4: valid Key: " + m_validMap.value(0, "");
}

QString SXMKeyPadHandler::getValidMapValue(int currentNumber)
{
    return m_validMap.value(currentNumber, "");
}

QString SXMKeyPadHandler::appendValidNumber(QString currentVal, QString newVal)
{
    if (currentVal.contains(newVal))
        return currentVal;
    return currentVal + newVal;
}
