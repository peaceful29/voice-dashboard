/**********************************************************
*(c) Copyright 2012. All Rights Reserved
* LG Electronics.
*
* Project Name: LG Electronics VietNam
* Group: LGEVH VC IVI SOFTWARE DEVELOPMENT 1
* Security: Confidential
* ***********************************************************/
/*********************************************************
* @file
* Filename: AMFMKeypadHandler
* Purpose: Enabled key for valid frequency
* Platform: QNX
* Author(s): khai.hoang
* E-mail id.: khai.hoang@lge.com
* Creation date : Sep 15, 2017
*
* Modifications:
*
*
**********************************************************/
#ifndef AMFMKEYPADHANDLER_H
#define AMFMKEYPADHANDLER_H

#include <QString>
#include <QObject>

class AMFMKeypadHandler : public QObject
{
    Q_OBJECT

public:
    AMFMKeypadHandler();
    ~AMFMKeypadHandler();
    void onAMFMValidNumberChanged(bool isFM, QString currentNumber);

signals:
    void addDotToCurrentFMFreq();
    void doneGetValidNumber(QString validKey);
private:
    void getAMValidNumber(QString currentNumber);
    void getFMValidNumber(QString currentNumber, bool bDel);
    void getAMFMRange(bool isFM, int& startFreq, int& endFreq, int& step);
};

#endif // AMFMKEYPADHANDLER_H
