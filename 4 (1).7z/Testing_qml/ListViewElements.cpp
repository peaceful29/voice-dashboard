#include "ListViewElements.h"


ListViewElements::ListViewElements(QObject *parent)
{

}

ListViewElements::ListViewElements(const QString &name, const int &number): m_name(name), m_number(number)
{

}

ListViewElements::~ListViewElements()
{

}

QString ListViewElements::name() const
{
    return m_name;
}

void ListViewElements::setName(const QString &name)
{
    m_name = name;
}

int ListViewElements::number() const
{
    return m_number;
}

void ListViewElements::setNumber(int number)
{
    m_number = number;
}

