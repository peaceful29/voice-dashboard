#include "AMFMKeypadHandler.h"
#include <QVector>
#include <QDebug>

AMFMKeypadHandler::AMFMKeypadHandler()
{
}

AMFMKeypadHandler::~AMFMKeypadHandler()
{
}

void AMFMKeypadHandler::onAMFMValidNumberChanged(bool isFM, QString currentNumber)
{
    if(isFM)
        getFMValidNumber(currentNumber, false);
    else
        getAMValidNumber(currentNumber);
}

void AMFMKeypadHandler::getAMValidNumber(QString currentNumber)
{
    int nCurCHInfo = currentNumber.toInt();
    QVector<int> ocValidNumber;
    ocValidNumber.clear();

    int nStartFreq, nEndFreq, nStep;// = 530; = 1710; = 10;
    getAMFMRange(false, nStartFreq, nEndFreq, nStep);
    qDebug("AM KEYPAD valid key start: %s, %d, %d, %d",
          currentNumber.toStdString().c_str(), nStartFreq, nEndFreq, nStep);
    switch (currentNumber.count()) {
    case 0:
    {
        for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
            if (nFreq/1000 > 0) {
                if (ocValidNumber.indexOf(nFreq/1000) == -1) {
                    ocValidNumber.append(nFreq/1000);
                }
            } else if (nFreq/100 > 0) {
                if (ocValidNumber.indexOf(nFreq/100) == -1) {
                    ocValidNumber.append(nFreq/100);
                }
            }
        }
    }
        break;
    case 1:
    {
        if ((nCurCHInfo*1000) >= nStartFreq && (nCurCHInfo*1000) <= nEndFreq) {
            for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                if (nFreq/1000 == 1) {
                    if (ocValidNumber.indexOf((nFreq%1000)/100) == -1) {
                        ocValidNumber.append((nFreq%1000)/100);
                    }
                }
            }
        } else if ((nCurCHInfo*100) >= nStartFreq && (nCurCHInfo*100) <= nEndFreq) {
            if (nEndFreq > (nCurCHInfo+1)*100)
                nEndFreq = (nCurCHInfo+1)*100;
            for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                if (nFreq/(nCurCHInfo*100) == 1 && ((nFreq%(nCurCHInfo*100))/10) <10) {
                    if (ocValidNumber.indexOf((nFreq%(nCurCHInfo*100))/10) == -1) {
                        ocValidNumber.append((nFreq%(nCurCHInfo*100))/10);
                    }
                }
            }
        } else if (nStartFreq/(nCurCHInfo*100) == 1) {
            if (nEndFreq > (nCurCHInfo+1)*100)
                nEndFreq = (nCurCHInfo+1)*100;
            for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                if ((nFreq%(nCurCHInfo*100))/10 > -1 && (nFreq%(nCurCHInfo*100))/10 < 10) {
                    if (ocValidNumber.indexOf((nFreq%(nCurCHInfo*100))/10) == -1) {
                        ocValidNumber.append((nFreq%(nCurCHInfo*100))/10);
                    }
                }
            }
        }
    }
        break;
    case 2:
    {
        if ((nCurCHInfo*100) >= nStartFreq && (nCurCHInfo*100) <= nEndFreq) {
            if (nEndFreq >= (nCurCHInfo+1)*100)
                nEndFreq = (nCurCHInfo+1)*100;
            for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                if (nFreq/(nCurCHInfo*100) == 1 && ((nFreq%(nCurCHInfo*100))/10) <10) {
                    if (ocValidNumber.indexOf((nFreq%(nCurCHInfo*100))/10) == -1) {
                        ocValidNumber.append((nFreq%(nCurCHInfo*100))/10);
                    }
                }
            }
        } else if ((nCurCHInfo*10) >= nStartFreq && (nCurCHInfo*10) <= nEndFreq) {
            if (nEndFreq > (nCurCHInfo+1)*10)
                nEndFreq = (nCurCHInfo+1)*10;
            for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                if (nFreq/(nCurCHInfo*10) == 1 && (nFreq%(nCurCHInfo*10)) <10) {
                    if (ocValidNumber.indexOf((nFreq%(nCurCHInfo*10))) == -1) {
                        ocValidNumber.append((nFreq%(nCurCHInfo*10)));
                    }
                }
            }
        } else if (nStartFreq/(nCurCHInfo*10) == 1) {
            if (nEndFreq > (nCurCHInfo+1)*10)
                nEndFreq = (nCurCHInfo+1)*10;
            for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                if ((nFreq%(nCurCHInfo*10)) > -1 && (nFreq%(nCurCHInfo*10)) < 10) {
                    if (ocValidNumber.indexOf((nFreq%(nCurCHInfo*10))) == -1) {
                        ocValidNumber.append((nFreq%(nCurCHInfo*10)));
                    }
                }
            }
        }
    }
        break;
    case 3:
    {
        if ((nCurCHInfo*10) >= nStartFreq && (nCurCHInfo*10) <= nEndFreq) {
            if ((nCurCHInfo*10) == nEndFreq) {
                ocValidNumber.append(0);
            } else {
                if (nEndFreq > (nCurCHInfo+1)*10)
                    nEndFreq = (nCurCHInfo+1)*10;
                for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                    if (nFreq/(nCurCHInfo*10) == 1 && (nFreq%(nCurCHInfo*10)) <10) {
                        if (ocValidNumber.indexOf((nFreq%(nCurCHInfo*10))) == -1) {
                            ocValidNumber.append((nFreq%(nCurCHInfo*10)));
                        }
                    }
                }
            }
        } else if (nCurCHInfo >= nStartFreq && nCurCHInfo <= nEndFreq) {
            ocValidNumber.clear();
        }
    }
        break;
    default:
    {
        ocValidNumber.clear();
    }
        break;
    }

    QString validkey;
    for(int i = 0; i < ocValidNumber.size(); i++) {
        validkey.append(QString::number(ocValidNumber[i]));
    }
    qDebug("AMFM KEYPAD valid key c: %s",validkey.toStdString().c_str() );
    emit doneGetValidNumber(validkey);
}

void AMFMKeypadHandler::getFMValidNumber(QString currentNumber, bool bDel)
{
    QString strCurCHInfo = currentNumber;
    int nCurCHInfo=0;
    if (strCurCHInfo.indexOf('.') == -1) {
        nCurCHInfo = strCurCHInfo.toInt();
    } else {
        QString strTmp = strCurCHInfo.left(strCurCHInfo.indexOf('.'));
        nCurCHInfo = strTmp.toInt();
    }

    QVector<int> ocValidNumber;
    ocValidNumber.clear();

    int nStartFreq, nEndFreq, nStep;// = 8770; = 10800; = 50;
    getAMFMRange(true, nStartFreq, nEndFreq, nStep);

    qDebug("FM KEYPAD valid key start: %s, %d, %d, %d, %d",
          currentNumber.toStdString().c_str(), strCurCHInfo.count(), nStartFreq, nEndFreq, nStep);
    switch (strCurCHInfo.count()) {
        case 0:
        {
            for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                if (nFreq/10000 > 0) {
                    if (ocValidNumber.indexOf(nFreq/10000) == -1) {
                        ocValidNumber.append(nFreq/10000);
                    }
                } else if (nFreq/1000 > 0) {
                    if (ocValidNumber.indexOf(nFreq/1000) == -1) {
                        ocValidNumber.append(nFreq/1000);
                    }
                }
            }
        }
            break;
        case 1:
        {
            if ((nCurCHInfo*10000) >= nStartFreq && (nCurCHInfo*10000) <= nEndFreq) {
                nStartFreq = nCurCHInfo*10000;
                for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                    if ((nFreq%nStartFreq)/1000 > -1 && (nFreq%nStartFreq)/1000 < 10) {
                        if (ocValidNumber.indexOf((nFreq%nStartFreq)/1000) == -1) {
                            ocValidNumber.append((nFreq%nStartFreq)/1000);
                        }
                    }
                }
            } else if ((nCurCHInfo*1000) >= nStartFreq && (nCurCHInfo*1000) <= nEndFreq) {
                nStartFreq = nCurCHInfo*1000;
                if (nEndFreq > (nCurCHInfo+1)*1000)
                    nEndFreq = (nCurCHInfo+1)*1000;
                for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                    if ((nFreq%nStartFreq)/100 > -1 && (nFreq%nStartFreq)/100 < 10) {
                        if (ocValidNumber.indexOf((nFreq%nStartFreq)/100) == -1) {
                            ocValidNumber.append((nFreq%nStartFreq)/100);
                        }
                    }
                }
            } else if (nStartFreq/(nCurCHInfo*1000) == 1) {
                if (nEndFreq > (nCurCHInfo+1)*1000)
                    nEndFreq = (nCurCHInfo+1)*1000;
                for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                    if ((nFreq%(nCurCHInfo*1000))/100 > -1 && (nFreq%(nCurCHInfo*1000))/100 < 10) {
                        if (ocValidNumber.indexOf((nFreq%(nCurCHInfo*1000))/100) == -1) {
                            ocValidNumber.append((nFreq%(nCurCHInfo*1000))/100);
                        }
                    }
                }
            }
        }
            break;
        case 2:
        {
            if ((nCurCHInfo*100) >= nStartFreq && (nCurCHInfo*100) <= nEndFreq) {
                //ocValidNumber.append(10);
                if (bDel == true) {
                    strCurCHInfo.remove(1,1);
                } else {
                    qDebug() << "Vao 2";
                    emit addDotToCurrentFMFreq();
                    return;
                    //strCurCHInfo.append(".");
                    //HLOGP("AMFM KEYPAD current:%s",strCurCHInfo.toStdString().c_str());
                }
                getFMValidNumber(strCurCHInfo, false);
                return;
            } else if ((nCurCHInfo*1000) >= nStartFreq && (nCurCHInfo*1000) <= nEndFreq) {
                nStartFreq = nCurCHInfo*1000;
                for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                    if ((nFreq%nStartFreq)/100 > -1 && (nFreq%nStartFreq)/100 < 10) {
                        if (ocValidNumber.indexOf((nFreq%nStartFreq)/100) == -1) {
                            ocValidNumber.append((nFreq%nStartFreq)/100);
                        }
                    }
                }
            } else if (nStartFreq/(nCurCHInfo*100) == 1) {
                //ocValidNumber.append(10);
                if (bDel == true) {
                    strCurCHInfo.remove(1,1);
                } else {
                    qDebug() << "Vao 3";
                    emit addDotToCurrentFMFreq();
                    return;
                    //strCurCHInfo.append(".");
                    //HLOGP("AMFM KEYPAD current:%s",strCurCHInfo.toStdString().c_str());
                }
                getFMValidNumber(strCurCHInfo, false);
                return;
            }

        }
            break;
        case 3:
        {
            if (strCurCHInfo.indexOf('.') == 2) {
                if ((nCurCHInfo*100) >= nStartFreq && (nCurCHInfo*100) <= nEndFreq) {
                    //nStartFreq = nCurCHInfo*100;
                    if (nEndFreq > (nCurCHInfo+1)*100)
                        nEndFreq = (nCurCHInfo+1)*100;
                    for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                        if ((nFreq%((nCurCHInfo)*100))/10 > -1 && (nFreq%((nCurCHInfo)*100))/10 < 10) {
                            if (ocValidNumber.indexOf((nFreq%((nCurCHInfo)*100))/10) == -1) {
                                ocValidNumber.append((nFreq%((nCurCHInfo)*100))/10);
                            }
                        }
                    }
                } else if (nStartFreq/(nCurCHInfo*100) == 1) {
                    if (nEndFreq > (nCurCHInfo+1)*100)
                        nEndFreq = (nCurCHInfo+1)*100;
                    for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                        if ((nFreq%(nCurCHInfo*100))/10 > -1 && (nFreq%(nCurCHInfo*100))/10 < 10) {
                            if (ocValidNumber.indexOf((nFreq%(nCurCHInfo*100))/10) == -1) {
                                ocValidNumber.append((nFreq%(nCurCHInfo*100))/10);
                            }
                        }
                    }
                }
            } else {
                if ((nCurCHInfo*100) >= nStartFreq && (nCurCHInfo*100) <= nEndFreq) {
                    //ocValidNumber.append(10);
                    if (bDel == true) {
                        strCurCHInfo.remove(2,1);
                    } else {
                        qDebug() << "Vao 4";
                        emit addDotToCurrentFMFreq();
                        return;
                        //strCurCHInfo.append(".");
                        //HLOGP("AMFM KEYPAD current:%s",strCurCHInfo.toStdString().c_str());
                    }
                    getFMValidNumber(strCurCHInfo, false);
                    return;
                }

            }
        }
            break;
        case 4:
        {
            if (strCurCHInfo.indexOf('.') == 3) {
                if (nEndFreq%(nCurCHInfo*100) < 100) {
                    for (int nFreq=nEndFreq; nFreq>=nCurCHInfo*100; nFreq-=nStep) {
                        if ((nFreq%((nCurCHInfo)*100))/10 > -1 && (nFreq%((nCurCHInfo)*100))/10 < 10) {
                            if (ocValidNumber.indexOf((nFreq%((nCurCHInfo)*100))/10) == -1) {
                                ocValidNumber.append((nFreq%((nCurCHInfo)*100))/10);
                            }
                        }
                    }
                } else if ((nCurCHInfo*100) >= nStartFreq && (nCurCHInfo*100) <= nEndFreq) {
                    if (nEndFreq > (nCurCHInfo+1)*100)
                        nEndFreq = (nCurCHInfo+1)*100;
                    for (int nFreq=nStartFreq; nFreq<=nEndFreq; nFreq+=nStep) {
                        if ((nFreq%((nCurCHInfo)*100))/10 > -1 && (nFreq%((nCurCHInfo)*100))/10 < 10) {
                            if (ocValidNumber.indexOf((nFreq%((nCurCHInfo)*100))/10) == -1) {
                                ocValidNumber.append((nFreq%((nCurCHInfo)*100))/10);
                            }
                        }
                    }
                }
            } else if (nStep == 5) { //thai
                ocValidNumber.append(0);
                ocValidNumber.append(5);
            } else {
                ocValidNumber.clear();
            }
        }
            break;
        case 5:
        {
            if (nStep == 5) { //thai
                ocValidNumber.append(0);
                ocValidNumber.append(5);
            } else {
                ocValidNumber.clear();
            }
        }
            break;
        default:
        {
            ocValidNumber.clear();
        }
            break;
    }

    QString validkey;
    for(int i = 0; i < ocValidNumber.size(); i++) {
        validkey.append(QString::number(ocValidNumber[i]));
    }
    qDebug("AMFM KEYPAD valid key end: %s",validkey.toStdString().c_str() );
    emit doneGetValidNumber(validkey);
}

void AMFMKeypadHandler::getAMFMRange(bool isFM, int& startFreq, int& endFreq, int& step)
{
    if(isFM) {
        startFreq = 8770;
        endFreq = 10800;
        step = 50;
    } else {
        startFreq = 522;
        endFreq = 1629;
        step = 9;
    }
}

