#include "ListviewModel.h"
#include <QApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <AppMain.h>
int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    AppMain appMain;
    return app.exec();
}
